export type UserRole = 'veterinarian' | 'assistant' | 'admin' | 'staff';

export interface User {
  id: string;
  fullName: string;
  email: string;
  username: string;
  role: UserRole;
  avatarUrl?: string;
  phone?: string;
  title?: string;
  bio?: string;
  passwordHash?: string;
  createdAt: string;
}

export type PetSpecies = 'Dog' | 'Cat' | 'Bird' | 'Rabbit' | 'Hamster' | 'Reptile' | 'Other';
export type PetGender = 'Male' | 'Female' | 'Unknown';

export interface Pet {
  id: string;
  name: string;
  species: PetSpecies;
  breed: string;
  gender: PetGender;
  ageYears: number;
  ageMonths: number;
  dateOfBirth: string;
  color: string;
  weight: number; // in kg or configured unit
  microchipNumber?: string;
  allergies: string[];
  specialNotes?: string;
  photoUrl?: string;
  ownerId: string;
  createdAt: string;
  updatedAt: string;
}

export interface PetOwner {
  id: string;
  fullName: string;
  phoneNumber: string;
  emailAddress: string;
  completeAddress: string;
  emergencyContact: {
    name: string;
    phone: string;
    relationship: string;
  };
  notes?: string;
  createdAt: string;
  updatedAt: string;
}

export type AppointmentStatus = 'Pending' | 'Confirmed' | 'Completed' | 'Cancelled';

export interface Appointment {
  id: string;
  petId: string;
  ownerId: string;
  appointmentDate: string; // YYYY-MM-DD
  appointmentTime: string; // HH:mm
  veterinarian: string;
  reasonForVisit: string;
  additionalNotes?: string;
  status: AppointmentStatus;
  createdAt: string;
  updatedAt: string;
}

export interface VaccinationEntry {
  vaccineName: string;
  administeredDate: string;
  nextDueDate?: string;
  batchNumber?: string;
}

export interface MedicalRecord {
  id: string;
  petId: string;
  ownerId: string;
  veterinarian: string;
  consultationDate: string; // YYYY-MM-DD
  symptoms: string;
  diagnosis: string;
  treatment: string;
  prescribedMedication: string;
  vaccinationRecords: VaccinationEntry[];
  weight: number; // in kg
  temperature: number; // in Celsius
  followUpDate?: string;
  additionalNotes?: string;
  createdAt: string;
  updatedAt: string;
}

export interface ClinicSettings {
  clinicName: string;
  tagline: string;
  logoUrl?: string;
  phoneNumber: string;
  emergencyHotline: string;
  emailAddress: string;
  address: string;
  operatingHours: {
    weekdays: string;
    saturday: string;
    sunday: string;
  };
  weightUnit: 'kg' | 'lbs';
  temperatureUnit: '°C' | '°F';
}

export interface DashboardStats {
  totalRegisteredPets: number;
  totalPetOwners: number;
  totalAppointments: number;
  todayAppointments: number;
  completedAppointments: number;
  pendingAppointments: number;
}
