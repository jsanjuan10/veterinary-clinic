import {
  User,
  Pet,
  PetOwner,
  Appointment,
  MedicalRecord,
  ClinicSettings,
  DashboardStats,
} from '../types';

const STORAGE_KEYS = {
  USERS: 'sage_paw_users_v1',
  OWNERS: 'sage_paw_owners_v1',
  PETS: 'sage_paw_pets_v1',
  APPOINTMENTS: 'sage_paw_appointments_v1',
  RECORDS: 'sage_paw_records_v1',
  SETTINGS: 'sage_paw_settings_v1',
  AUTH_SESSION: 'sage_paw_session_v1',
};

// Formats YYYY-MM-DD relative to today
const getRelativeDateStr = (dayOffset: number): string => {
  const d = new Date();
  d.setDate(d.getDate() + dayOffset);
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
};

const DEFAULT_USERS: User[] = [];

const DEFAULT_SETTINGS: ClinicSettings = {
  clinicName: 'Sage & Paw Veterinary Clinic',
  tagline: 'Compassionate Care for Life’s Best Companions',
  logoUrl: '',
  phoneNumber: '+1 (555) 838-2273',
  emergencyHotline: '+1 (555) 911-PETS',
  emailAddress: 'hello@sagepaw.vet',
  address: '742 Evergreen Botanical Way, Suite 100, Meadowbrook, CA 94112',
  operatingHours: {
    weekdays: '8:00 AM – 7:00 PM',
    saturday: '8:30 AM – 4:00 PM',
    sunday: '10:00 AM – 2:00 PM (Urgent Care Only)',
  },
  weightUnit: 'kg',
  temperatureUnit: '°C',
};

const DEFAULT_OWNERS: PetOwner[] = [
  {
    id: 'OWN-101',
    fullName: 'Sarah Mitchell',
    phoneNumber: '+1 (555) 412-8890',
    emailAddress: 'sarah.mitchell@example.com',
    completeAddress: '142 Orchard Grove Lane, Meadowbrook, CA 94112',
    emergencyContact: {
      name: 'Robert Mitchell',
      phone: '+1 (555) 412-8891',
      relationship: 'Spouse',
    },
    notes: 'Prefers morning appointments. Dogs travel well in car.',
    createdAt: '2024-03-10T10:00:00Z',
    updatedAt: '2024-03-10T10:00:00Z',
  },
  {
    id: 'OWN-102',
    fullName: 'Michael Chang',
    phoneNumber: '+1 (555) 678-3341',
    emailAddress: 'mchang@example.com',
    completeAddress: '88 Whispering Pines Apt 4B, Meadowbrook, CA 94115',
    emergencyContact: {
      name: 'Linda Chang',
      phone: '+1 (555) 678-3342',
      relationship: 'Sister',
    },
    notes: 'Cat requires gentle handling; calm towel wrap recommended.',
    createdAt: '2024-03-15T11:20:00Z',
    updatedAt: '2024-03-15T11:20:00Z',
  },
  {
    id: 'OWN-103',
    fullName: 'Emma Watson-Lee',
    phoneNumber: '+1 (555) 902-5412',
    emailAddress: 'emma.lee@example.com',
    completeAddress: '305 Maple Ridge Boulevard, Meadowbrook, CA 94118',
    emergencyContact: {
      name: 'James Lee',
      phone: '+1 (555) 902-5419',
      relationship: 'Husband',
    },
    notes: 'Has pet health insurance with Trupanion.',
    createdAt: '2024-04-02T14:15:00Z',
    updatedAt: '2024-04-02T14:15:00Z',
  },
  {
    id: 'OWN-104',
    fullName: 'David Rodriguez',
    phoneNumber: '+1 (555) 349-7811',
    emailAddress: 'david.rodriguez@example.com',
    completeAddress: '512 Sunset Terrace, Meadowbrook, CA 94120',
    emergencyContact: {
      name: 'Elena Rodriguez',
      phone: '+1 (555) 349-7812',
      relationship: 'Mother',
    },
    notes: 'Active foster caregiver for local shelter.',
    createdAt: '2024-04-20T09:40:00Z',
    updatedAt: '2024-04-20T09:40:00Z',
  },
  {
    id: 'OWN-105',
    fullName: 'Jennifer Kim',
    phoneNumber: '+1 (555) 789-2104',
    emailAddress: 'jennifer.kim@example.com',
    completeAddress: '23 Valley Vista Way, Meadowbrook, CA 94122',
    emergencyContact: {
      name: 'Daniel Kim',
      phone: '+1 (555) 789-2105',
      relationship: 'Brother',
    },
    notes: 'Allergic to specific room sprays; requested unscented rooms.',
    createdAt: '2024-05-01T15:00:00Z',
    updatedAt: '2024-05-01T15:00:00Z',
  },
];

const DEFAULT_PETS: Pet[] = [
  {
    id: 'PET-201',
    name: 'Bella',
    species: 'Dog',
    breed: 'Golden Retriever',
    gender: 'Female',
    ageYears: 3,
    ageMonths: 4,
    dateOfBirth: '2023-07-12',
    color: 'Honey Cream',
    weight: 28.5,
    microchipNumber: '985141002348911',
    allergies: ['Chicken poultry proteins'],
    specialNotes: 'Extremely friendly, loves liver treats. Up to date on all core vaccinations.',
    photoUrl: '/src/assets/images/vet_clinic_hero_1793857119970.jpg',
    ownerId: 'OWN-101',
    createdAt: '2024-03-10T10:15:00Z',
    updatedAt: '2024-03-10T10:15:00Z',
  },
  {
    id: 'PET-202',
    name: 'Oliver',
    species: 'Cat',
    breed: 'Domestic Short Hair (Tabby)',
    gender: 'Male',
    ageYears: 2,
    ageMonths: 1,
    dateOfBirth: '2024-10-04',
    color: 'Brown Classic Tabby with White Chest',
    weight: 4.8,
    microchipNumber: '985141009847120',
    allergies: ['Flea saliva dermatitis'],
    specialNotes: 'Indoor-only cat. Very sweet when spoken to softly in exam rooms.',
    photoUrl: '/src/assets/images/vet_pet_care_1793857120930.jpg',
    ownerId: 'OWN-102',
    createdAt: '2024-03-15T11:30:00Z',
    updatedAt: '2024-03-15T11:30:00Z',
  },
  {
    id: 'PET-203',
    name: 'Luna',
    species: 'Cat',
    breed: 'Maine Coon',
    gender: 'Female',
    ageYears: 4,
    ageMonths: 6,
    dateOfBirth: '2022-05-18',
    color: 'Silver Torbie',
    weight: 6.9,
    microchipNumber: '985141004523910',
    allergies: [],
    specialNotes: 'Needs annual cardiac murmur screen (HCM genetic screening normal).',
    photoUrl: 'https://images.unsplash.com/photo-1533738363-b7f9aef128ce?w=400&auto=format&fit=crop&q=80',
    ownerId: 'OWN-103',
    createdAt: '2024-04-02T14:30:00Z',
    updatedAt: '2024-04-02T14:30:00Z',
  },
  {
    id: 'PET-204',
    name: 'Milo',
    species: 'Dog',
    breed: 'French Bulldog',
    gender: 'Male',
    ageYears: 1,
    ageMonths: 8,
    dateOfBirth: '2025-03-02',
    color: 'Fawn with Black Mask',
    weight: 11.2,
    microchipNumber: '985141007788992',
    allergies: ['Dairy', 'Environmental pollen'],
    specialNotes: 'Brachycephalic airways monitored. Keep cool during warm weather visits.',
    photoUrl: 'https://images.unsplash.com/photo-1583511655857-d19b40a7a54e?w=400&auto=format&fit=crop&q=80',
    ownerId: 'OWN-104',
    createdAt: '2024-04-20T10:00:00Z',
    updatedAt: '2024-04-20T10:00:00Z',
  },
  {
    id: 'PET-205',
    name: 'Clover',
    species: 'Rabbit',
    breed: 'Holland Lop',
    gender: 'Female',
    ageYears: 2,
    ageMonths: 0,
    dateOfBirth: '2024-11-01',
    color: 'Broken Chestnut',
    weight: 1.8,
    microchipNumber: '985141006129983',
    allergies: [],
    specialNotes: 'Timothy hay diet. Check incisors for proper wear each consultation.',
    photoUrl: 'https://images.unsplash.com/photo-1585110396000-c9ffd4e4b308?w=400&auto=format&fit=crop&q=80',
    ownerId: 'OWN-105',
    createdAt: '2024-05-01T15:20:00Z',
    updatedAt: '2024-05-01T15:20:00Z',
  },
  {
    id: 'PET-206',
    name: 'Kiwi',
    species: 'Bird',
    breed: 'Cockatiel',
    gender: 'Male',
    ageYears: 3,
    ageMonths: 2,
    dateOfBirth: '2023-09-15',
    color: 'Lutino Yellow & White',
    weight: 0.092, // 92 grams
    microchipNumber: 'LEG-BAND-CA-889',
    allergies: ['Aerosol sprays sensitive'],
    specialNotes: 'Whistles tunes. Needs feather grooming inspection.',
    photoUrl: 'https://images.unsplash.com/photo-1522858547137-f1dcec554f55?w=400&auto=format&fit=crop&q=80',
    ownerId: 'OWN-103',
    createdAt: '2024-05-10T16:00:00Z',
    updatedAt: '2024-05-10T16:00:00Z',
  },
];

const DEFAULT_APPOINTMENTS: Appointment[] = [
  {
    id: 'APT-301',
    petId: 'PET-201',
    ownerId: 'OWN-101',
    appointmentDate: getRelativeDateStr(0), // Today
    appointmentTime: '09:30',
    veterinarian: 'Dr. Sophia Jenkins, DVM',
    reasonForVisit: 'Annual Wellness & DHPP Booster',
    additionalNotes: 'Owner requested tick prevention refill and nail trim.',
    status: 'Confirmed',
    createdAt: '2024-10-25T09:00:00Z',
    updatedAt: '2024-10-25T09:00:00Z',
  },
  {
    id: 'APT-302',
    petId: 'PET-202',
    ownerId: 'OWN-102',
    appointmentDate: getRelativeDateStr(0), // Today
    appointmentTime: '11:00',
    veterinarian: 'Dr. Marcus Vance, DVM',
    reasonForVisit: 'Routine Follow-up & Weight Check',
    additionalNotes: 'Check previous ear cytology results.',
    status: 'Pending',
    createdAt: '2024-10-26T11:00:00Z',
    updatedAt: '2024-10-26T11:00:00Z',
  },
  {
    id: 'APT-303',
    petId: 'PET-204',
    ownerId: 'OWN-104',
    appointmentDate: getRelativeDateStr(0), // Today
    appointmentTime: '14:15',
    veterinarian: 'Dr. Sophia Jenkins, DVM',
    reasonForVisit: 'Allergy Flare-up Evaluation',
    additionalNotes: 'Mild redness around paws and inner ear flaps.',
    status: 'Confirmed',
    createdAt: '2024-10-27T14:00:00Z',
    updatedAt: '2024-10-27T14:00:00Z',
  },
  {
    id: 'APT-304',
    petId: 'PET-205',
    ownerId: 'OWN-105',
    appointmentDate: getRelativeDateStr(1), // Tomorrow
    appointmentTime: '10:00',
    veterinarian: 'Dr. Marcus Vance, DVM',
    reasonForVisit: 'Dental & Molar Assessment',
    additionalNotes: 'Appetite reported normal, routine preventative review.',
    status: 'Confirmed',
    createdAt: '2024-10-28T10:00:00Z',
    updatedAt: '2024-10-28T10:00:00Z',
  },
  {
    id: 'APT-305',
    petId: 'PET-203',
    ownerId: 'OWN-103',
    appointmentDate: getRelativeDateStr(3),
    appointmentTime: '15:30',
    veterinarian: 'Dr. Sophia Jenkins, DVM',
    reasonForVisit: 'Senior Cat Blood Panel & Urinalysis',
    additionalNotes: 'Fasting instructions sent to client.',
    status: 'Pending',
    createdAt: '2024-10-29T15:30:00Z',
    updatedAt: '2024-10-29T15:30:00Z',
  },
  {
    id: 'APT-306',
    petId: 'PET-206',
    ownerId: 'OWN-103',
    appointmentDate: getRelativeDateStr(-2), // 2 days ago
    appointmentTime: '13:00',
    veterinarian: 'Dr. Marcus Vance, DVM',
    reasonForVisit: 'Beak and Feather Checkup',
    additionalNotes: 'Beak trimmed slightly; dietary vitamin drops advised.',
    status: 'Completed',
    createdAt: '2024-10-20T13:00:00Z',
    updatedAt: '2024-10-20T13:00:00Z',
  },
  {
    id: 'APT-307',
    petId: 'PET-201',
    ownerId: 'OWN-101',
    appointmentDate: getRelativeDateStr(-7), // 7 days ago
    appointmentTime: '16:00',
    veterinarian: 'Dr. Sophia Jenkins, DVM',
    reasonForVisit: 'Minor Limp Inspection',
    additionalNotes: 'Soft tissue sprain resolved with rest and Carprofen.',
    status: 'Completed',
    createdAt: '2024-10-15T16:00:00Z',
    updatedAt: '2024-10-15T16:00:00Z',
  },
];

const DEFAULT_RECORDS: MedicalRecord[] = [
  {
    id: 'MED-401',
    petId: 'PET-201',
    ownerId: 'OWN-101',
    veterinarian: 'Dr. Sophia Jenkins, DVM',
    consultationDate: getRelativeDateStr(-7),
    symptoms: 'Mild intermittent lameness on right forelimb following off-leash park run.',
    diagnosis: 'Grade 1 carpal sprain; no joint effusion or bone tenderness on palpation.',
    treatment: 'Cold compress application for 48 hours, strict leash rest for 5 days.',
    prescribedMedication: 'Carprofen 75mg chewable tablets, 1 tab PO q24h with meal for 4 days.',
    vaccinationRecords: [
      {
        vaccineName: 'Rabies (3-Year PureVax)',
        administeredDate: '2024-03-10',
        nextDueDate: '2027-03-10',
        batchNumber: 'RB-899120',
      },
      {
        vaccineName: 'DHPP Core Booster',
        administeredDate: '2024-03-10',
        nextDueDate: '2025-03-10',
        batchNumber: 'DH-44129',
      },
    ],
    weight: 28.5,
    temperature: 38.4,
    followUpDate: getRelativeDateStr(7),
    additionalNotes: 'Patient was cooperative and responsive. Range of motion intact.',
    createdAt: '2024-10-15T16:30:00Z',
    updatedAt: '2024-10-15T16:30:00Z',
  },
  {
    id: 'MED-402',
    petId: 'PET-202',
    ownerId: 'OWN-102',
    veterinarian: 'Dr. Marcus Vance, DVM',
    consultationDate: getRelativeDateStr(-14),
    symptoms: 'Frequent head shaking and scratching at left pinna.',
    diagnosis: 'Mild unilateral Malassezia otitis externa (left ear yeast overgrowth).',
    treatment: 'In-clinic ear canal flush using sterile saline, topical suspension applied.',
    prescribedMedication: 'Posatex Otic Drops, 4 drops left ear once daily for 7 days.',
    vaccinationRecords: [
      {
        vaccineName: 'FVRCP Feline Core',
        administeredDate: '2024-03-15',
        nextDueDate: '2025-03-15',
        batchNumber: 'FV-77120',
      },
    ],
    weight: 4.8,
    temperature: 38.6,
    followUpDate: getRelativeDateStr(0),
    additionalNotes: 'Ear canal clear on repeat otoscopy. Tympanic membrane intact.',
    createdAt: '2024-10-08T11:45:00Z',
    updatedAt: '2024-10-08T11:45:00Z',
  },
  {
    id: 'MED-403',
    petId: 'PET-203',
    ownerId: 'OWN-103',
    veterinarian: 'Dr. Sophia Jenkins, DVM',
    consultationDate: getRelativeDateStr(-30),
    symptoms: 'Routine 6-month geriatric wellness examination; slight tartar on upper molars.',
    diagnosis: 'Stage 1 Gingivitis; otherwise excellent cardiopulmonary and renal indicators.',
    treatment: 'Prophy dental scaling and polishing scheduled for upcoming quarter.',
    prescribedMedication: 'VOHC-approved dental water additive + weekly enzymatic toothpaste.',
    vaccinationRecords: [
      {
        vaccineName: 'Rabies Feline 1-Year',
        administeredDate: '2024-04-02',
        nextDueDate: '2025-04-02',
        batchNumber: 'RF-99124',
      },
    ],
    weight: 6.9,
    temperature: 38.5,
    followUpDate: getRelativeDateStr(3),
    additionalNotes: 'Weight stable at 6.9kg. Abdominal palpation non-painful.',
    createdAt: '2024-09-22T15:00:00Z',
    updatedAt: '2024-09-22T15:00:00Z',
  },
  {
    id: 'MED-404',
    petId: 'PET-206',
    ownerId: 'OWN-103',
    veterinarian: 'Dr. Marcus Vance, DVM',
    consultationDate: getRelativeDateStr(-2),
    symptoms: 'Slight elongation of upper beak tip; grooming check.',
    diagnosis: 'Minor physiological beak overgrowth without underlying nutritional deficit.',
    treatment: 'Precision dremel beveling of maxillary beak tip.',
    prescribedMedication: 'None required. Cuttlebone and calcium mineral block renewed.',
    vaccinationRecords: [],
    weight: 0.092,
    temperature: 40.5, // Normal avian core temp
    followUpDate: getRelativeDateStr(90),
    additionalNotes: 'Avian respiratory rhythm calm and even throughout.',
    createdAt: '2024-10-20T13:45:00Z',
    updatedAt: '2024-10-20T13:45:00Z',
  },
];

class DatabaseService {
  private get<T>(key: string, defaultValue: T): T {
    try {
      const data = localStorage.getItem(key);
      if (!data) return defaultValue;
      return JSON.parse(data) as T;
    } catch {
      return defaultValue;
    }
  }

  private set<T>(key: string, value: T): void {
    try {
      localStorage.setItem(key, JSON.stringify(value));
    } catch (e) {
      console.error(`Error saving to localStorage [${key}]:`, e);
    }
  }

  public init() {
    // Purge any legacy demo accounts
    const storedUsers = this.get<User[]>(STORAGE_KEYS.USERS, []);
    const filteredUsers = storedUsers.filter(
      (u) => u.email !== 'dr.jenkins@sagepaw.vet' && u.email !== 'dr.vance@sagepaw.vet' && u.username !== 'dr_jenkins' && u.username !== 'dr_vance'
    );
    this.set(STORAGE_KEYS.USERS, filteredUsers);

    // If active session belongs to a demo account, clear it
    try {
      const activeSession = localStorage.getItem('sage_paw_active_session_v1');
      if (activeSession) {
        const parsed = JSON.parse(activeSession);
        if (
          parsed?.user?.email === 'dr.jenkins@sagepaw.vet' ||
          parsed?.user?.email === 'dr.vance@sagepaw.vet' ||
          parsed?.user?.username === 'dr_jenkins' ||
          parsed?.user?.username === 'dr_vance'
        ) {
          localStorage.removeItem('sage_paw_active_session_v1');
        }
      }
    } catch {}

    if (!localStorage.getItem(STORAGE_KEYS.SETTINGS)) {
      this.set(STORAGE_KEYS.SETTINGS, DEFAULT_SETTINGS);
    }
    if (!localStorage.getItem(STORAGE_KEYS.OWNERS)) {
      this.set(STORAGE_KEYS.OWNERS, DEFAULT_OWNERS);
    }
    if (!localStorage.getItem(STORAGE_KEYS.PETS)) {
      this.set(STORAGE_KEYS.PETS, DEFAULT_PETS);
    }
    if (!localStorage.getItem(STORAGE_KEYS.APPOINTMENTS)) {
      this.set(STORAGE_KEYS.APPOINTMENTS, DEFAULT_APPOINTMENTS);
    }
    if (!localStorage.getItem(STORAGE_KEYS.RECORDS)) {
      this.set(STORAGE_KEYS.RECORDS, DEFAULT_RECORDS);
    }
  }

  public resetToDefaults() {
    this.set(STORAGE_KEYS.USERS, DEFAULT_USERS);
    this.set(STORAGE_KEYS.SETTINGS, DEFAULT_SETTINGS);
    this.set(STORAGE_KEYS.OWNERS, DEFAULT_OWNERS);
    this.set(STORAGE_KEYS.PETS, DEFAULT_PETS);
    this.set(STORAGE_KEYS.APPOINTMENTS, DEFAULT_APPOINTMENTS);
    this.set(STORAGE_KEYS.RECORDS, DEFAULT_RECORDS);
  }

  // --- Users ---
  public getUsers(): User[] {
    return this.get<User[]>(STORAGE_KEYS.USERS, DEFAULT_USERS);
  }

  public getUserById(id: string): User | undefined {
    return this.getUsers().find((u) => u.id === id);
  }

  public getUserByEmailOrUsername(identifier: string): User | undefined {
    const term = identifier.trim().toLowerCase();
    return this.getUsers().find(
      (u) => u.email.toLowerCase() === term || u.username.toLowerCase() === term
    );
  }

  public createUser(userData: Omit<User, 'id' | 'createdAt'>): User {
    const users = this.getUsers();
    const newUser: User = {
      ...userData,
      id: `USR-${Date.now().toString().slice(-4)}`,
      createdAt: new Date().toISOString(),
    };
    users.push(newUser);
    this.set(STORAGE_KEYS.USERS, users);
    return newUser;
  }

  public updateUser(id: string, updates: Partial<User>): User {
    const users = this.getUsers();
    const index = users.findIndex((u) => u.id === id);
    if (index === -1) throw new Error('User not found');
    users[index] = { ...users[index], ...updates };
    this.set(STORAGE_KEYS.USERS, users);
    return users[index];
  }

  // --- Settings ---
  public getSettings(): ClinicSettings {
    return this.get<ClinicSettings>(STORAGE_KEYS.SETTINGS, DEFAULT_SETTINGS);
  }

  public updateSettings(settings: Partial<ClinicSettings>): ClinicSettings {
    const current = this.getSettings();
    const updated = { ...current, ...settings };
    this.set(STORAGE_KEYS.SETTINGS, updated);
    return updated;
  }

  // --- Owners ---
  public getOwners(): PetOwner[] {
    return this.get<PetOwner[]>(STORAGE_KEYS.OWNERS, DEFAULT_OWNERS);
  }

  public getOwnerById(id: string): PetOwner | undefined {
    return this.getOwners().find((o) => o.id === id);
  }

  public createOwner(data: Omit<PetOwner, 'id' | 'createdAt' | 'updatedAt'>): PetOwner {
    const owners = this.getOwners();
    const newOwner: PetOwner = {
      ...data,
      id: `OWN-${(owners.length + 101).toString()}`,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    owners.unshift(newOwner);
    this.set(STORAGE_KEYS.OWNERS, owners);
    return newOwner;
  }

  public updateOwner(id: string, data: Partial<PetOwner>): PetOwner {
    const owners = this.getOwners();
    const index = owners.findIndex((o) => o.id === id);
    if (index === -1) throw new Error('Owner not found');
    owners[index] = { ...owners[index], ...data, updatedAt: new Date().toISOString() };
    this.set(STORAGE_KEYS.OWNERS, owners);
    return owners[index];
  }

  public deleteOwner(id: string): boolean {
    const owners = this.getOwners();
    const pets = this.getPetsByOwnerId(id);
    if (pets.length > 0) {
      throw new Error(`Cannot delete owner with ${pets.length} registered pets. Please reassign or delete the pets first.`);
    }
    const filtered = owners.filter((o) => o.id !== id);
    this.set(STORAGE_KEYS.OWNERS, filtered);
    return true;
  }

  // --- Pets ---
  public getPets(): Pet[] {
    return this.get<Pet[]>(STORAGE_KEYS.PETS, DEFAULT_PETS);
  }

  public getPetById(id: string): Pet | undefined {
    return this.getPets().find((p) => p.id === id);
  }

  public getPetsByOwnerId(ownerId: string): Pet[] {
    return this.getPets().filter((p) => p.ownerId === ownerId);
  }

  public createPet(data: Omit<Pet, 'id' | 'createdAt' | 'updatedAt'>): Pet {
    const pets = this.getPets();
    const newPet: Pet = {
      ...data,
      id: `PET-${(pets.length + 201).toString()}`,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    pets.unshift(newPet);
    this.set(STORAGE_KEYS.PETS, pets);
    return newPet;
  }

  public updatePet(id: string, data: Partial<Pet>): Pet {
    const pets = this.getPets();
    const index = pets.findIndex((p) => p.id === id);
    if (index === -1) throw new Error('Pet not found');
    pets[index] = { ...pets[index], ...data, updatedAt: new Date().toISOString() };
    this.set(STORAGE_KEYS.PETS, pets);
    return pets[index];
  }

  public deletePet(id: string): boolean {
    const pets = this.getPets();
    const filteredPets = pets.filter((p) => p.id !== id);
    this.set(STORAGE_KEYS.PETS, filteredPets);

    // Also clean up appointments and medical records for this pet
    const appointments = this.getAppointments().filter((a) => a.petId !== id);
    this.set(STORAGE_KEYS.APPOINTMENTS, appointments);

    const records = this.getMedicalRecords().filter((r) => r.petId !== id);
    this.set(STORAGE_KEYS.RECORDS, records);
    return true;
  }

  // --- Appointments ---
  public getAppointments(): Appointment[] {
    return this.get<Appointment[]>(STORAGE_KEYS.APPOINTMENTS, DEFAULT_APPOINTMENTS);
  }

  public getAppointmentById(id: string): Appointment | undefined {
    return this.getAppointments().find((a) => a.id === id);
  }

  public getAppointmentsByPetId(petId: string): Appointment[] {
    return this.getAppointments().filter((a) => a.petId === petId);
  }

  public createAppointment(data: Omit<Appointment, 'id' | 'createdAt' | 'updatedAt'>): Appointment {
    const appointments = this.getAppointments();
    const newAppointment: Appointment = {
      ...data,
      id: `APT-${(appointments.length + 301).toString()}`,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    appointments.unshift(newAppointment);
    this.set(STORAGE_KEYS.APPOINTMENTS, appointments);
    return newAppointment;
  }

  public updateAppointment(id: string, data: Partial<Appointment>): Appointment {
    const appointments = this.getAppointments();
    const index = appointments.findIndex((a) => a.id === id);
    if (index === -1) throw new Error('Appointment not found');
    appointments[index] = { ...appointments[index], ...data, updatedAt: new Date().toISOString() };
    this.set(STORAGE_KEYS.APPOINTMENTS, appointments);
    return appointments[index];
  }

  public deleteAppointment(id: string): boolean {
    const appointments = this.getAppointments();
    const filtered = appointments.filter((a) => a.id !== id);
    this.set(STORAGE_KEYS.APPOINTMENTS, filtered);
    return true;
  }

  // --- Medical Records ---
  public getMedicalRecords(): MedicalRecord[] {
    return this.get<MedicalRecord[]>(STORAGE_KEYS.RECORDS, DEFAULT_RECORDS);
  }

  public getMedicalRecordById(id: string): MedicalRecord | undefined {
    return this.getMedicalRecords().find((r) => r.id === id);
  }

  public getMedicalRecordsByPetId(petId: string): MedicalRecord[] {
    return this.getMedicalRecords().filter((r) => r.petId === petId);
  }

  public createMedicalRecord(data: Omit<MedicalRecord, 'id' | 'createdAt' | 'updatedAt'>): MedicalRecord {
    const records = this.getMedicalRecords();
    const newRecord: MedicalRecord = {
      ...data,
      id: `MED-${(records.length + 401).toString()}`,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    records.unshift(newRecord);
    this.set(STORAGE_KEYS.RECORDS, records);
    return newRecord;
  }

  public updateMedicalRecord(id: string, data: Partial<MedicalRecord>): MedicalRecord {
    const records = this.getMedicalRecords();
    const index = records.findIndex((r) => r.id === id);
    if (index === -1) throw new Error('Medical Record not found');
    records[index] = { ...records[index], ...data, updatedAt: new Date().toISOString() };
    this.set(STORAGE_KEYS.RECORDS, records);
    return records[index];
  }

  public deleteMedicalRecord(id: string): boolean {
    const records = this.getMedicalRecords();
    const filtered = records.filter((r) => r.id !== id);
    this.set(STORAGE_KEYS.RECORDS, filtered);
    return true;
  }

  // --- Stats Aggregator ---
  public getDashboardStats(): DashboardStats {
    const pets = this.getPets();
    const owners = this.getOwners();
    const appointments = this.getAppointments();
    const todayStr = getRelativeDateStr(0);

    const todayApts = appointments.filter((a) => a.appointmentDate === todayStr);
    const completedApts = appointments.filter((a) => a.status === 'Completed');
    const pendingApts = appointments.filter((a) => a.status === 'Pending');

    return {
      totalRegisteredPets: pets.length,
      totalPetOwners: owners.length,
      totalAppointments: appointments.length,
      todayAppointments: todayApts.length,
      completedAppointments: completedApts.length,
      pendingAppointments: pendingApts.length,
    };
  }

  // --- Export & Import full database ---
  public exportData(): string {
    const bundle = {
      version: '1.0',
      timestamp: new Date().toISOString(),
      users: this.getUsers(),
      owners: this.getOwners(),
      pets: this.getPets(),
      appointments: this.getAppointments(),
      records: this.getMedicalRecords(),
      settings: this.getSettings(),
    };
    return JSON.stringify(bundle, null, 2);
  }

  public importData(jsonString: string): boolean {
    try {
      const bundle = JSON.parse(jsonString);
      if (bundle.users) this.set(STORAGE_KEYS.USERS, bundle.users);
      if (bundle.owners) this.set(STORAGE_KEYS.OWNERS, bundle.owners);
      if (bundle.pets) this.set(STORAGE_KEYS.PETS, bundle.pets);
      if (bundle.appointments) this.set(STORAGE_KEYS.APPOINTMENTS, bundle.appointments);
      if (bundle.records) this.set(STORAGE_KEYS.RECORDS, bundle.records);
      if (bundle.settings) this.set(STORAGE_KEYS.SETTINGS, bundle.settings);
      return true;
    } catch (e) {
      console.error('Failed to import database payload', e);
      return false;
    }
  }
}

export const db = new DatabaseService();
// Initialize database on bundle load
db.init();
