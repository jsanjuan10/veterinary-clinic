import { User } from '../types';
import { db } from './db';

const SESSION_KEY = 'sage_paw_active_session_v1';
const REMEMBER_KEY = 'sage_paw_remember_email_v1';

export interface AuthSession {
  user: User;
  token: string;
  expiresAt: number;
}

export class AuthService {
  public static getSavedEmail(): string {
    return localStorage.getItem(REMEMBER_KEY) || '';
  }

  public static setRememberEmail(email: string, remember: boolean): void {
    if (remember && email) {
      localStorage.setItem(REMEMBER_KEY, email);
    } else {
      localStorage.removeItem(REMEMBER_KEY);
    }
  }

  public static getCurrentSession(): AuthSession | null {
    try {
      const raw = localStorage.getItem(SESSION_KEY);
      if (!raw) return null;
      const session = JSON.parse(raw) as AuthSession;
      if (Date.now() > session.expiresAt) {
        localStorage.removeItem(SESSION_KEY);
        return null;
      }
      // Re-fetch latest user record from DB to keep profile updates in sync
      const freshUser = db.getUserById(session.user.id);
      if (freshUser) {
        session.user = freshUser;
      }
      return session;
    } catch {
      return null;
    }
  }

  public static login(identifier: string, passwordPlain: string, rememberMe: boolean = false): User {
    if (!identifier.trim()) {
      throw new Error('Please enter your email or username.');
    }
    if (!passwordPlain) {
      throw new Error('Please enter your password.');
    }

    const user = db.getUserByEmailOrUsername(identifier);
    if (!user) {
      throw new Error('Account not found. Please check your credentials or register a new account.');
    }

    if (user.passwordHash && user.passwordHash !== passwordPlain) {
      throw new Error('Incorrect password. Please try again.');
    }

    // Generate session
    const session: AuthSession = {
      user,
      token: `tok_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`,
      expiresAt: Date.now() + (rememberMe ? 30 * 24 * 60 * 60 * 1000 : 24 * 60 * 60 * 1000),
    };

    localStorage.setItem(SESSION_KEY, JSON.stringify(session));
    this.setRememberEmail(user.email, rememberMe);
    return user;
  }

  public static register(data: {
    fullName: string;
    email: string;
    username: string;
    passwordPlain: string;
    confirmPasswordPlain: string;
    role?: 'veterinarian' | 'assistant' | 'admin' | 'staff';
  }): User {
    const { fullName, email, username, passwordPlain, confirmPasswordPlain, role } = data;

    if (!fullName.trim()) throw new Error('Full name is required.');
    if (!email.trim() || !email.includes('@')) throw new Error('Valid email address is required.');
    if (!username.trim() || username.length < 3) throw new Error('Username must be at least 3 characters.');
    if (!passwordPlain || passwordPlain.length < 6) throw new Error('Password must be at least 6 characters.');
    if (passwordPlain !== confirmPasswordPlain) throw new Error('Passwords do not match.');

    // Duplicate check
    const existingEmail = db.getUserByEmailOrUsername(email);
    if (existingEmail) throw new Error('An account with this email address already exists.');

    const existingUsername = db.getUserByEmailOrUsername(username);
    if (existingUsername) throw new Error('This username is already taken. Please choose another.');

    const newUser = db.createUser({
      fullName: fullName.trim(),
      email: email.trim().toLowerCase(),
      username: username.trim().toLowerCase(),
      role: role || 'veterinarian',
      title: 'Veterinary Staff Practitioner',
      passwordHash: passwordPlain,
      avatarUrl: '/src/assets/images/vet_doctor_avatar_1793857120858.jpg',
    });

    // Auto-login newly registered user
    return this.login(newUser.email, passwordPlain, true);
  }

  public static logout(): void {
    localStorage.removeItem(SESSION_KEY);
  }

  public static resetPassword(email: string, newPassword: string): boolean {
    const user = db.getUserByEmailOrUsername(email);
    if (!user) {
      throw new Error('No registered account was found with that email address.');
    }
    if (!newPassword || newPassword.length < 6) {
      throw new Error('New password must be at least 6 characters.');
    }
    db.updateUser(user.id, { passwordHash: newPassword });
    return true;
  }
}
