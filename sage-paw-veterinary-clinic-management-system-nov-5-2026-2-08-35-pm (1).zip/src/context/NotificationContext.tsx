import React, { createContext, useContext, useState, useCallback, ReactNode } from 'react';
import { CheckCircle2, AlertTriangle, AlertCircle, Info, X } from 'lucide-react';

export type NotificationType = 'success' | 'error' | 'warning' | 'info';

export interface NotificationItem {
  id: string;
  type: NotificationType;
  title: string;
  message?: string;
  duration?: number;
}

interface NotificationContextType {
  notifications: NotificationItem[];
  notify: (notification: Omit<NotificationItem, 'id'>) => void;
  removeNotification: (id: string) => void;
}

const NotificationContext = createContext<NotificationContextType | undefined>(undefined);

export const NotificationProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [notifications, setNotifications] = useState<NotificationItem[]>([]);

  const removeNotification = useCallback((id: string) => {
    setNotifications((prev) => prev.filter((n) => n.id !== id));
  }, []);

  const notify = useCallback(
    (notification: Omit<NotificationItem, 'id'>) => {
      const id = `notif_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;
      const item: NotificationItem = {
        ...notification,
        id,
      };

      setNotifications((prev) => [...prev, item]);

      const duration = notification.duration ?? 4500;
      if (duration > 0) {
        setTimeout(() => {
          removeNotification(id);
        }, duration);
      }
    },
    [removeNotification]
  );

  return (
    <NotificationContext.Provider value={{ notifications, notify, removeNotification }}>
      {children}
      {/* Toast Notification Container */}
      <div className="fixed bottom-5 right-5 z-50 flex flex-col gap-2 max-w-sm w-full pointer-events-none px-4 sm:px-0">
        {notifications.map((item) => {
          const typeStyles = {
            success: 'bg-[#1C2C21] text-white border-[#3F664B]',
            error: 'bg-[#2E1818] text-white border-[#753434]',
            warning: 'bg-[#2D2314] text-white border-[#7C5A24]',
            info: 'bg-[#19242C] text-white border-[#335368]',
          };

          const iconMap = {
            success: <CheckCircle2 className="w-5 h-5 text-[#8FA98F] shrink-0" />,
            error: <AlertCircle className="w-5 h-5 text-[#E57373] shrink-0" />,
            warning: <AlertTriangle className="w-5 h-5 text-[#F2B05E] shrink-0" />,
            info: <Info className="w-5 h-5 text-[#81B4DE] shrink-0" />,
          };

          return (
            <div
              key={item.id}
              className={`pointer-events-auto rounded-xl p-4 shadow-xl border flex items-start gap-3 transition-all duration-200 transform translate-y-0 ${typeStyles[item.type]}`}
            >
              {iconMap[item.type]}
              <div className="flex-1 min-w-0 pr-1">
                <p className="text-sm font-semibold tracking-tight leading-tight">{item.title}</p>
                {item.message && (
                  <p className="text-xs text-white/80 mt-1 leading-relaxed">{item.message}</p>
                )}
              </div>
              <button
                onClick={() => removeNotification(item.id)}
                className="text-white/60 hover:text-white transition-colors p-0.5 rounded"
                aria-label="Dismiss notification"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          );
        })}
      </div>
    </NotificationContext.Provider>
  );
};

export const useNotification = () => {
  const context = useContext(NotificationContext);
  if (!context) {
    throw new Error('useNotification must be used within a NotificationProvider');
  }
  return context;
};
