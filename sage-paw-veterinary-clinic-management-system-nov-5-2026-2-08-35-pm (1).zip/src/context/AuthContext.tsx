import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { User } from '../types';
import { AuthService } from '../services/auth';
import { db } from '../services/db';
import { useNotification } from './NotificationContext';

interface AuthContextType {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  savedRememberEmail: string;
  login: (identifier: string, pass: string, remember: boolean) => Promise<boolean>;
  register: (data: {
    fullName: string;
    email: string;
    username: string;
    passwordPlain: string;
    confirmPasswordPlain: string;
  }) => Promise<boolean>;
  resetPassword: (email: string, newPass: string) => Promise<boolean>;
  logout: () => void;
  updateProfile: (updates: Partial<User>) => Promise<boolean>;
  changePassword: (oldPass: string, newPass: string) => Promise<boolean>;
  isLogoutModalOpen: boolean;
  setIsLogoutModalOpen: (open: boolean) => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [savedRememberEmail, setSavedRememberEmail] = useState<string>('');
  const [isLogoutModalOpen, setIsLogoutModalOpen] = useState<boolean>(false);
  const { notify } = useNotification();

  useEffect(() => {
    // Check saved email for remember me
    setSavedRememberEmail(AuthService.getSavedEmail());

    // Restore active session
    const session = AuthService.getCurrentSession();
    if (session) {
      setUser(session.user);
    }
    setIsLoading(false);
  }, []);

  const login = async (identifier: string, pass: string, remember: boolean): Promise<boolean> => {
    try {
      const loggedUser = AuthService.login(identifier, pass, remember);
      setUser(loggedUser);
      setSavedRememberEmail(AuthService.getSavedEmail());
      notify({
        type: 'success',
        title: `Welcome back, ${loggedUser.fullName.split(' ')[0]}`,
        message: 'Successfully logged in to Sage & Paw Clinic System.',
      });
      return true;
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Login failed. Please check credentials.';
      notify({
        type: 'error',
        title: 'Authentication Failed',
        message: msg,
      });
      return false;
    }
  };

  const register = async (data: {
    fullName: string;
    email: string;
    username: string;
    passwordPlain: string;
    confirmPasswordPlain: string;
  }): Promise<boolean> => {
    try {
      const registeredUser = AuthService.register(data);
      setUser(registeredUser);
      notify({
        type: 'success',
        title: 'Account Created',
        message: `Welcome to Sage & Paw, ${registeredUser.fullName}! Your practitioner account is ready.`,
      });
      return true;
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Registration failed.';
      notify({
        type: 'error',
        title: 'Registration Error',
        message: msg,
      });
      return false;
    }
  };

  const resetPassword = async (email: string, newPass: string): Promise<boolean> => {
    try {
      AuthService.resetPassword(email, newPass);
      notify({
        type: 'success',
        title: 'Password Updated',
        message: 'Your password has been successfully reset. You can now log in with your new credentials.',
      });
      return true;
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Password reset failed.';
      notify({
        type: 'error',
        title: 'Reset Failed',
        message: msg,
      });
      return false;
    }
  };

  const logout = () => {
    AuthService.logout();
    setUser(null);
    setIsLogoutModalOpen(false);
    notify({
      type: 'info',
      title: 'Logged Out',
      message: 'You have been securely logged out of Sage & Paw.',
    });
  };

  const updateProfile = async (updates: Partial<User>): Promise<boolean> => {
    if (!user) return false;
    try {
      const updated = db.updateUser(user.id, updates);
      setUser(updated);
      notify({
        type: 'success',
        title: 'Profile Updated',
        message: 'Your profile information has been saved.',
      });
      return true;
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Could not update profile.';
      notify({
        type: 'error',
        title: 'Update Error',
        message: msg,
      });
      return false;
    }
  };

  const changePassword = async (oldPass: string, newPass: string): Promise<boolean> => {
    if (!user) return false;
    if (user.passwordHash && user.passwordHash !== oldPass) {
      notify({
        type: 'error',
        title: 'Password Mismatch',
        message: 'Current password entered does not match your existing password.',
      });
      return false;
    }
    if (newPass.length < 6) {
      notify({
        type: 'error',
        title: 'Invalid Password',
        message: 'New password must contain at least 6 characters.',
      });
      return false;
    }
    db.updateUser(user.id, { passwordHash: newPass });
    notify({
      type: 'success',
      title: 'Security Updated',
      message: 'Your password has been changed successfully.',
    });
    return true;
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        isAuthenticated: !!user,
        isLoading,
        savedRememberEmail,
        login,
        register,
        resetPassword,
        logout,
        updateProfile,
        changePassword,
        isLogoutModalOpen,
        setIsLogoutModalOpen,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
