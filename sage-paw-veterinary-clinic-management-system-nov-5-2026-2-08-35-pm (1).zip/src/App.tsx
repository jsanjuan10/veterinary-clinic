import React, { useState } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { NotificationProvider, useNotification } from './context/NotificationContext';
import { Sidebar, NavTab } from './components/layout/Sidebar';
import { Navbar } from './components/layout/Navbar';
import { AuthView } from './components/auth/AuthView';
import { DashboardView } from './components/dashboard/DashboardView';
import { PetManagementView } from './components/pets/PetManagementView';
import { OwnerManagementView } from './components/owners/OwnerManagementView';
import { AppointmentManagementView } from './components/appointments/AppointmentManagementView';
import { MedicalRecordsView } from './components/records/MedicalRecordsView';
import { SettingsView } from './components/settings/SettingsView';
import { ConfirmationModal } from './components/common/ConfirmationModal';
import { PetDetailsModal } from './components/pets/PetDetailsModal';
import { PetFormModal } from './components/pets/PetFormModal';
import { OwnerFormModal } from './components/owners/OwnerFormModal';
import { AppointmentFormModal } from './components/appointments/AppointmentFormModal';
import { MedicalRecordFormModal } from './components/records/MedicalRecordFormModal';
import { db } from './services/db';
import { Pet, PetOwner, Appointment, MedicalRecord } from './types';

const MainLayout: React.FC = () => {
  const { user, isAuthenticated, isLoading, logout, isLogoutModalOpen, setIsLogoutModalOpen } = useAuth();
  const { notify } = useNotification();

  const [currentTab, setCurrentTab] = useState<NavTab>('dashboard');
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  // Cross-modal / Global Quick Action states
  const [activeDossierPetId, setActiveDossierPetId] = useState<string | null>(null);
  const [isGlobalPetModalOpen, setIsGlobalPetModalOpen] = useState(false);
  const [isGlobalOwnerModalOpen, setIsGlobalOwnerModalOpen] = useState(false);
  const [isGlobalAppointmentModalOpen, setIsGlobalAppointmentModalOpen] = useState(false);
  const [isGlobalRecordModalOpen, setIsGlobalRecordModalOpen] = useState(false);

  // Pre-fill target ID for scheduling or medical record
  const [prefilledPetId, setPrefilledPetId] = useState<string | undefined>(undefined);

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[#F7F9F7]">
        <div className="flex flex-col items-center gap-3">
          <div className="w-10 h-10 border-3 border-[#4A7255] border-t-transparent rounded-full animate-spin" />
          <span className="text-xs font-semibold text-[#4A7255] font-display tracking-wide">
            Loading Sage & Paw Clinic System...
          </span>
        </div>
      </div>
    );
  }

  if (!isAuthenticated || !user) {
    return <AuthView />;
  }

  const handleQuickAction = (actionType: 'appointment' | 'pet' | 'owner' | 'record') => {
    setPrefilledPetId(undefined);
    if (actionType === 'appointment') setIsGlobalAppointmentModalOpen(true);
    if (actionType === 'pet') setIsGlobalPetModalOpen(true);
    if (actionType === 'owner') setIsGlobalOwnerModalOpen(true);
    if (actionType === 'record') setIsGlobalRecordModalOpen(true);
  };

  const handleSelectPet = (petId: string) => {
    setActiveDossierPetId(petId);
  };

  const handleSelectOwner = (ownerId: string) => {
    setCurrentTab('owners');
  };

  const handleScheduleForPet = (petId: string) => {
    setPrefilledPetId(petId);
    setIsGlobalAppointmentModalOpen(true);
  };

  const handleRecordForPet = (petId: string) => {
    setPrefilledPetId(petId);
    setIsGlobalRecordModalOpen(true);
  };

  // Quick Action save handlers
  const handleSavePetGlobal = (petData: Omit<Pet, 'id' | 'createdAt' | 'updatedAt'>) => {
    db.createPet(petData);
    notify({
      type: 'success',
      title: 'Pet Patient Registered',
      message: `${petData.name} was added to the clinic.`,
    });
    setCurrentTab('pets');
  };

  const handleSaveOwnerGlobal = (ownerData: Omit<PetOwner, 'id' | 'createdAt' | 'updatedAt'>) => {
    db.createOwner(ownerData);
    notify({
      type: 'success',
      title: 'Client Registered',
      message: `${ownerData.fullName} was added to the directory.`,
    });
    setCurrentTab('owners');
  };

  const handleSaveAppointmentGlobal = (aptData: Omit<Appointment, 'id' | 'createdAt' | 'updatedAt'>) => {
    db.createAppointment(aptData);
    notify({
      type: 'success',
      title: 'Appointment Scheduled',
      message: `Scheduled for ${aptData.appointmentDate} at ${aptData.appointmentTime}.`,
    });
    setCurrentTab('appointments');
  };

  const handleSaveRecordGlobal = (recordData: Omit<MedicalRecord, 'id' | 'createdAt' | 'updatedAt'>) => {
    db.createMedicalRecord(recordData);
    notify({
      type: 'success',
      title: 'Medical Consultation Saved',
      message: 'Consultation diagnosis & treatment plan logged.',
    });
    setCurrentTab('records');
  };

  const dossierPet = activeDossierPetId ? db.getPetById(activeDossierPetId) || null : null;

  return (
    <div className="min-h-screen flex bg-[#F7F9F7] text-[#1F2923]">
      {/* Sidebar (Desktop & Mobile Drawer) */}
      <Sidebar
        currentTab={currentTab}
        onSelectTab={setCurrentTab}
        isMobileOpen={isMobileMenuOpen}
        onCloseMobile={() => setIsMobileMenuOpen(false)}
      />

      {/* Main Content Viewport */}
      <div className="flex-1 flex flex-col min-w-0">
        <Navbar
          currentTab={currentTab}
          onSelectTab={setCurrentTab}
          onOpenMobileMenu={() => setIsMobileMenuOpen(true)}
          onQuickAction={handleQuickAction}
        />

        <main className="flex-1 p-4 md:p-8 max-w-7xl w-full mx-auto">
          {currentTab === 'dashboard' && (
            <DashboardView
              onNavigate={setCurrentTab}
              onOpenQuickAction={handleQuickAction}
              onSelectPet={handleSelectPet}
            />
          )}

          {currentTab === 'pets' && (
            <PetManagementView
              onSelectOwner={handleSelectOwner}
              onScheduleAppointment={handleScheduleForPet}
              onNewMedicalRecord={handleRecordForPet}
            />
          )}

          {currentTab === 'owners' && (
            <OwnerManagementView onSelectPet={handleSelectPet} />
          )}

          {currentTab === 'appointments' && (
            <AppointmentManagementView
              onSelectPet={handleSelectPet}
              onSelectOwner={handleSelectOwner}
            />
          )}

          {currentTab === 'records' && (
            <MedicalRecordsView
              onSelectPet={handleSelectPet}
              onSelectOwner={handleSelectOwner}
            />
          )}

          {currentTab === 'settings' && <SettingsView />}
        </main>
      </div>

      {/* Global Pet Dossier Modal */}
      {dossierPet && (
        <PetDetailsModal
          pet={dossierPet}
          isOpen={!!activeDossierPetId}
          onClose={() => setActiveDossierPetId(null)}
          onEdit={() => {
            setActiveDossierPetId(null);
            setCurrentTab('pets');
          }}
          onDelete={(petToDelete) => {
            db.deletePet(petToDelete.id);
            setActiveDossierPetId(null);
            notify({
              type: 'info',
              title: 'Pet Deleted',
              message: `${petToDelete.name} was removed.`,
            });
          }}
          onSelectOwner={(ownerId) => {
            setActiveDossierPetId(null);
            setCurrentTab('owners');
          }}
          onNewAppointmentForPet={(petId) => {
            setActiveDossierPetId(null);
            handleScheduleForPet(petId);
          }}
          onNewMedicalRecordForPet={(petId) => {
            setActiveDossierPetId(null);
            handleRecordForPet(petId);
          }}
        />
      )}

      {/* Global Quick Action Modals */}
      <PetFormModal
        isOpen={isGlobalPetModalOpen}
        onClose={() => setIsGlobalPetModalOpen(false)}
        onSave={handleSavePetGlobal}
      />

      <OwnerFormModal
        isOpen={isGlobalOwnerModalOpen}
        onClose={() => setIsGlobalOwnerModalOpen(false)}
        onSave={handleSaveOwnerGlobal}
      />

      <AppointmentFormModal
        isOpen={isGlobalAppointmentModalOpen}
        defaultPetId={prefilledPetId}
        onClose={() => setIsGlobalAppointmentModalOpen(false)}
        onSave={handleSaveAppointmentGlobal}
      />

      <MedicalRecordFormModal
        isOpen={isGlobalRecordModalOpen}
        defaultPetId={prefilledPetId}
        onClose={() => setIsGlobalRecordModalOpen(false)}
        onSave={handleSaveRecordGlobal}
      />

      {/* Logout Confirmation Dialog */}
      <ConfirmationModal
        isOpen={isLogoutModalOpen}
        title="Sign Out of Sage & Paw?"
        message="Are you sure you want to end your current veterinary session? Any unsaved changes in open forms will be discarded."
        confirmLabel="Sign Out"
        isDestructive={false}
        onConfirm={logout}
        onCancel={() => setIsLogoutModalOpen(false)}
      />
    </div>
  );
};

export default function App() {
  return (
    <NotificationProvider>
      <AuthProvider>
        <MainLayout />
      </AuthProvider>
    </NotificationProvider>
  );
}
