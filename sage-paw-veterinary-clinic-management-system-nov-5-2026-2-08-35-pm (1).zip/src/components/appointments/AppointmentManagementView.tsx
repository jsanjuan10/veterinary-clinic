import React, { useState } from 'react';
import {
  CalendarDays,
  CalendarCheck,
  Search,
  Plus,
  Clock,
  CheckCircle,
  XCircle,
  Edit,
  Trash2,
  Calendar as CalendarIcon,
  ListFilter,
  Check,
  AlertCircle,
  ChevronLeft,
  ChevronRight,
  User,
  PawPrint,
  Stethoscope,
} from 'lucide-react';
import { Appointment, AppointmentStatus, Pet, PetOwner } from '../../types';
import { db } from '../../services/db';
import { useNotification } from '../../context/NotificationContext';
import { AppointmentFormModal } from './AppointmentFormModal';
import { ConfirmationModal } from '../common/ConfirmationModal';
import { EmptyState } from '../common/EmptyState';

interface AppointmentManagementViewProps {
  onSelectPet: (petId: string) => void;
  onSelectOwner: (ownerId: string) => void;
  onConsultationCompleted?: (appointment: Appointment) => void;
}

export const AppointmentManagementView: React.FC<AppointmentManagementViewProps> = ({
  onSelectPet,
  onSelectOwner,
  onConsultationCompleted,
}) => {
  const { notify } = useNotification();
  const [appointments, setAppointments] = useState<Appointment[]>(db.getAppointments());
  const [pets, setPets] = useState<Pet[]>(db.getPets());
  const [owners, setOwners] = useState<PetOwner[]>(db.getOwners());

  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('All');
  const [activeTab, setActiveTab] = useState<'list' | 'calendar' | 'daily'>('list');

  // Calendar month state
  const [currentDate, setCurrentDate] = useState<Date>(new Date());
  const [selectedCalendarDate, setSelectedCalendarDate] = useState<string>(
    new Date().toISOString().split('T')[0]
  );

  // Modals
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [appointmentToEdit, setAppointmentToEdit] = useState<Appointment | null>(null);
  const [appointmentToDelete, setAppointmentToDelete] = useState<Appointment | null>(null);

  const refreshData = () => {
    setAppointments(db.getAppointments());
    setPets(db.getPets());
    setOwners(db.getOwners());
  };

  const petMap = new Map<string, Pet>();
  pets.forEach((p) => petMap.set(p.id, p));

  const ownerMap = new Map<string, PetOwner>();
  owners.forEach((o) => ownerMap.set(o.id, o));

  const statusList = ['All', 'Confirmed', 'Pending', 'Completed', 'Cancelled'];

  const filteredAppointments = appointments.filter((apt) => {
    const pet = petMap.get(apt.petId);
    const owner = ownerMap.get(apt.ownerId);
    const term = searchTerm.toLowerCase();

    const matchesSearch =
      (pet && pet.name.toLowerCase().includes(term)) ||
      (owner && owner.fullName.toLowerCase().includes(term)) ||
      apt.reasonForVisit.toLowerCase().includes(term) ||
      apt.veterinarian.toLowerCase().includes(term) ||
      apt.id.toLowerCase().includes(term);

    const matchesStatus = statusFilter === 'All' ? true : apt.status === statusFilter;

    return matchesSearch && matchesStatus;
  });

  const handleOpenAdd = (datePrefill?: string) => {
    setAppointmentToEdit(null);
    if (datePrefill) {
      setSelectedCalendarDate(datePrefill);
    }
    setIsFormOpen(true);
  };

  const handleOpenEdit = (apt: Appointment) => {
    setAppointmentToEdit(apt);
    setIsFormOpen(true);
  };

  const handleSaveAppointment = (data: Omit<Appointment, 'id' | 'createdAt' | 'updatedAt'>) => {
    try {
      if (appointmentToEdit) {
        db.updateAppointment(appointmentToEdit.id, data);
        notify({
          type: 'success',
          title: 'Appointment Updated',
          message: `Consultation schedule updated for ${data.appointmentDate} at ${data.appointmentTime}.`,
        });
      } else {
        db.createAppointment(data);
        notify({
          type: 'success',
          title: 'Appointment Scheduled',
          message: `New appointment successfully booked for ${data.appointmentDate} at ${data.appointmentTime}.`,
        });
      }
      refreshData();
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Could not schedule appointment.';
      notify({ type: 'error', title: 'Schedule Failed', message: msg });
    }
  };

  const handleStatusChange = (apt: Appointment, newStatus: AppointmentStatus) => {
    try {
      db.updateAppointment(apt.id, { status: newStatus });
      notify({
        type: 'success',
        title: 'Status Updated',
        message: `Appointment marked as ${newStatus}.`,
      });
      refreshData();
    } catch {
      notify({ type: 'error', title: 'Update Error', message: 'Could not update status.' });
    }
  };

  const handleDeleteConfirm = () => {
    if (!appointmentToDelete) return;
    try {
      db.deleteAppointment(appointmentToDelete.id);
      notify({
        type: 'info',
        title: 'Appointment Removed',
        message: 'The scheduled booking was deleted from the calendar.',
      });
      setAppointmentToDelete(null);
      refreshData();
    } catch {
      notify({ type: 'error', title: 'Delete Failed', message: 'Could not remove appointment.' });
    }
  };

  // Calendar calculations
  const year = currentDate.getFullYear();
  const month = currentDate.getMonth();

  const firstDayOfMonth = new Date(year, month, 1).getDay();
  const daysInMonth = new Date(year, month + 1, 0).getDate();

  const prevMonth = () => {
    setCurrentDate(new Date(year, month - 1, 1));
  };

  const nextMonth = () => {
    setCurrentDate(new Date(year, month + 1, 1));
  };

  const monthNames = [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'
  ];

  // Daily timeline hours: 08:00 to 18:00
  const dailyHours = Array.from({ length: 11 }, (_, i) => i + 8);

  const getAppointmentsForDate = (dateStr: string) => {
    return appointments.filter((a) => a.appointmentDate === dateStr);
  };

  const statusColors: Record<AppointmentStatus, string> = {
    Pending: 'bg-[#FFF8EE] text-[#9A6216] border-[#F2D7B2]',
    Confirmed: 'bg-[#EDF7F0] text-[#2F683D] border-[#C2E4CD]',
    Completed: 'bg-[#F2F4F7] text-[#475467] border-[#D0D5DD]',
    Cancelled: 'bg-[#FEF3F2] text-[#B42318] border-[#FECDCA]',
  };

  return (
    <div className="space-y-6">
      {/* Top Controls Header */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 bg-white p-4 md:p-5 rounded-2xl border border-[#E2EAE4] shadow-sm">
        <div className="flex-1 flex flex-col sm:flex-row gap-3">
          {/* Search */}
          <div className="relative flex-1">
            <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-[#738879]">
              <Search className="w-4 h-4" />
            </div>
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search by pet, owner, doctor, or reason for visit..."
              className="w-full pl-10 pr-4 py-2 text-xs md:text-sm rounded-xl border border-[#D5E0D7] bg-[#FBFCFB] focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#4A7255]/20 focus:border-[#4A7255] transition-all text-[#1F2923]"
            />
          </div>

          {/* Status Filter */}
          <div className="flex items-center gap-1 p-1 bg-[#F0F4F1] rounded-xl overflow-x-auto">
            {statusList.map((st) => (
              <button
                key={st}
                onClick={() => setStatusFilter(st)}
                className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all whitespace-nowrap shrink-0 ${
                  statusFilter === st
                    ? 'bg-white text-[#253B2D] shadow-xs'
                    : 'text-[#586F60] hover:text-[#253B2D]'
                }`}
              >
                {st}
              </button>
            ))}
          </div>
        </div>

        {/* View Tabs & Schedule CTA */}
        <div className="flex items-center gap-2.5 shrink-0 justify-end">
          <div className="inline-flex items-center p-1 bg-[#F0F4F1] rounded-xl border border-[#DFE7E1]">
            <button
              onClick={() => setActiveTab('list')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all ${
                activeTab === 'list'
                  ? 'bg-white text-[#294231] shadow-xs'
                  : 'text-[#647C6B] hover:text-[#294231]'
              }`}
            >
              List View
            </button>
            <button
              onClick={() => setActiveTab('calendar')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all ${
                activeTab === 'calendar'
                  ? 'bg-white text-[#294231] shadow-xs'
                  : 'text-[#647C6B] hover:text-[#294231]'
              }`}
            >
              Month Calendar
            </button>
            <button
              onClick={() => setActiveTab('daily')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all ${
                activeTab === 'daily'
                  ? 'bg-white text-[#294231] shadow-xs'
                  : 'text-[#647C6B] hover:text-[#294231]'
              }`}
            >
              Daily Timeline
            </button>
          </div>

          <button
            onClick={() => handleOpenAdd()}
            className="inline-flex items-center gap-2 px-4 py-2 bg-[#4A7255] hover:bg-[#3C5D45] text-white text-xs font-semibold rounded-xl shadow-sm transition-all"
          >
            <Plus className="w-4 h-4" />
            <span>Schedule Appointment</span>
          </button>
        </div>
      </div>

      {/* 1. LIST VIEW */}
      {activeTab === 'list' && (
        <div className="space-y-4">
          {filteredAppointments.length === 0 ? (
            <EmptyState
              icon={CalendarDays}
              title="No appointments found"
              description="No clinical appointments match your current filters or date range."
              actionLabel="Schedule First Appointment"
              onAction={() => handleOpenAdd()}
            />
          ) : (
            <div className="bg-white rounded-2xl border border-[#E2EAE4] shadow-sm overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-[#F7FAF8] border-b border-[#E2EAE4] text-[#55695B] uppercase font-semibold text-[11px] tracking-wider">
                    <tr>
                      <th className="py-3.5 px-4">Date & Time</th>
                      <th className="py-3.5 px-4">Patient Pet</th>
                      <th className="py-3.5 px-4">Pet Owner</th>
                      <th className="py-3.5 px-4">Reason for Visit</th>
                      <th className="py-3.5 px-4">Attending Doctor</th>
                      <th className="py-3.5 px-4">Status</th>
                      <th className="py-3.5 px-4 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#EEF4F0]">
                    {filteredAppointments.map((apt) => {
                      const pet = petMap.get(apt.petId);
                      const owner = ownerMap.get(apt.ownerId);

                      return (
                        <tr key={apt.id} className="hover:bg-[#F9FAF9] transition-colors">
                          <td className="py-3.5 px-4">
                            <span className="font-bold text-[#1F2923] block font-mono">
                              {apt.appointmentDate}
                            </span>
                            <span className="text-[11px] text-[#697E70] font-mono flex items-center gap-1 mt-0.5">
                              <Clock className="w-3 h-3 text-[#4A7255]" />
                              {apt.appointmentTime}
                            </span>
                          </td>
                          <td className="py-3.5 px-4">
                            <button
                              onClick={() => pet && onSelectPet(pet.id)}
                              className="font-bold text-[#2A4232] hover:underline flex items-center gap-2 text-left"
                            >
                              {pet?.photoUrl ? (
                                <img
                                  src={pet.photoUrl}
                                  alt={pet.name}
                                  className="w-7 h-7 rounded-lg object-cover"
                                  referrerPolicy="no-referrer"
                                />
                              ) : (
                                <div className="w-7 h-7 rounded-lg bg-[#E8F0EA] text-[#4A7255] flex items-center justify-center font-bold text-xs">
                                  {pet?.name?.charAt(0) || 'P'}
                                </div>
                              )}
                              <div>
                                <span className="block leading-tight">{pet?.name || 'Pet'}</span>
                                <span className="text-[10px] text-[#718677] font-normal">
                                  {pet?.species} · {pet?.breed}
                                </span>
                              </div>
                            </button>
                          </td>
                          <td className="py-3.5 px-4">
                            <button
                              onClick={() => owner && onSelectOwner(owner.id)}
                              className="text-[#1F2923] hover:underline block text-left"
                            >
                              <span className="font-medium block">{owner?.fullName || '—'}</span>
                              <span className="text-[11px] text-[#697E70] font-mono">
                                {owner?.phoneNumber || ''}
                              </span>
                            </button>
                          </td>
                          <td className="py-3.5 px-4">
                            <span className="font-medium text-[#1F2923] block max-w-xs truncate">
                              {apt.reasonForVisit}
                            </span>
                            {apt.additionalNotes && (
                              <span className="text-[11px] text-[#718677] truncate block max-w-xs">
                                Note: {apt.additionalNotes}
                              </span>
                            )}
                          </td>
                          <td className="py-3.5 px-4 text-[#354A3B]">
                            {apt.veterinarian}
                          </td>
                          <td className="py-3.5 px-4">
                            <select
                              value={apt.status}
                              onChange={(e) =>
                                handleStatusChange(apt, e.target.value as AppointmentStatus)
                              }
                              className={`px-2.5 py-1 text-[11px] font-semibold rounded-lg border focus:outline-none cursor-pointer ${
                                statusColors[apt.status]
                              }`}
                            >
                              <option value="Confirmed">Confirmed</option>
                              <option value="Pending">Pending</option>
                              <option value="Completed">Completed</option>
                              <option value="Cancelled">Cancelled</option>
                            </select>
                          </td>
                          <td className="py-3.5 px-4 text-right">
                            <div className="flex items-center justify-end gap-1.5">
                              {apt.status !== 'Completed' && (
                                <button
                                  onClick={() => handleStatusChange(apt, 'Completed')}
                                  className="p-1.5 text-[#2E7D32] hover:bg-[#E8F5E9] rounded-lg transition-colors"
                                  title="Mark as Completed"
                                >
                                  <Check className="w-3.5 h-3.5" />
                                </button>
                              )}
                              <button
                                onClick={() => handleOpenEdit(apt)}
                                className="p-1.5 text-[#5B7162] hover:bg-[#EEF4EF] rounded-lg transition-colors"
                                title="Edit"
                              >
                                <Edit className="w-3.5 h-3.5" />
                              </button>
                              <button
                                onClick={() => setAppointmentToDelete(apt)}
                                className="p-1.5 text-[#B92A2A] hover:bg-[#FDF2F2] rounded-lg transition-colors"
                                title="Cancel & Delete"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      )}

      {/* 2. MONTHLY CALENDAR VIEW */}
      {activeTab === 'calendar' && (
        <div className="bg-white rounded-2xl border border-[#E2EAE4] p-6 shadow-sm space-y-4">
          {/* Calendar Month Navigation Header */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <h3 className="text-lg font-bold font-display text-[#1F2923]">
                {monthNames[month]} {year}
              </h3>
              <button
                onClick={() => {
                  const today = new Date();
                  setCurrentDate(today);
                  setSelectedCalendarDate(today.toISOString().split('T')[0]);
                }}
                className="px-2.5 py-1 text-xs font-semibold rounded-lg bg-[#EEF4EF] text-[#294231] hover:bg-[#E2ECE4] transition-colors"
              >
                Today
              </button>
            </div>

            <div className="flex items-center gap-1.5">
              <button
                onClick={prevMonth}
                className="p-1.5 rounded-lg border border-[#D5E0D7] hover:bg-[#F0F4F1] transition-colors"
                aria-label="Previous month"
              >
                <ChevronLeft className="w-4 h-4 text-[#55695B]" />
              </button>
              <button
                onClick={nextMonth}
                className="p-1.5 rounded-lg border border-[#D5E0D7] hover:bg-[#F0F4F1] transition-colors"
                aria-label="Next month"
              >
                <ChevronRight className="w-4 h-4 text-[#55695B]" />
              </button>
            </div>
          </div>

          {/* Day of Week Labels */}
          <div className="grid grid-cols-7 gap-2 text-center text-xs font-semibold text-[#5B7162] pb-2 border-b border-[#EEF4F0]">
            <div>Sun</div>
            <div>Mon</div>
            <div>Tue</div>
            <div>Wed</div>
            <div>Thu</div>
            <div>Fri</div>
            <div>Sat</div>
          </div>

          {/* 35/42 Days Grid */}
          <div className="grid grid-cols-7 gap-2">
            {/* Blank offset tiles for previous month */}
            {Array.from({ length: firstDayOfMonth }).map((_, i) => (
              <div key={`empty-${i}`} className="min-h-[90px] p-2 bg-[#FAFBFA] rounded-xl border border-transparent opacity-40" />
            ))}

            {/* Days in Month */}
            {Array.from({ length: daysInMonth }).map((_, i) => {
              const dayNum = i + 1;
              const dateStr = `${year}-${String(month + 1).padStart(2, '0')}-${String(dayNum).padStart(2, '0')}`;
              const dayAppointments = getAppointmentsForDate(dateStr);
              const isSelected = selectedCalendarDate === dateStr;
              const isToday = new Date().toISOString().split('T')[0] === dateStr;

              return (
                <div
                  key={dateStr}
                  onClick={() => setSelectedCalendarDate(dateStr)}
                  className={`min-h-[90px] p-2 rounded-xl border transition-all cursor-pointer flex flex-col justify-between ${
                    isSelected
                      ? 'border-[#4A7255] bg-[#F4F8F5] ring-2 ring-[#4A7255]/20 shadow-xs'
                      : isToday
                      ? 'border-[#B4D0BB] bg-[#FAFCFA]'
                      : 'border-[#E8EFEA] bg-white hover:border-[#CADACF]'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span
                      className={`text-xs font-bold font-mono ${
                        isToday
                          ? 'w-6 h-6 rounded-full bg-[#4A7255] text-white flex items-center justify-center'
                          : 'text-[#202E24]'
                      }`}
                    >
                      {dayNum}
                    </span>
                    {dayAppointments.length > 0 && (
                      <span className="text-[10px] font-semibold text-[#4A7255] bg-[#EAF2EC] px-1.5 py-0.5 rounded-md">
                        {dayAppointments.length}
                      </span>
                    )}
                  </div>

                  {/* Little Appointment Preview Chips */}
                  <div className="space-y-1 mt-1 overflow-hidden">
                    {dayAppointments.slice(0, 2).map((apt) => {
                      const pet = petMap.get(apt.petId);
                      return (
                        <div
                          key={apt.id}
                          className="px-1.5 py-0.5 text-[10px] rounded bg-white border border-[#E0EAE2] truncate text-[#294231] font-medium"
                          title={`${apt.appointmentTime} - ${pet?.name}: ${apt.reasonForVisit}`}
                        >
                          <span className="font-mono text-[#54735B]">{apt.appointmentTime}</span> {pet?.name}
                        </div>
                      );
                    })}
                    {dayAppointments.length > 2 && (
                      <span className="text-[9px] text-[#718778] font-medium block">
                        +{dayAppointments.length - 2} more
                      </span>
                    )}
                  </div>
                </div>
              );
            })}
          </div>

          {/* Selected Date Inspector Strip */}
          <div className="p-4 rounded-xl bg-[#F6FAF7] border border-[#E0EBE2] mt-4">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <CalendarIcon className="w-4 h-4 text-[#4A7255]" />
                <h4 className="text-xs font-bold text-[#1F2923]">
                  Consultations for {selectedCalendarDate} (
                  {getAppointmentsForDate(selectedCalendarDate).length})
                </h4>
              </div>
              <button
                onClick={() => handleOpenAdd(selectedCalendarDate)}
                className="text-xs font-semibold text-[#4A7255] hover:underline"
              >
                + Schedule for this day
              </button>
            </div>

            {getAppointmentsForDate(selectedCalendarDate).length === 0 ? (
              <p className="text-xs text-[#718677] py-2">
                No appointments booked for this date yet. Click above to schedule.
              </p>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {getAppointmentsForDate(selectedCalendarDate).map((apt) => {
                  const pet = petMap.get(apt.petId);
                  const owner = ownerMap.get(apt.ownerId);
                  return (
                    <div
                      key={apt.id}
                      className="p-3 bg-white rounded-xl border border-[#E3ECE5] flex items-center justify-between text-xs"
                    >
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-mono font-bold text-[#2A4232]">{apt.appointmentTime}</span>
                          <span className="font-bold text-[#1F2923]">{pet?.name}</span>
                          <span className="text-[10px] text-[#718677]">({pet?.species})</span>
                        </div>
                        <p className="text-[#55695C] truncate mt-0.5">{apt.reasonForVisit}</p>
                        <p className="text-[11px] text-[#7A8E80]">
                          Client: {owner?.fullName} · {apt.veterinarian}
                        </p>
                      </div>
                      <div className="flex items-center gap-1.5 shrink-0">
                        <span className={`px-2 py-0.5 text-[10px] font-semibold rounded-md border ${statusColors[apt.status]}`}>
                          {apt.status}
                        </span>
                        <button
                          onClick={() => handleOpenEdit(apt)}
                          className="p-1 text-[#55695B] hover:text-[#1F2923]"
                        >
                          <Edit className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      )}

      {/* 3. DAILY SCHEDULE TIMELINE VIEW */}
      {activeTab === 'daily' && (
        <div className="bg-white rounded-2xl border border-[#E2EAE4] p-6 shadow-sm space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-[#EEF4F0]">
            <div className="flex items-center gap-3">
              <CalendarIcon className="w-5 h-5 text-[#4A7255]" />
              <div>
                <h3 className="text-base font-bold font-display text-[#1F2923]">
                  Timeline Schedule: {selectedCalendarDate}
                </h3>
                <p className="text-xs text-[#63796A]">
                  Hourly operational calendar across examination rooms
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <input
                type="date"
                value={selectedCalendarDate}
                onChange={(e) => setSelectedCalendarDate(e.target.value)}
                className="px-3 py-1.5 rounded-xl border border-[#D5E0D7] text-xs font-mono"
              />
              <button
                onClick={() => handleOpenAdd(selectedCalendarDate)}
                className="px-3 py-1.5 bg-[#4A7255] text-white text-xs font-semibold rounded-xl"
              >
                + Book Slot
              </button>
            </div>
          </div>

          <div className="space-y-3 pt-2">
            {dailyHours.map((hour) => {
              const hourPrefix = `${String(hour).padStart(2, '0')}:`;
              const hourAppointments = appointments.filter(
                (a) =>
                  a.appointmentDate === selectedCalendarDate &&
                  a.appointmentTime.startsWith(hourPrefix.slice(0, 2))
              );

              return (
                <div
                  key={hour}
                  className="flex items-start gap-4 p-2.5 rounded-xl border border-[#EFF4F0] hover:bg-[#F9FAF9] transition-colors"
                >
                  <div className="w-16 font-mono text-xs font-semibold text-[#5B7162] pt-1">
                    {String(hour).padStart(2, '0')}:00
                  </div>

                  <div className="flex-1">
                    {hourAppointments.length === 0 ? (
                      <div className="text-[11px] text-[#A2B5A8] py-1">Available consultation slot</div>
                    ) : (
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                        {hourAppointments.map((apt) => {
                          const pet = petMap.get(apt.petId);
                          const owner = ownerMap.get(apt.ownerId);
                          return (
                            <div
                              key={apt.id}
                              className="p-3 bg-[#F6FAF7] border border-[#D8E6DB] rounded-xl flex items-center justify-between text-xs"
                            >
                              <div>
                                <div className="flex items-center gap-2">
                                  <span className="font-mono font-bold text-[#2A4232]">
                                    {apt.appointmentTime}
                                  </span>
                                  <span className="font-bold text-[#1F2923]">{pet?.name}</span>
                                  <span className="text-[11px] text-[#55695C]">
                                    ({pet?.species})
                                  </span>
                                </div>
                                <p className="text-[#324536] mt-0.5">{apt.reasonForVisit}</p>
                                <p className="text-[10px] text-[#718677]">
                                  {owner?.fullName} · {apt.veterinarian}
                                </p>
                              </div>

                              <div className="flex items-center gap-1.5">
                                <span className={`px-2 py-0.5 text-[10px] font-semibold rounded-md border ${statusColors[apt.status]}`}>
                                  {apt.status}
                                </span>
                                <button
                                  onClick={() => handleOpenEdit(apt)}
                                  className="p-1 text-[#55695B] hover:text-[#1F2923]"
                                >
                                  <Edit className="w-3.5 h-3.5" />
                                </button>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Appointment Form Modal */}
      <AppointmentFormModal
        isOpen={isFormOpen}
        appointmentToEdit={appointmentToEdit}
        defaultDate={selectedCalendarDate}
        onClose={() => setIsFormOpen(false)}
        onSave={handleSaveAppointment}
      />

      {/* Confirmation Modal for Delete/Cancel */}
      <ConfirmationModal
        isOpen={!!appointmentToDelete}
        title="Cancel & Delete Appointment?"
        message="Are you sure you want to remove this appointment booking from the clinic schedule?"
        confirmLabel="Delete Appointment"
        isDestructive={true}
        onConfirm={handleDeleteConfirm}
        onCancel={() => setAppointmentToDelete(null)}
      />
    </div>
  );
};
