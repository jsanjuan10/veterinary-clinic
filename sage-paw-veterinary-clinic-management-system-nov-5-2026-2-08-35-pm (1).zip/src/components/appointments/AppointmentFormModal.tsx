import React, { useState, useEffect } from 'react';
import { X, CalendarDays, Clock, User, PawPrint, Stethoscope } from 'lucide-react';
import { Appointment, AppointmentStatus, Pet, PetOwner } from '../../types';
import { db } from '../../services/db';

interface AppointmentFormModalProps {
  isOpen: boolean;
  appointmentToEdit?: Appointment | null;
  defaultPetId?: string;
  defaultDate?: string;
  onClose: () => void;
  onSave: (data: Omit<Appointment, 'id' | 'createdAt' | 'updatedAt'>) => void;
}

const VISIT_REASONS = [
  'Annual Wellness & Vaccinations',
  'Routine Follow-up & Weight Check',
  'Dental Examination & Cleaning',
  'Dermatology & Allergy Evaluation',
  'Post-Surgery Checkup',
  'Avian/Exotic Wellness Exam',
  'Diagnostic Bloodwork & Urinalysis',
  'Microchipping & ID Registration',
  'Acute Illness / Lethargy Check',
];

const TIME_SLOTS = [
  '08:30', '09:00', '09:30', '10:00', '10:30', '11:00', '11:30',
  '13:00', '13:30', '14:00', '14:30', '15:00', '15:30', '16:00', '16:30', '17:00'
];

export const AppointmentFormModal: React.FC<AppointmentFormModalProps> = ({
  isOpen,
  appointmentToEdit,
  defaultPetId,
  defaultDate,
  onClose,
  onSave,
}) => {
  const [petId, setPetId] = useState('');
  const [ownerId, setOwnerId] = useState('');
  const [appointmentDate, setAppointmentDate] = useState('');
  const [appointmentTime, setAppointmentTime] = useState('09:30');
  const [veterinarian, setVeterinarian] = useState('Dr. Sophia Jenkins, DVM');
  const [reasonForVisit, setReasonForVisit] = useState('');
  const [additionalNotes, setAdditionalNotes] = useState('');
  const [status, setStatus] = useState<AppointmentStatus>('Confirmed');
  const [errorMsg, setErrorMsg] = useState('');

  const pets = db.getPets();
  const owners = db.getOwners();
  const users = db.getUsers().filter((u) => u.role === 'veterinarian');

  useEffect(() => {
    if (appointmentToEdit) {
      setPetId(appointmentToEdit.petId);
      setOwnerId(appointmentToEdit.ownerId);
      setAppointmentDate(appointmentToEdit.appointmentDate);
      setAppointmentTime(appointmentToEdit.appointmentTime);
      setVeterinarian(appointmentToEdit.veterinarian);
      setReasonForVisit(appointmentToEdit.reasonForVisit);
      setAdditionalNotes(appointmentToEdit.additionalNotes || '');
      setStatus(appointmentToEdit.status);
    } else {
      const initialPetId = defaultPetId || (pets[0] ? pets[0].id : '');
      const initialPet = pets.find((p) => p.id === initialPetId);
      setPetId(initialPetId);
      setOwnerId(initialPet ? initialPet.ownerId : (owners[0] ? owners[0].id : ''));

      // Date defaults to today or defaultDate
      const today = new Date().toISOString().split('T')[0];
      setAppointmentDate(defaultDate || today);
      setAppointmentTime('10:00');
      setVeterinarian(users[0]?.fullName || 'Dr. Sophia Jenkins, DVM');
      setReasonForVisit('Annual Wellness & Vaccinations');
      setAdditionalNotes('');
      setStatus('Confirmed');
    }
    setErrorMsg('');
  }, [appointmentToEdit, isOpen, defaultPetId, defaultDate]);

  if (!isOpen) return null;

  const handlePetChange = (newPetId: string) => {
    setPetId(newPetId);
    const pet = pets.find((p) => p.id === newPetId);
    if (pet) {
      setOwnerId(pet.ownerId);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!petId) {
      setErrorMsg('Please select a pet patient.');
      return;
    }
    if (!ownerId) {
      setErrorMsg('Please assign an owner.');
      return;
    }
    if (!appointmentDate) {
      setErrorMsg('Please choose an appointment date.');
      return;
    }
    if (!appointmentTime) {
      setErrorMsg('Please select an appointment time.');
      return;
    }
    if (!reasonForVisit.trim()) {
      setErrorMsg('Please specify the reason for visit.');
      return;
    }

    onSave({
      petId,
      ownerId,
      appointmentDate,
      appointmentTime,
      veterinarian,
      reasonForVisit: reasonForVisit.trim(),
      additionalNotes: additionalNotes.trim() || undefined,
      status,
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/45 backdrop-blur-[2px] overflow-y-auto">
      <div className="bg-white rounded-2xl max-w-xl w-full shadow-2xl border border-[#DCE4DF] max-h-[92vh] flex flex-col overflow-hidden animate-in fade-in zoom-in-95 my-auto">
        <div className="p-5 border-b border-[#E8EFEA] flex items-center justify-between bg-[#F8FAF8]">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#E8F0EA] text-[#3E6548] flex items-center justify-center font-bold">
              <CalendarDays className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold font-display text-[#1F2923]">
                {appointmentToEdit ? 'Reschedule / Edit Appointment' : 'Schedule New Appointment'}
              </h3>
              <p className="text-xs text-[#5D7063]">
                Verify patient, attending veterinarian, and clinical purpose
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-[#738879] hover:text-[#1E2820] hover:bg-[#EAEFEA] rounded-xl"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 overflow-y-auto space-y-4 flex-1 text-xs text-[#1F2923]">
          {errorMsg && (
            <div className="p-3 bg-[#FDF2F2] border border-[#F8D7DA] text-[#9E2A2B] rounded-xl">
              {errorMsg}
            </div>
          )}

          {/* Pet & Owner Selectors */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block font-semibold mb-1 text-[#2D3A31]">Select Pet Patient *</label>
              <select
                required
                value={petId}
                onChange={(e) => handlePetChange(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-[#D5E0D7] bg-[#FBFCFB] focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#4A7255]"
              >
                <option value="">-- Choose Patient --</option>
                {pets.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.name} ({p.species} - {p.breed})
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block font-semibold mb-1 text-[#2D3A31]">Pet Owner *</label>
              <select
                required
                value={ownerId}
                onChange={(e) => setOwnerId(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-[#D5E0D7] bg-[#FBFCFB] focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#4A7255]"
              >
                <option value="">-- Assigned Owner --</option>
                {owners.map((o) => (
                  <option key={o.id} value={o.id}>
                    {o.fullName} ({o.phoneNumber})
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Date & Time */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block font-semibold mb-1 text-[#2D3A31]">Appointment Date *</label>
              <input
                type="date"
                required
                value={appointmentDate}
                onChange={(e) => setAppointmentDate(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-[#D5E0D7] bg-[#FBFCFB] focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#4A7255]"
              />
            </div>

            <div>
              <label className="block font-semibold mb-1 text-[#2D3A31]">Appointment Time *</label>
              <select
                required
                value={appointmentTime}
                onChange={(e) => setAppointmentTime(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-[#D5E0D7] bg-[#FBFCFB] focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#4A7255]"
              >
                {TIME_SLOTS.map((t) => (
                  <option key={t} value={t}>
                    {t}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Attending Veterinarian */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block font-semibold mb-1 text-[#2D3A31]">Attending Veterinarian *</label>
              <select
                required
                value={veterinarian}
                onChange={(e) => setVeterinarian(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-[#D5E0D7] bg-[#FBFCFB] focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#4A7255]"
              >
                {users.map((u) => (
                  <option key={u.id} value={u.fullName}>
                    {u.fullName}
                  </option>
                ))}
                {users.length === 0 && (
                  <option value="Attending Veterinarian">Attending Veterinarian</option>
                )}
              </select>
            </div>

            <div>
              <label className="block font-semibold mb-1 text-[#2D3A31]">Appointment Status *</label>
              <select
                value={status}
                onChange={(e) => setStatus(e.target.value as AppointmentStatus)}
                className="w-full px-3 py-2 rounded-xl border border-[#D5E0D7] bg-[#FBFCFB] focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#4A7255]"
              >
                <option value="Confirmed">Confirmed</option>
                <option value="Pending">Pending Check-in</option>
                <option value="Completed">Completed</option>
                <option value="Cancelled">Cancelled</option>
              </select>
            </div>
          </div>

          {/* Reason for Visit */}
          <div>
            <label className="block font-semibold mb-1 text-[#2D3A31]">Reason for Visit *</label>
            <input
              type="text"
              required
              value={reasonForVisit}
              onChange={(e) => setReasonForVisit(e.target.value)}
              placeholder="e.g. Annual Wellness & Vaccinations"
              className="w-full px-3 py-2 rounded-xl border border-[#D5E0D7] bg-[#FBFCFB] focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#4A7255] mb-2"
            />
            {/* Quick Reason Suggestions */}
            <div className="flex flex-wrap gap-1.5">
              {VISIT_REASONS.slice(0, 5).map((r) => (
                <button
                  type="button"
                  key={r}
                  onClick={() => setReasonForVisit(r)}
                  className="px-2 py-0.5 rounded-md bg-[#EEF3EF] hover:bg-[#E2ECE4] text-[#34513C] text-[11px] font-medium transition-colors"
                >
                  {r}
                </button>
              ))}
            </div>
          </div>

          {/* Additional Notes */}
          <div>
            <label className="block font-semibold mb-1 text-[#2D3A31]">Clinical / Arrival Notes</label>
            <textarea
              rows={2}
              value={additionalNotes}
              onChange={(e) => setAdditionalNotes(e.target.value)}
              placeholder="Client symptoms, fasting requirements, medication refill requests..."
              className="w-full px-3 py-2 rounded-xl border border-[#D5E0D7] bg-[#FBFCFB] focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#4A7255]"
            />
          </div>

          <div className="pt-3 border-t border-[#E8EFEA] flex items-center justify-end gap-2.5">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-[#EEF3EF] hover:bg-[#E3ECE5] text-[#2F4134] font-semibold rounded-xl"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 bg-[#4A7255] hover:bg-[#3C5D45] text-white font-semibold rounded-xl shadow-sm transition-all"
            >
              {appointmentToEdit ? 'Update Booking' : 'Confirm & Schedule Appointment'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
