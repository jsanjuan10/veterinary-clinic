import React, { useState, useEffect } from 'react';
import { X, PawPrint, Upload, Image, Sparkles } from 'lucide-react';
import { Pet, PetSpecies, PetGender, PetOwner } from '../../types';
import { db } from '../../services/db';

interface PetFormModalProps {
  isOpen: boolean;
  petToEdit?: Pet | null;
  defaultOwnerId?: string;
  onClose: () => void;
  onSave: (petData: Omit<Pet, 'id' | 'createdAt' | 'updatedAt'>) => void;
}

const PRESET_PHOTOS = [
  { label: 'Golden Retriever Dog', url: '/src/assets/images/vet_clinic_hero_1793857119970.jpg' },
  { label: 'Tabby Cat Care', url: '/src/assets/images/vet_pet_care_1793857120930.jpg' },
  { label: 'Maine Coon Cat', url: 'https://images.unsplash.com/photo-1533738363-b7f9aef128ce?w=400&auto=format&fit=crop&q=80' },
  { label: 'French Bulldog', url: 'https://images.unsplash.com/photo-1583511655857-d19b40a7a54e?w=400&auto=format&fit=crop&q=80' },
  { label: 'Holland Lop Rabbit', url: 'https://images.unsplash.com/photo-1585110396000-c9ffd4e4b308?w=400&auto=format&fit=crop&q=80' },
  { label: 'Cockatiel Bird', url: 'https://images.unsplash.com/photo-1522858547137-f1dcec554f55?w=400&auto=format&fit=crop&q=80' },
];

export const PetFormModal: React.FC<PetFormModalProps> = ({
  isOpen,
  petToEdit,
  defaultOwnerId,
  onClose,
  onSave,
}) => {
  const [name, setName] = useState('');
  const [species, setSpecies] = useState<PetSpecies>('Dog');
  const [breed, setBreed] = useState('');
  const [gender, setGender] = useState<PetGender>('Male');
  const [ageYears, setAgeYears] = useState<number>(1);
  const [ageMonths, setAgeMonths] = useState<number>(0);
  const [dateOfBirth, setDateOfBirth] = useState('');
  const [color, setColor] = useState('');
  const [weight, setWeight] = useState<number>(5.0);
  const [microchipNumber, setMicrochipNumber] = useState('');
  const [allergiesText, setAllergiesText] = useState('');
  const [specialNotes, setSpecialNotes] = useState('');
  const [photoUrl, setPhotoUrl] = useState('');
  const [ownerId, setOwnerId] = useState('');
  const [errorMsg, setErrorMsg] = useState('');

  const owners = db.getOwners();

  useEffect(() => {
    if (petToEdit) {
      setName(petToEdit.name);
      setSpecies(petToEdit.species);
      setBreed(petToEdit.breed);
      setGender(petToEdit.gender);
      setAgeYears(petToEdit.ageYears);
      setAgeMonths(petToEdit.ageMonths);
      setDateOfBirth(petToEdit.dateOfBirth);
      setColor(petToEdit.color);
      setWeight(petToEdit.weight);
      setMicrochipNumber(petToEdit.microchipNumber || '');
      setAllergiesText((petToEdit.allergies || []).join(', '));
      setSpecialNotes(petToEdit.specialNotes || '');
      setPhotoUrl(petToEdit.photoUrl || '');
      setOwnerId(petToEdit.ownerId);
    } else {
      setName('');
      setSpecies('Dog');
      setBreed('');
      setGender('Male');
      setAgeYears(2);
      setAgeMonths(0);
      setDateOfBirth('2024-01-01');
      setColor('');
      setWeight(10);
      setMicrochipNumber('');
      setAllergiesText('');
      setSpecialNotes('');
      setPhotoUrl(PRESET_PHOTOS[0].url);
      setOwnerId(defaultOwnerId || (owners[0] ? owners[0].id : ''));
    }
    setErrorMsg('');
  }, [petToEdit, isOpen, defaultOwnerId]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      setErrorMsg('Please enter the pet name.');
      return;
    }
    if (!breed.trim()) {
      setErrorMsg('Please specify the breed.');
      return;
    }
    if (!ownerId) {
      setErrorMsg('Please assign a registered pet owner.');
      return;
    }

    const allergies = allergiesText
      .split(',')
      .map((s) => s.trim())
      .filter((s) => s.length > 0);

    onSave({
      name: name.trim(),
      species,
      breed: breed.trim(),
      gender,
      ageYears: Number(ageYears) || 0,
      ageMonths: Number(ageMonths) || 0,
      dateOfBirth,
      color: color.trim(),
      weight: Number(weight) || 1,
      microchipNumber: microchipNumber.trim() || undefined,
      allergies,
      specialNotes: specialNotes.trim() || undefined,
      photoUrl: photoUrl.trim() || undefined,
      ownerId,
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/45 backdrop-blur-[2px] overflow-y-auto">
      <div className="bg-white rounded-2xl max-w-2xl w-full shadow-2xl border border-[#DCE4DF] max-h-[92vh] flex flex-col overflow-hidden animate-in fade-in zoom-in-95 my-auto">
        {/* Header */}
        <div className="p-5 border-b border-[#E8EFEA] flex items-center justify-between bg-[#F8FAF8]">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#E8F0EA] text-[#3E6548] flex items-center justify-center font-bold">
              <PawPrint className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold font-display text-[#1F2923]">
                {petToEdit ? `Edit Patient: ${petToEdit.name}` : 'Register New Pet Patient'}
              </h3>
              <p className="text-xs text-[#5D7063]">
                {petToEdit ? 'Update clinical and identity records' : 'Enter complete details for clinic intake'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-[#738879] hover:text-[#1E2820] hover:bg-[#EAEFEA] rounded-xl"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 overflow-y-auto space-y-4 flex-1 text-xs text-[#1F2923]">
          {errorMsg && (
            <div className="p-3 bg-[#FDF2F2] border border-[#F8D7DA] text-[#9E2A2B] rounded-xl">
              {errorMsg}
            </div>
          )}

          {/* Row 1: Name & Species */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block font-semibold mb-1 text-[#2D3A31]">Pet Name *</label>
              <input
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g. Bella"
                className="w-full px-3 py-2 rounded-xl border border-[#D5E0D7] bg-[#FBFCFB] focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#4A7255]"
              />
            </div>
            <div>
              <label className="block font-semibold mb-1 text-[#2D3A31]">Species *</label>
              <select
                value={species}
                onChange={(e) => setSpecies(e.target.value as PetSpecies)}
                className="w-full px-3 py-2 rounded-xl border border-[#D5E0D7] bg-[#FBFCFB] focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#4A7255]"
              >
                <option value="Dog">Dog (Canine)</option>
                <option value="Cat">Cat (Feline)</option>
                <option value="Bird">Bird (Avian)</option>
                <option value="Rabbit">Rabbit (Lagomorph)</option>
                <option value="Hamster">Hamster / Small Rodent</option>
                <option value="Reptile">Reptile</option>
                <option value="Other">Other Species</option>
              </select>
            </div>
          </div>

          {/* Row 2: Breed & Gender */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block font-semibold mb-1 text-[#2D3A31]">Breed *</label>
              <input
                type="text"
                required
                value={breed}
                onChange={(e) => setBreed(e.target.value)}
                placeholder="e.g. Golden Retriever"
                className="w-full px-3 py-2 rounded-xl border border-[#D5E0D7] bg-[#FBFCFB] focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#4A7255]"
              />
            </div>
            <div>
              <label className="block font-semibold mb-1 text-[#2D3A31]">Gender *</label>
              <select
                value={gender}
                onChange={(e) => setGender(e.target.value as PetGender)}
                className="w-full px-3 py-2 rounded-xl border border-[#D5E0D7] bg-[#FBFCFB] focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#4A7255]"
              >
                <option value="Male">Male</option>
                <option value="Female">Female</option>
                <option value="Unknown">Unknown / Not Determined</option>
              </select>
            </div>
          </div>

          {/* Row 3: Age & Date of Birth */}
          <div className="grid grid-cols-3 gap-3">
            <div>
              <label className="block font-semibold mb-1 text-[#2D3A31]">Age (Years)</label>
              <input
                type="number"
                min="0"
                max="50"
                value={ageYears}
                onChange={(e) => setAgeYears(parseInt(e.target.value) || 0)}
                className="w-full px-3 py-2 rounded-xl border border-[#D5E0D7] bg-[#FBFCFB] focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#4A7255]"
              />
            </div>
            <div>
              <label className="block font-semibold mb-1 text-[#2D3A31]">Age (Months)</label>
              <input
                type="number"
                min="0"
                max="11"
                value={ageMonths}
                onChange={(e) => setAgeMonths(parseInt(e.target.value) || 0)}
                className="w-full px-3 py-2 rounded-xl border border-[#D5E0D7] bg-[#FBFCFB] focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#4A7255]"
              />
            </div>
            <div>
              <label className="block font-semibold mb-1 text-[#2D3A31]">Date of Birth</label>
              <input
                type="date"
                value={dateOfBirth}
                onChange={(e) => setDateOfBirth(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-[#D5E0D7] bg-[#FBFCFB] focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#4A7255]"
              />
            </div>
          </div>

          {/* Row 4: Weight, Color, Microchip */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="block font-semibold mb-1 text-[#2D3A31]">Weight (kg) *</label>
              <input
                type="number"
                step="0.01"
                min="0.01"
                required
                value={weight}
                onChange={(e) => setWeight(parseFloat(e.target.value) || 0)}
                className="w-full px-3 py-2 rounded-xl border border-[#D5E0D7] bg-[#FBFCFB] focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#4A7255]"
              />
            </div>
            <div>
              <label className="block font-semibold mb-1 text-[#2D3A31]">Coat Color / Markings</label>
              <input
                type="text"
                value={color}
                onChange={(e) => setColor(e.target.value)}
                placeholder="e.g. Honey Cream"
                className="w-full px-3 py-2 rounded-xl border border-[#D5E0D7] bg-[#FBFCFB] focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#4A7255]"
              />
            </div>
            <div>
              <label className="block font-semibold mb-1 text-[#2D3A31]">Microchip ID</label>
              <input
                type="text"
                value={microchipNumber}
                onChange={(e) => setMicrochipNumber(e.target.value)}
                placeholder="e.g. 985141002348911"
                className="w-full px-3 py-2 rounded-xl border border-[#D5E0D7] bg-[#FBFCFB] focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#4A7255]"
              />
            </div>
          </div>

          {/* Row 5: Owner Selector */}
          <div>
            <label className="block font-semibold mb-1 text-[#2D3A31]">
              Assigned Pet Owner *
            </label>
            <select
              required
              value={ownerId}
              onChange={(e) => setOwnerId(e.target.value)}
              className="w-full px-3 py-2 rounded-xl border border-[#D5E0D7] bg-[#FBFCFB] focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#4A7255]"
            >
              <option value="">-- Select Registered Owner --</option>
              {owners.map((o) => (
                <option key={o.id} value={o.id}>
                  {o.fullName} ({o.phoneNumber})
                </option>
              ))}
            </select>
          </div>

          {/* Row 6: Allergies & Notes */}
          <div>
            <label className="block font-semibold mb-1 text-[#2D3A31]">
              Known Allergies (comma-separated)
            </label>
            <input
              type="text"
              value={allergiesText}
              onChange={(e) => setAllergiesText(e.target.value)}
              placeholder="e.g. Chicken poultry proteins, Flea saliva, Dairy"
              className="w-full px-3 py-2 rounded-xl border border-[#D5E0D7] bg-[#FBFCFB] focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#4A7255]"
            />
          </div>

          <div>
            <label className="block font-semibold mb-1 text-[#2D3A31]">
              Special Clinical / Behavioral Notes
            </label>
            <textarea
              rows={2}
              value={specialNotes}
              onChange={(e) => setSpecialNotes(e.target.value)}
              placeholder="Special handling needs, behavioral temperament, dietary instructions..."
              className="w-full px-3 py-2 rounded-xl border border-[#D5E0D7] bg-[#FBFCFB] focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#4A7255]"
            />
          </div>

          {/* Photo Preset Selection */}
          <div>
            <label className="block font-semibold mb-1 text-[#2D3A31]">
              Pet Photo Avatar (Select preset or enter URL)
            </label>
            <div className="flex items-center gap-2 mb-2 overflow-x-auto pb-1">
              {PRESET_PHOTOS.map((preset, idx) => (
                <button
                  type="button"
                  key={idx}
                  onClick={() => setPhotoUrl(preset.url)}
                  className={`p-1 rounded-xl border transition-all shrink-0 ${
                    photoUrl === preset.url
                      ? 'border-[#4A7255] ring-2 ring-[#4A7255]/30'
                      : 'border-[#D5E0D7] opacity-75 hover:opacity-100'
                  }`}
                >
                  <img
                    src={preset.url}
                    alt={preset.label}
                    className="w-12 h-12 rounded-lg object-cover"
                    referrerPolicy="no-referrer"
                  />
                </button>
              ))}
            </div>
            <input
              type="text"
              value={photoUrl}
              onChange={(e) => setPhotoUrl(e.target.value)}
              placeholder="Or enter image URL https://..."
              className="w-full px-3 py-2 rounded-xl border border-[#D5E0D7] bg-[#FBFCFB] focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#4A7255]"
            />
          </div>

          <div className="pt-3 border-t border-[#E8EFEA] flex items-center justify-end gap-2.5">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-[#EEF3EF] hover:bg-[#E3ECE5] text-[#2F4134] font-semibold rounded-xl"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 bg-[#4A7255] hover:bg-[#3C5D45] text-white font-semibold rounded-xl shadow-sm transition-all"
            >
              {petToEdit ? 'Save Changes' : 'Register Pet'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
