import React, { useState } from 'react';
import {
  PawPrint,
  Search,
  Plus,
  LayoutGrid,
  Table as TableIcon,
  Filter,
  Eye,
  Edit,
  Trash2,
  Calendar,
  Heart,
  ChevronRight,
  Sparkles,
} from 'lucide-react';
import { Pet, PetSpecies, PetOwner } from '../../types';
import { db } from '../../services/db';
import { useNotification } from '../../context/NotificationContext';
import { PetDetailsModal } from './PetDetailsModal';
import { PetFormModal } from './PetFormModal';
import { ConfirmationModal } from '../common/ConfirmationModal';
import { EmptyState } from '../common/EmptyState';

interface PetManagementViewProps {
  onSelectOwner: (ownerId: string) => void;
  onScheduleAppointment: (petId: string) => void;
  onNewMedicalRecord: (petId: string) => void;
}

export const PetManagementView: React.FC<PetManagementViewProps> = ({
  onSelectOwner,
  onScheduleAppointment,
  onNewMedicalRecord,
}) => {
  const { notify } = useNotification();
  const [pets, setPets] = useState<Pet[]>(db.getPets());
  const [owners, setOwners] = useState<PetOwner[]>(db.getOwners());

  const [searchTerm, setSearchTerm] = useState('');
  const [speciesFilter, setSpeciesFilter] = useState<string>('All');
  const [viewMode, setViewMode] = useState<'grid' | 'table'>('grid');

  // Modal states
  const [selectedPet, setSelectedPet] = useState<Pet | null>(null);
  const [isDetailsOpen, setIsDetailsOpen] = useState(false);
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [petToEdit, setPetToEdit] = useState<Pet | null>(null);
  const [petToDelete, setPetToDelete] = useState<Pet | null>(null);

  const refreshData = () => {
    setPets(db.getPets());
    setOwners(db.getOwners());
  };

  const ownerMap = new Map<string, PetOwner>();
  owners.forEach((o) => ownerMap.set(o.id, o));

  const speciesList = ['All', 'Dog', 'Cat', 'Bird', 'Rabbit', 'Other'];

  const filteredPets = pets.filter((pet) => {
    const owner = ownerMap.get(pet.ownerId);
    const searchLower = searchTerm.toLowerCase();
    const matchesSearch =
      pet.name.toLowerCase().includes(searchLower) ||
      pet.breed.toLowerCase().includes(searchLower) ||
      pet.species.toLowerCase().includes(searchLower) ||
      (pet.microchipNumber && pet.microchipNumber.toLowerCase().includes(searchLower)) ||
      (owner && owner.fullName.toLowerCase().includes(searchLower));

    const matchesSpecies =
      speciesFilter === 'All'
        ? true
        : speciesFilter === 'Other'
        ? !['Dog', 'Cat', 'Bird', 'Rabbit'].includes(pet.species)
        : pet.species === speciesFilter;

    return matchesSearch && matchesSpecies;
  });

  const handleOpenAdd = () => {
    setPetToEdit(null);
    setIsFormOpen(true);
  };

  const handleOpenEdit = (pet: Pet) => {
    setPetToEdit(pet);
    setIsFormOpen(true);
  };

  const handleSavePet = (petData: Omit<Pet, 'id' | 'createdAt' | 'updatedAt'>) => {
    try {
      if (petToEdit) {
        db.updatePet(petToEdit.id, petData);
        notify({
          type: 'success',
          title: 'Pet Record Updated',
          message: `Changes to ${petData.name} have been saved successfully.`,
        });
      } else {
        db.createPet(petData);
        notify({
          type: 'success',
          title: 'Pet Patient Registered',
          message: `${petData.name} has been added to the clinical directory.`,
        });
      }
      refreshData();
      if (selectedPet && petToEdit && selectedPet.id === petToEdit.id) {
        setSelectedPet(db.getPetById(selectedPet.id) || null);
      }
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Failed to save pet record.';
      notify({ type: 'error', title: 'Action Failed', message: msg });
    }
  };

  const handleDeletePetConfirm = () => {
    if (!petToDelete) return;
    try {
      db.deletePet(petToDelete.id);
      notify({
        type: 'info',
        title: 'Pet Removed',
        message: `${petToDelete.name} and associated appointment logs were removed.`,
      });
      setPetToDelete(null);
      setIsDetailsOpen(false);
      refreshData();
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Could not delete pet.';
      notify({ type: 'error', title: 'Delete Failed', message: msg });
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Controls Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white p-4 md:p-5 rounded-2xl border border-[#E2EAE4] shadow-sm">
        <div className="flex-1 flex flex-col sm:flex-row gap-3">
          {/* Search Bar */}
          <div className="relative flex-1">
            <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-[#738879]">
              <Search className="w-4 h-4" />
            </div>
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search pets by name, breed, species, owner or microchip..."
              className="w-full pl-10 pr-4 py-2 text-xs md:text-sm rounded-xl border border-[#D5E0D7] bg-[#FBFCFB] focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#4A7255]/20 focus:border-[#4A7255] transition-all text-[#1F2923]"
            />
          </div>

          {/* Species Filter Tabs */}
          <div className="flex items-center gap-1 p-1 bg-[#F0F4F1] rounded-xl overflow-x-auto">
            {speciesList.map((sp) => (
              <button
                key={sp}
                onClick={() => setSpeciesFilter(sp)}
                className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all whitespace-nowrap shrink-0 ${
                  speciesFilter === sp
                    ? 'bg-white text-[#253B2D] shadow-xs'
                    : 'text-[#586F60] hover:text-[#253B2D]'
                }`}
              >
                {sp}
              </button>
            ))}
          </div>
        </div>

        {/* View Toggle & New Pet Button */}
        <div className="flex items-center gap-2.5 shrink-0 justify-end">
          <div className="inline-flex items-center p-1 bg-[#F0F4F1] rounded-xl border border-[#DFE7E1]">
            <button
              onClick={() => setViewMode('grid')}
              className={`p-1.5 rounded-lg transition-all ${
                viewMode === 'grid'
                  ? 'bg-white text-[#294231] shadow-xs'
                  : 'text-[#647C6B] hover:text-[#294231]'
              }`}
              title="Grid View"
            >
              <LayoutGrid className="w-4 h-4" />
            </button>
            <button
              onClick={() => setViewMode('table')}
              className={`p-1.5 rounded-lg transition-all ${
                viewMode === 'table'
                  ? 'bg-white text-[#294231] shadow-xs'
                  : 'text-[#647C6B] hover:text-[#294231]'
              }`}
              title="Table View"
            >
              <TableIcon className="w-4 h-4" />
            </button>
          </div>

          <button
            onClick={handleOpenAdd}
            className="inline-flex items-center gap-2 px-4 py-2 bg-[#4A7255] hover:bg-[#3C5D45] text-white text-xs font-semibold rounded-xl shadow-sm transition-all"
          >
            <Plus className="w-4 h-4" />
            <span>Add New Pet</span>
          </button>
        </div>
      </div>

      {/* Main Content Area */}
      {filteredPets.length === 0 ? (
        <EmptyState
          icon={PawPrint}
          title="No pet patients found"
          description={
            searchTerm || speciesFilter !== 'All'
              ? 'Try adjusting your search criteria or species filter.'
              : 'There are currently no pets registered in the clinic database.'
          }
          actionLabel="Register First Pet"
          onAction={handleOpenAdd}
        />
      ) : viewMode === 'grid' ? (
        /* CARD GRID VIEW */
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {filteredPets.map((pet) => {
            const owner = ownerMap.get(pet.ownerId);
            return (
              <div
                key={pet.id}
                className="bg-white rounded-2xl border border-[#E2EAE4] p-5 shadow-sm hover:border-[#4A7255]/40 hover:shadow-md transition-all flex flex-col justify-between group"
              >
                <div>
                  <div className="flex items-start gap-4 mb-4">
                    {pet.photoUrl ? (
                      <img
                        src={pet.photoUrl}
                        alt={pet.name}
                        className="w-16 h-16 rounded-2xl object-cover border-2 border-[#E5EFE7] shadow-xs shrink-0 group-hover:scale-105 transition-transform"
                        referrerPolicy="no-referrer"
                      />
                    ) : (
                      <div className="w-16 h-16 rounded-2xl bg-[#E8F0EA] text-[#4A7255] flex items-center justify-center font-bold text-xl shrink-0">
                        {pet.name.charAt(0)}
                      </div>
                    )}

                    <div className="min-w-0 flex-1">
                      <div className="flex items-center justify-between gap-1">
                        <h4 className="text-base font-bold font-display text-[#1F2923] truncate">
                          {pet.name}
                        </h4>
                        <span className="font-mono text-[10px] text-[#718677]">{pet.id}</span>
                      </div>
                      <p className="text-xs text-[#526657] font-medium truncate mt-0.5">
                        {pet.breed}
                      </p>
                      <div className="flex items-center gap-1.5 text-[11px] text-[#718677] mt-1">
                        <span className="px-2 py-0.5 bg-[#EDF3EF] rounded-md font-medium text-[#37523F]">
                          {pet.species}
                        </span>
                        <span>·</span>
                        <span>{pet.gender}</span>
                        <span>·</span>
                        <span className="font-mono tabular-nums">{pet.weight} kg</span>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-1.5 pt-3 border-t border-[#EEF4F0] text-xs text-[#526657]">
                    <div className="flex items-center justify-between">
                      <span className="text-[#718677]">Age:</span>
                      <span className="font-semibold text-[#1F2923]">
                        {pet.ageYears} yrs {pet.ageMonths} mos
                      </span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-[#718677]">Owner:</span>
                      <button
                        onClick={() => owner && onSelectOwner(owner.id)}
                        className="font-medium text-[#4A7255] hover:underline truncate max-w-[170px]"
                      >
                        {owner?.fullName || 'Not assigned'}
                      </button>
                    </div>
                    {pet.allergies && pet.allergies.length > 0 && (
                      <div className="flex items-center justify-between pt-1">
                        <span className="text-[#B56722] font-medium text-[11px]">Allergies:</span>
                        <span className="text-[11px] text-[#B56722] truncate max-w-[170px]">
                          {pet.allergies.join(', ')}
                        </span>
                      </div>
                    )}
                  </div>
                </div>

                {/* Card Action Buttons */}
                <div className="mt-4 pt-3 border-t border-[#EEF4F0] flex items-center justify-between gap-2">
                  <button
                    onClick={() => {
                      setSelectedPet(pet);
                      setIsDetailsOpen(true);
                    }}
                    className="flex-1 py-1.5 px-3 bg-[#EEF4EF] hover:bg-[#E2ECE4] text-[#294231] text-xs font-semibold rounded-xl transition-colors inline-flex items-center justify-center gap-1.5"
                  >
                    <Eye className="w-3.5 h-3.5" />
                    <span>View Dossier</span>
                  </button>

                  <div className="flex items-center gap-1">
                    <button
                      onClick={() => handleOpenEdit(pet)}
                      className="p-1.5 text-[#5B7162] hover:text-[#213025] hover:bg-[#EEF4EF] rounded-lg transition-colors"
                      title="Edit Pet"
                    >
                      <Edit className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => setPetToDelete(pet)}
                      className="p-1.5 text-[#B92A2A] hover:bg-[#FDF2F2] rounded-lg transition-colors"
                      title="Delete Pet"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        /* TABLE VIEW */
        <div className="bg-white rounded-2xl border border-[#E2EAE4] shadow-sm overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-[#F7FAF8] border-b border-[#E2EAE4] text-[#55695B] uppercase font-semibold text-[11px] tracking-wider">
                <tr>
                  <th className="py-3 px-4">Patient</th>
                  <th className="py-3 px-4">Species & Breed</th>
                  <th className="py-3 px-4">Gender & Age</th>
                  <th className="py-3 px-4">Weight</th>
                  <th className="py-3 px-4">Owner</th>
                  <th className="py-3 px-4">Microchip ID</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#EEF4F0]">
                {filteredPets.map((pet) => {
                  const owner = ownerMap.get(pet.ownerId);
                  return (
                    <tr
                      key={pet.id}
                      className="hover:bg-[#F9FAF9] transition-colors group cursor-pointer"
                      onClick={() => {
                        setSelectedPet(pet);
                        setIsDetailsOpen(true);
                      }}
                    >
                      <td className="py-3 px-4">
                        <div className="flex items-center gap-3">
                          {pet.photoUrl ? (
                            <img
                              src={pet.photoUrl}
                              alt={pet.name}
                              className="w-9 h-9 rounded-xl object-cover border border-[#D5E0D7]"
                              referrerPolicy="no-referrer"
                            />
                          ) : (
                            <div className="w-9 h-9 rounded-xl bg-[#E8F0EA] text-[#4A7255] flex items-center justify-center font-bold">
                              {pet.name.charAt(0)}
                            </div>
                          )}
                          <div>
                            <span className="font-bold text-[#1F2923] block">{pet.name}</span>
                            <span className="font-mono text-[10px] text-[#788E7E]">{pet.id}</span>
                          </div>
                        </div>
                      </td>
                      <td className="py-3 px-4">
                        <span className="font-medium text-[#1F2923] block">{pet.breed}</span>
                        <span className="text-[11px] text-[#697E70]">{pet.species}</span>
                      </td>
                      <td className="py-3 px-4">
                        <span className="text-[#1F2923] block">{pet.gender}</span>
                        <span className="text-[11px] text-[#697E70]">
                          {pet.ageYears}y {pet.ageMonths}m
                        </span>
                      </td>
                      <td className="py-3 px-4 font-mono font-medium text-[#294030] tabular-nums">
                        {pet.weight} kg
                      </td>
                      <td className="py-3 px-4">
                        <span className="font-medium text-[#1F2923] block">
                          {owner?.fullName || 'Not assigned'}
                        </span>
                        <span className="text-[11px] text-[#697E70] font-mono">
                          {owner?.phoneNumber || '—'}
                        </span>
                      </td>
                      <td className="py-3 px-4 font-mono text-[11px] text-[#697E70]">
                        {pet.microchipNumber || '—'}
                      </td>
                      <td className="py-3 px-4 text-right" onClick={(e) => e.stopPropagation()}>
                        <div className="flex items-center justify-end gap-1.5">
                          <button
                            onClick={() => {
                              setSelectedPet(pet);
                              setIsDetailsOpen(true);
                            }}
                            className="p-1.5 text-[#4A7255] hover:bg-[#EEF4EF] rounded-lg transition-colors"
                            title="View"
                          >
                            <Eye className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => handleOpenEdit(pet)}
                            className="p-1.5 text-[#5B7162] hover:bg-[#EEF4EF] rounded-lg transition-colors"
                            title="Edit"
                          >
                            <Edit className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => setPetToDelete(pet)}
                            className="p-1.5 text-[#B92A2A] hover:bg-[#FDF2F2] rounded-lg transition-colors"
                            title="Delete"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Pet Details Modal */}
      <PetDetailsModal
        pet={selectedPet}
        isOpen={isDetailsOpen}
        onClose={() => setIsDetailsOpen(false)}
        onEdit={(pet) => {
          setIsDetailsOpen(false);
          handleOpenEdit(pet);
        }}
        onDelete={(pet) => {
          setIsDetailsOpen(false);
          setPetToDelete(pet);
        }}
        onSelectOwner={(ownerId) => {
          setIsDetailsOpen(false);
          onSelectOwner(ownerId);
        }}
        onNewAppointmentForPet={(petId) => {
          setIsDetailsOpen(false);
          onScheduleAppointment(petId);
        }}
        onNewMedicalRecordForPet={(petId) => {
          setIsDetailsOpen(false);
          onNewMedicalRecord(petId);
        }}
      />

      {/* Pet Add/Edit Form Modal */}
      <PetFormModal
        isOpen={isFormOpen}
        petToEdit={petToEdit}
        onClose={() => setIsFormOpen(false)}
        onSave={handleSavePet}
      />

      {/* Confirmation Modal for Delete */}
      <ConfirmationModal
        isOpen={!!petToDelete}
        title={`Delete Pet Record: ${petToDelete?.name}?`}
        message="Are you sure you want to permanently delete this pet record? All connected appointment logs and medical consultations will also be removed."
        confirmLabel="Delete Pet"
        isDestructive={true}
        onConfirm={handleDeletePetConfirm}
        onCancel={() => setPetToDelete(null)}
      />
    </div>
  );
};
