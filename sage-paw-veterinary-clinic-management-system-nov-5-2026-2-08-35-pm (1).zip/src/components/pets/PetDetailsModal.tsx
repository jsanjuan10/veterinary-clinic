import React from 'react';
import {
  X,
  PawPrint,
  Heart,
  Calendar,
  AlertCircle,
  Clock,
  Phone,
  Mail,
  MapPin,
  FileText,
  Weight,
  Syringe,
  Printer,
  Edit2,
  Trash2,
} from 'lucide-react';
import { Pet, PetOwner } from '../../types';
import { db } from '../../services/db';

interface PetDetailsModalProps {
  pet: Pet | null;
  isOpen: boolean;
  onClose: () => void;
  onEdit: (pet: Pet) => void;
  onDelete: (pet: Pet) => void;
  onSelectOwner: (ownerId: string) => void;
  onNewAppointmentForPet: (petId: string) => void;
  onNewMedicalRecordForPet: (petId: string) => void;
}

export const PetDetailsModal: React.FC<PetDetailsModalProps> = ({
  pet,
  isOpen,
  onClose,
  onEdit,
  onDelete,
  onSelectOwner,
  onNewAppointmentForPet,
  onNewMedicalRecordForPet,
}) => {
  if (!isOpen || !pet) return null;

  const owner = db.getOwnerById(pet.ownerId);
  const appointments = db.getAppointmentsByPetId(pet.id);
  const records = db.getMedicalRecordsByPetId(pet.id);

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/45 backdrop-blur-[2px] overflow-y-auto">
      <div className="bg-white rounded-2xl max-w-3xl w-full shadow-2xl border border-[#DDE5E0] max-h-[92vh] flex flex-col overflow-hidden animate-in fade-in zoom-in-95 my-auto">
        {/* Header Bar */}
        <div className="p-5 border-b border-[#E8EFEA] flex items-center justify-between bg-[#F8FAF8]">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#E8F0EA] text-[#3E6548] flex items-center justify-center font-bold text-lg">
              <PawPrint className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-lg font-bold font-display text-[#1F2923]">
                  {pet.name}
                </h3>
                <span className="px-2 py-0.5 rounded-md bg-[#E2ECE4] text-[#34513C] text-xs font-semibold">
                  {pet.species}
                </span>
                <span className="font-mono text-xs text-[#708476]">{pet.id}</span>
              </div>
              <p className="text-xs text-[#5D7063]">
                {pet.breed} · {pet.gender} · {pet.ageYears} yrs {pet.ageMonths} mos
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="p-2 text-[#566B5C] hover:text-[#213025] hover:bg-[#EAEFEA] rounded-xl transition-colors"
              title="Print Dossier"
            >
              <Printer className="w-4 h-4" />
            </button>
            <button
              onClick={() => onEdit(pet)}
              className="p-2 text-[#566B5C] hover:text-[#213025] hover:bg-[#EAEFEA] rounded-xl transition-colors"
              title="Edit Pet Information"
            >
              <Edit2 className="w-4 h-4" />
            </button>
            <button
              onClick={() => onDelete(pet)}
              className="p-2 text-[#B92A2A] hover:bg-[#FDF2F2] rounded-xl transition-colors"
              title="Delete Pet"
            >
              <Trash2 className="w-4 h-4" />
            </button>
            <button
              onClick={onClose}
              className="p-2 text-[#778B7D] hover:text-[#1E2820] hover:bg-[#EAEFEA] rounded-xl transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Modal Scrollable Body */}
        <div className="p-6 overflow-y-auto space-y-6 flex-1 text-[#222E25]">
          {/* Top Profile Summary */}
          <div className="flex flex-col sm:flex-row gap-5 items-start sm:items-center bg-[#F7FAF8] p-4 rounded-2xl border border-[#E3ECE5]">
            {pet.photoUrl ? (
              <img
                src={pet.photoUrl}
                alt={pet.name}
                className="w-24 h-24 rounded-2xl object-cover border-2 border-white shadow-sm shrink-0"
                referrerPolicy="no-referrer"
              />
            ) : (
              <div className="w-24 h-24 rounded-2xl bg-[#E8F0EA] text-[#4A7255] flex items-center justify-center font-bold text-3xl shrink-0">
                {pet.name.charAt(0)}
              </div>
            )}

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 flex-1 text-xs">
              <div>
                <span className="text-[11px] text-[#697E70] block">Date of Birth</span>
                <span className="font-semibold text-[#1F2923] font-mono tabular-nums">
                  {pet.dateOfBirth || 'Unknown'}
                </span>
              </div>
              <div>
                <span className="text-[11px] text-[#697E70] block">Current Weight</span>
                <span className="font-semibold text-[#1F2923] font-mono tabular-nums">
                  {pet.weight} kg
                </span>
              </div>
              <div>
                <span className="text-[11px] text-[#697E70] block">Coat Color</span>
                <span className="font-semibold text-[#1F2923] truncate block">
                  {pet.color || 'Not specified'}
                </span>
              </div>
              <div>
                <span className="text-[11px] text-[#697E70] block">Microchip ID</span>
                <span className="font-semibold text-[#1F2923] font-mono text-[11px] truncate block">
                  {pet.microchipNumber || 'None registered'}
                </span>
              </div>
            </div>
          </div>

          {/* Allergies & Special Notes */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
            <div className="p-4 rounded-xl border border-[#EAE3D5] bg-[#FCFAF5]">
              <div className="flex items-center gap-1.5 font-bold text-[#8A5A19] mb-2">
                <AlertCircle className="w-4 h-4" />
                <span>Known Allergies & Contraindications</span>
              </div>
              {pet.allergies && pet.allergies.length > 0 ? (
                <div className="flex flex-wrap gap-1.5">
                  {pet.allergies.map((allergy, i) => (
                    <span
                      key={i}
                      className="px-2 py-0.5 rounded-md bg-[#F4EADB] text-[#784A12] font-medium"
                    >
                      {allergy}
                    </span>
                  ))}
                </div>
              ) : (
                <p className="text-[#847B6F]">No known drug or dietary allergies recorded.</p>
              )}
            </div>

            <div className="p-4 rounded-xl border border-[#E3ECE5] bg-[#F9FBF9]">
              <span className="font-bold text-[#324536] block mb-1.5">
                Special Handling & Behavioral Notes
              </span>
              <p className="text-[#55695B] leading-relaxed">
                {pet.specialNotes || 'No special handling instructions indicated for this patient.'}
              </p>
            </div>
          </div>

          {/* Owner Information Section */}
          <div className="p-4 rounded-2xl border border-[#E3ECE5] bg-white">
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs font-bold uppercase tracking-wider text-[#697E70]">
                Registered Pet Owner
              </span>
              {owner && (
                <button
                  onClick={() => onSelectOwner(owner.id)}
                  className="text-xs font-semibold text-[#4A7255] hover:underline"
                >
                  View Owner Details →
                </button>
              )}
            </div>

            {owner ? (
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                <div>
                  <span className="text-[11px] text-[#697E70] block">Owner Name</span>
                  <span className="font-bold text-[#1E2922]">{owner.fullName}</span>
                </div>
                <div>
                  <span className="text-[11px] text-[#697E70] block">Phone Number</span>
                  <span className="font-mono text-[#324536]">{owner.phoneNumber}</span>
                </div>
                <div>
                  <span className="text-[11px] text-[#697E70] block">Emergency Contact</span>
                  <span className="text-[#324536]">
                    {owner.emergencyContact.name} ({owner.emergencyContact.relationship}):{' '}
                    {owner.emergencyContact.phone}
                  </span>
                </div>
              </div>
            ) : (
              <p className="text-xs text-[#7A8E80]">No owner linked to this pet record.</p>
            )}
          </div>

          {/* Medical Records History */}
          <div>
            <div className="flex items-center justify-between mb-3">
              <h4 className="text-sm font-bold font-display text-[#1E2922] flex items-center gap-2">
                <FileText className="w-4 h-4 text-[#4A7255]" />
                <span>Medical Consultation History ({records.length})</span>
              </h4>
              <button
                onClick={() => onNewMedicalRecordForPet(pet.id)}
                className="text-xs font-semibold text-[#4A7255] hover:underline"
              >
                + Add Record
              </button>
            </div>

            {records.length === 0 ? (
              <div className="p-4 text-center rounded-xl border border-dashed border-[#D2DCD4] text-xs text-[#718778]">
                No clinical consultation records logged for {pet.name} yet.
              </div>
            ) : (
              <div className="space-y-3">
                {records.map((rec) => (
                  <div
                    key={rec.id}
                    className="p-4 rounded-xl border border-[#E5EDE7] bg-[#FBFCFB] text-xs space-y-2"
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-[#2A4030]">
                        {rec.diagnosis || 'General Examination'}
                      </span>
                      <span className="font-mono text-[#667C6E] tabular-nums">
                        {rec.consultationDate}
                      </span>
                    </div>
                    <p className="text-[#4E6254]">
                      <strong>Symptoms:</strong> {rec.symptoms}
                    </p>
                    <p className="text-[#4E6254]">
                      <strong>Treatment:</strong> {rec.treatment}
                    </p>
                    {rec.prescribedMedication && (
                      <p className="text-[#344E3B]">
                        <strong>Rx Medication:</strong> {rec.prescribedMedication}
                      </p>
                    )}
                    <div className="flex items-center gap-4 text-[11px] text-[#6E8173] pt-1 border-t border-[#EDF3EE]">
                      <span>Doctor: {rec.veterinarian}</span>
                      <span>Weight: {rec.weight} kg</span>
                      <span>Temp: {rec.temperature}°C</span>
                      {rec.followUpDate && <span>Follow-up: {rec.followUpDate}</span>}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Appointment History */}
          <div>
            <div className="flex items-center justify-between mb-3">
              <h4 className="text-sm font-bold font-display text-[#1E2922] flex items-center gap-2">
                <Calendar className="w-4 h-4 text-[#4A7255]" />
                <span>Appointments ({appointments.length})</span>
              </h4>
              <button
                onClick={() => onNewAppointmentForPet(pet.id)}
                className="text-xs font-semibold text-[#4A7255] hover:underline"
              >
                + Schedule
              </button>
            </div>

            {appointments.length === 0 ? (
              <div className="p-4 text-center rounded-xl border border-dashed border-[#D2DCD4] text-xs text-[#718778]">
                No appointments recorded.
              </div>
            ) : (
              <div className="space-y-2">
                {appointments.map((apt) => (
                  <div
                    key={apt.id}
                    className="p-3 rounded-xl border border-[#E7EFE9] flex items-center justify-between text-xs"
                  >
                    <div>
                      <span className="font-bold text-[#1F2C23] block">{apt.reasonForVisit}</span>
                      <span className="text-[#657A6C]">
                        {apt.appointmentDate} at {apt.appointmentTime} · {apt.veterinarian}
                      </span>
                    </div>
                    <span className="px-2 py-0.5 rounded-md font-semibold text-[11px] bg-[#EEF4EF] text-[#334E3B]">
                      {apt.status}
                    </span>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Modal Footer */}
        <div className="p-4 border-t border-[#E8EFEA] bg-[#F8FAF8] flex items-center justify-between">
          <span className="text-xs text-[#738879]">
            Registered since {new Date(pet.createdAt).toLocaleDateString()}
          </span>
          <div className="flex items-center gap-2">
            <button
              onClick={() => onNewAppointmentForPet(pet.id)}
              className="px-3.5 py-1.5 bg-[#4A7255] hover:bg-[#3C5D45] text-white text-xs font-semibold rounded-xl shadow-sm transition-all"
            >
              Schedule Visit
            </button>
            <button
              onClick={onClose}
              className="px-4 py-1.5 bg-[#E8EFEA] hover:bg-[#DCE6DE] text-[#2F4134] text-xs font-semibold rounded-xl transition-colors"
            >
              Close
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
