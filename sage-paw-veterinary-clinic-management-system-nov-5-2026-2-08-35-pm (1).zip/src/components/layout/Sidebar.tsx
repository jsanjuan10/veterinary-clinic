import React from 'react';
import {
  LayoutDashboard,
  PawPrint,
  Users,
  CalendarDays,
  FileText,
  Settings,
  LogOut,
  Heart,
  ChevronRight,
  Shield,
  X,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { db } from '../../services/db';

export type NavTab = 'dashboard' | 'pets' | 'owners' | 'appointments' | 'records' | 'settings';

interface SidebarProps {
  currentTab: NavTab;
  onSelectTab: (tab: NavTab) => void;
  isMobileOpen: boolean;
  onCloseMobile: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentTab,
  onSelectTab,
  isMobileOpen,
  onCloseMobile,
}) => {
  const { user, setIsLogoutModalOpen } = useAuth();
  const settings = db.getSettings();

  const navItems = [
    { id: 'dashboard' as NavTab, label: 'Dashboard', icon: LayoutDashboard },
    { id: 'pets' as NavTab, label: 'Pet Management', icon: PawPrint },
    { id: 'owners' as NavTab, label: 'Pet Owners', icon: Users },
    { id: 'appointments' as NavTab, label: 'Appointments', icon: CalendarDays },
    { id: 'records' as NavTab, label: 'Medical Records', icon: FileText },
    { id: 'settings' as NavTab, label: 'Settings', icon: Settings },
  ];

  const handleNavClick = (tab: NavTab) => {
    onSelectTab(tab);
    onCloseMobile();
  };

  const content = (
    <div className="flex flex-col h-full bg-[#1F2D24] text-white">
      {/* Brand Header */}
      <div className="px-5 py-5 border-b border-white/10 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-[#6B9073] text-white flex items-center justify-center font-bold shadow-sm">
            <Heart className="w-5 h-5 fill-current" />
          </div>
          <div className="min-w-0">
            <span className="text-base font-bold tracking-tight text-white font-display block truncate">
              {settings.clinicName || 'Sage & Paw'}
            </span>
            <span className="text-[11px] text-[#A6C4AC] font-medium block truncate">
              Veterinary Clinic System
            </span>
          </div>
        </div>
        <button
          onClick={onCloseMobile}
          className="lg:hidden text-white/70 hover:text-white p-1 rounded-lg"
          aria-label="Close menu"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      {/* Practitioner Mini Badge */}
      {user && (
        <div className="mx-3.5 my-3.5 p-3 rounded-xl bg-white/5 border border-white/10 flex items-center gap-3">
          <img
            src={user.avatarUrl || '/src/assets/images/vet_doctor_avatar_1793857120858.jpg'}
            alt={user.fullName}
            className="w-10 h-10 rounded-xl object-cover border border-white/20 shrink-0"
            referrerPolicy="no-referrer"
          />
          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-1.5">
              <span className="text-xs font-semibold text-white truncate block">{user.fullName}</span>
            </div>
            <span className="text-[10px] text-[#A2BFA8] block truncate capitalize">
              {user.title || user.role}
            </span>
          </div>
        </div>
      )}

      {/* Navigation Items */}
      <nav className="flex-1 px-3 py-2 space-y-1 overflow-y-auto">
        <div className="px-3 pb-2 pt-1 text-[10px] font-bold uppercase tracking-wider text-[#8DAE93]">
          Clinical Navigation
        </div>
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = currentTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => handleNavClick(item.id)}
              className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs font-medium transition-all ${
                isActive
                  ? 'bg-[#4A7255] text-white shadow-sm font-semibold'
                  : 'text-[#D3E3D6] hover:bg-white/10 hover:text-white'
              }`}
            >
              <div className="flex items-center gap-3">
                <Icon className={`w-4 h-4 ${isActive ? 'text-white' : 'text-[#A0BFB6]'}`} />
                <span>{item.label}</span>
              </div>
              {isActive && <ChevronRight className="w-3.5 h-3.5 text-white/80" />}
            </button>
          );
        })}
      </nav>

      {/* Emergency & Clinic Contact pill */}
      <div className="px-4 py-3 mx-3 my-2 rounded-xl bg-black/20 border border-white/5 text-[11px] text-[#A9C3AF]">
        <div className="flex items-center gap-1.5 text-white font-medium mb-1">
          <Shield className="w-3.5 h-3.5 text-[#8FA98F]" />
          <span>Emergency Hotline</span>
        </div>
        <span className="font-mono text-white text-xs">{settings.emergencyHotline}</span>
      </div>

      {/* Bottom Logout */}
      <div className="p-3 border-t border-white/10">
        <button
          onClick={() => setIsLogoutModalOpen(true)}
          className="w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs font-medium text-[#FFBABA] hover:bg-[#B92A2A]/20 transition-colors"
        >
          <LogOut className="w-4 h-4" />
          <span>Sign Out</span>
        </button>
      </div>
    </div>
  );

  return (
    <>
      {/* Desktop Persistent Sidebar */}
      <aside className="hidden lg:flex w-64 shrink-0 flex-col h-screen sticky top-0 border-r border-[#D9E3DC] z-30 shadow-sm">
        {content}
      </aside>

      {/* Mobile Drawer Overlay */}
      {isMobileOpen && (
        <div className="lg:hidden fixed inset-0 z-50 flex">
          <div
            className="fixed inset-0 bg-black/50 backdrop-blur-[1px] transition-opacity"
            onClick={onCloseMobile}
          />
          <div className="relative flex-1 flex flex-col max-w-xs w-full h-full shadow-2xl z-10">
            {content}
          </div>
        </div>
      )}
    </>
  );
};
