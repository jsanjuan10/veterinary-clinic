import React, { useState } from 'react';
import { Menu, Plus, Calendar, Clock, User as UserIcon, LogOut, Settings as SettingsIcon } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { NavTab } from './Sidebar';

interface NavbarProps {
  currentTab: NavTab;
  onSelectTab: (tab: NavTab) => void;
  onOpenMobileMenu: () => void;
  onQuickAction: (actionType: 'appointment' | 'pet' | 'owner' | 'record') => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentTab,
  onSelectTab,
  onOpenMobileMenu,
  onQuickAction,
}) => {
  const { user, setIsLogoutModalOpen } = useAuth();
  const [profileDropdownOpen, setProfileDropdownOpen] = useState(false);

  const tabTitles: Record<NavTab, { title: string; subtitle: string }> = {
    dashboard: { title: 'Clinical Dashboard', subtitle: 'Real-time clinic metrics & appointment flow' },
    pets: { title: 'Pet Patient Records', subtitle: 'Manage veterinary patients, vitals & dossiers' },
    owners: { title: 'Pet Owners Directory', subtitle: 'Client contacts, addresses & registered pets' },
    appointments: { title: 'Appointment Scheduling', subtitle: 'Daily & monthly calendar management' },
    records: { title: 'Medical Consultations & Vitals', subtitle: 'Diagnostic history, prescriptions & treatments' },
    settings: { title: 'Clinic & System Settings', subtitle: 'Practitioner profile & operational preferences' },
  };

  const todayStr = new Date().toLocaleDateString('en-US', {
    weekday: 'short',
    month: 'short',
    day: 'numeric',
    year: 'numeric',
  });

  return (
    <header className="sticky top-0 z-20 bg-white/95 backdrop-blur-md border-b border-[#E3ECE5] px-4 md:px-8 py-3.5 transition-all">
      <div className="flex items-center justify-between gap-4">
        {/* Left: Mobile hamburger & Contextual Breadcrumb */}
        <div className="flex items-center gap-3 min-w-0">
          <button
            onClick={onOpenMobileMenu}
            className="lg:hidden p-2 text-[#46584B] hover:text-[#1F2923] hover:bg-[#F0F4F1] rounded-xl transition-colors shrink-0"
            aria-label="Open navigation menu"
          >
            <Menu className="w-5 h-5" />
          </button>

          <div className="min-w-0">
            <div className="flex items-center gap-2 text-xs text-[#6F8273]">
              <span className="font-medium hidden sm:inline">Sage & Paw</span>
              <span className="hidden sm:inline" aria-hidden="true">/</span>
              <span className="text-[#324536] font-semibold truncate">{tabTitles[currentTab].title}</span>
            </div>
            <h1 className="text-base md:text-lg font-bold text-[#1F2923] font-display truncate leading-tight mt-0.5">
              {tabTitles[currentTab].title}
            </h1>
          </div>
        </div>

        {/* Right: Date info + Quick Action CTA + User Menu */}
        <div className="flex items-center gap-3 shrink-0">
          {/* Subtle date pill */}
          <div className="hidden md:flex items-center gap-2 text-xs text-[#526656] bg-[#F4F7F4] px-3 py-1.5 rounded-xl border border-[#E2EAE3]">
            <Calendar className="w-3.5 h-3.5 text-[#5F8868]" />
            <span className="font-medium">{todayStr}</span>
          </div>

          {/* Quick Schedule Button */}
          <button
            onClick={() => onQuickAction('appointment')}
            className="flex items-center gap-1.5 px-3.5 py-2 bg-[#4A7255] hover:bg-[#3C5D45] active:bg-[#314E3A] text-white text-xs font-semibold rounded-xl shadow-sm transition-all whitespace-nowrap shrink-0"
          >
            <Plus className="w-4 h-4" />
            <span className="hidden sm:inline">Schedule Appointment</span>
            <span className="sm:hidden">New</span>
          </button>

          {/* User Profile Avatar with Dropdown */}
          {user && (
            <div className="relative">
              <button
                onClick={() => setProfileDropdownOpen(!profileDropdownOpen)}
                className="flex items-center gap-2 p-1 pl-1.5 rounded-xl hover:bg-[#F2F6F3] border border-transparent hover:border-[#DFE7E1] transition-colors focus:outline-none"
                aria-expanded={profileDropdownOpen}
              >
                <img
                  src={user.avatarUrl || '/src/assets/images/vet_doctor_avatar_1793857120858.jpg'}
                  alt={user.fullName}
                  className="w-8 h-8 rounded-lg object-cover border border-[#C5D5C8]"
                  referrerPolicy="no-referrer"
                />
                <div className="hidden xl:block text-left text-xs">
                  <span className="font-bold text-[#233327] block truncate max-w-[120px]">
                    {user.fullName.split(',')[0]}
                  </span>
                  <span className="text-[10px] text-[#697E6E] block capitalize">
                    {user.role}
                  </span>
                </div>
              </button>

              {/* Profile Dropdown Menu */}
              {profileDropdownOpen && (
                <>
                  <div
                    className="fixed inset-0 z-20"
                    onClick={() => setProfileDropdownOpen(false)}
                  />
                  <div className="absolute right-0 mt-2 w-56 bg-white rounded-2xl shadow-xl border border-[#DEE7E0] py-2 z-30 animate-in fade-in zoom-in-95">
                    <div className="px-4 py-2 border-b border-[#EDF2EE]">
                      <p className="text-xs font-bold text-[#1E2B21] truncate">{user.fullName}</p>
                      <p className="text-[11px] text-[#6D8271] truncate">{user.email}</p>
                    </div>

                    <button
                      onClick={() => {
                        setProfileDropdownOpen(false);
                        onSelectTab('settings');
                      }}
                      className="w-full flex items-center gap-2.5 px-4 py-2 text-xs text-[#314235] hover:bg-[#F3F7F4] transition-colors text-left"
                    >
                      <SettingsIcon className="w-4 h-4 text-[#667C6A]" />
                      <span>Settings & Profile</span>
                    </button>

                    <button
                      onClick={() => {
                        setProfileDropdownOpen(false);
                        setIsLogoutModalOpen(true);
                      }}
                      className="w-full flex items-center gap-2.5 px-4 py-2 text-xs text-[#B92A2A] hover:bg-[#FDF2F2] transition-colors text-left border-t border-[#EDF2EE] mt-1"
                    >
                      <LogOut className="w-4 h-4" />
                      <span>Log Out</span>
                    </button>
                  </div>
                </>
              )}
            </div>
          )}
        </div>
      </div>
    </header>
  );
};
