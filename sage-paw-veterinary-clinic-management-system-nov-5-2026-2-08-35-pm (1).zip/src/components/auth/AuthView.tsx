import React, { useState } from 'react';
import { Eye, EyeOff, Lock, Mail, User as UserIcon, Heart, CheckCircle2, ShieldCheck, Sparkles } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';

type AuthMode = 'login' | 'register' | 'forgot';

export const AuthView: React.FC = () => {
  const { login, register, resetPassword, savedRememberEmail } = useAuth();

  const [mode, setMode] = useState<AuthMode>('login');
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [rememberMe, setRememberMe] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Login form state
  const [loginIdentifier, setLoginIdentifier] = useState(savedRememberEmail || '');
  const [loginPassword, setLoginPassword] = useState('');

  // Register form state
  const [regFullName, setRegFullName] = useState('');
  const [regEmail, setRegEmail] = useState('');
  const [regUsername, setRegUsername] = useState('');
  const [regPassword, setRegPassword] = useState('');
  const [regConfirmPassword, setRegConfirmPassword] = useState('');

  // Forgot password form state
  const [forgotEmail, setForgotEmail] = useState('');
  const [forgotStep, setForgotStep] = useState<'request' | 'reset'>('request');
  const [resetCode, setResetCode] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmNewPassword, setConfirmNewPassword] = useState('');
  const [mockVerificationSent, setMockVerificationSent] = useState(false);

  // Form error states
  const [errorMessage, setErrorMessage] = useState('');

  const handleLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');
    setIsSubmitting(true);
    const success = await login(loginIdentifier, loginPassword, rememberMe);
    setIsSubmitting(false);
    if (!success) {
      setErrorMessage('Invalid email/username or password. Please check your credentials or register a new account.');
    }
  };

  const handleRegisterSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');

    if (regPassword !== regConfirmPassword) {
      setErrorMessage('Passwords do not match.');
      return;
    }
    if (regPassword.length < 6) {
      setErrorMessage('Password must be at least 6 characters long.');
      return;
    }

    setIsSubmitting(true);
    const success = await register({
      fullName: regFullName,
      email: regEmail,
      username: regUsername,
      passwordPlain: regPassword,
      confirmPasswordPlain: regConfirmPassword,
    });
    setIsSubmitting(false);
    if (!success) {
      setErrorMessage('Registration could not be completed. Please check your inputs.');
    }
  };

  const handleForgotRequest = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');
    if (!forgotEmail || !forgotEmail.includes('@')) {
      setErrorMessage('Please enter a valid registered email address.');
      return;
    }
    setMockVerificationSent(true);
    setForgotStep('reset');
  };

  const handleResetSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');
    if (newPassword !== confirmNewPassword) {
      setErrorMessage('New passwords do not match.');
      return;
    }
    if (newPassword.length < 6) {
      setErrorMessage('Password must be at least 6 characters.');
      return;
    }
    setIsSubmitting(true);
    const success = await resetPassword(forgotEmail, newPassword);
    setIsSubmitting(false);
    if (success) {
      setMode('login');
      setLoginIdentifier(forgotEmail);
      setLoginPassword(newPassword);
      setForgotStep('request');
      setMockVerificationSent(false);
    } else {
      setErrorMessage('Failed to reset password. Verify your email.');
    }
  };



  return (
    <div className="min-h-screen flex flex-col md:flex-row bg-[#F7F9F7]">
      {/* Left Column: Visual & Brand Story */}
      <div className="hidden lg:flex lg:w-1/2 relative bg-[#2D4533] text-white flex-col justify-between p-12 overflow-hidden">
        {/* Background Image with Gentle Overlay Scrim */}
        <div className="absolute inset-0 z-0">
          <img
            src="/src/assets/images/vet_clinic_hero_1793857119970.jpg"
            alt="Veterinary Clinic Care"
            className="w-full h-full object-cover opacity-35 filter brightness-90 saturate-85"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#1F2F23] via-[#243B2B]/90 to-[#2A4232]/80" />
        </div>

        {/* Content over scrim */}
        <div className="relative z-10">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#8FA98F] text-[#1A2E20] flex items-center justify-center font-bold text-xl shadow-md">
              <Heart className="w-5 h-5 fill-current" />
            </div>
            <div>
              <span className="text-xl font-bold tracking-tight text-white font-display block">Sage & Paw</span>
              <span className="text-xs text-[#B9CEBD] font-medium tracking-wide">Veterinary Clinic System</span>
            </div>
          </div>
        </div>

        <div className="relative z-10 my-auto py-12 max-w-lg">
          <span className="text-xs font-semibold tracking-wider uppercase text-[#A3C2A7] mb-2 block">
            Clinical Excellence & Compassion
          </span>
          <h1 className="text-3xl md:text-4xl font-bold font-display leading-tight text-white text-balance mb-4">
            Unified management for modern veterinary medicine.
          </h1>
          <p className="text-[#D3E0D6] text-sm md:text-base leading-relaxed mb-8">
            Complete digital orchestration for veterinary teams. Track companion animals, owners, real-time appointments, diagnostic vitals, and verified medical records with elegance.
          </p>

          <div className="space-y-3 border-t border-white/15 pt-6 text-xs text-[#C6D8C9]">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-[#8FA98F] shrink-0" />
              <span>Full CRUD patient records with species, weights, and allergies</span>
            </div>
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-[#8FA98F] shrink-0" />
              <span>Calendar-integrated appointment scheduling and status updates</span>
            </div>
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-[#8FA98F] shrink-0" />
              <span>Diagnostic consultation dossiers with vaccination tracking</span>
            </div>
          </div>
        </div>

        <div className="relative z-10 flex items-center justify-between text-xs text-[#A2BBA6] border-t border-white/10 pt-4">
          <span>742 Evergreen Botanical Way, Suite 100</span>
          <span>Emergency: (555) 911-PETS</span>
        </div>
      </div>

      {/* Right Column: Authentication Card Forms */}
      <div className="flex-1 flex items-center justify-center p-6 md:p-12 lg:p-16">
        <div className="w-full max-w-md bg-white rounded-2xl shadow-sm border border-[#E5EDE7] p-8 md:p-10">
          {/* Mobile Brand Header */}
          <div className="flex lg:hidden items-center gap-2.5 mb-6">
            <div className="w-9 h-9 rounded-xl bg-[#4A7255] text-white flex items-center justify-center font-bold">
              <Heart className="w-4 h-4 fill-current" />
            </div>
            <div>
              <span className="text-lg font-bold tracking-tight text-[#1E2820] font-display block">Sage & Paw</span>
              <span className="text-xs text-[#6B8F71]">Veterinary Clinic Management</span>
            </div>
          </div>

          {/* Form Header */}
          <div className="mb-6">
            <h2 className="text-2xl font-bold font-display text-[#1F2923]">
              {mode === 'login' && 'Sign In to Portal'}
              {mode === 'register' && 'Create Staff Account'}
              {mode === 'forgot' && 'Reset Password'}
            </h2>
            <p className="text-xs text-[#5D6F63] mt-1">
              {mode === 'login' && 'Enter your credentials to access the clinical workspace.'}
              {mode === 'register' && 'Register new medical staff, technician, or administrator.'}
              {mode === 'forgot' && 'Recover access to your clinic account with verified email.'}
            </p>
          </div>

          {errorMessage && (
            <div className="mb-5 p-3 rounded-lg bg-[#FDF2F2] border border-[#F8D7DA] text-[#9E2A2B] text-xs leading-relaxed">
              {errorMessage}
            </div>
          )}

          {/* LOGIN FORM */}
          {mode === 'login' && (
            <form onSubmit={handleLoginSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-[#2D3A31] mb-1.5">
                  Email or Username
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-[#7A8E80]">
                    <Mail className="w-4 h-4" />
                  </div>
                  <input
                    type="text"
                    required
                    value={loginIdentifier}
                    onChange={(e) => setLoginIdentifier(e.target.value)}
                    placeholder="Enter email or username"
                    className="w-full pl-9 pr-3.5 py-2.5 text-sm rounded-xl border border-[#D5E0D7] bg-[#FBFCFB] focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#4A7255]/25 focus:border-[#4A7255] transition-all text-[#1F2923]"
                  />
                </div>
              </div>

              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="block text-xs font-semibold text-[#2D3A31]">
                    Password
                  </label>
                  <button
                    type="button"
                    onClick={() => {
                      setErrorMessage('');
                      setMode('forgot');
                    }}
                    className="text-xs font-medium text-[#4A7255] hover:text-[#36573F] transition-colors"
                  >
                    Forgot password?
                  </button>
                </div>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-[#7A8E80]">
                    <Lock className="w-4 h-4" />
                  </div>
                  <input
                    type={showPassword ? 'text' : 'password'}
                    required
                    value={loginPassword}
                    onChange={(e) => setLoginPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full pl-9 pr-10 py-2.5 text-sm rounded-xl border border-[#D5E0D7] bg-[#FBFCFB] focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#4A7255]/25 focus:border-[#4A7255] transition-all text-[#1F2923]"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute inset-y-0 right-0 pr-3 flex items-center text-[#7A8E80] hover:text-[#36573F] focus:outline-none"
                    aria-label={showPassword ? 'Hide password' : 'Show password'}
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <div className="flex items-center justify-between pt-1">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={rememberMe}
                    onChange={(e) => setRememberMe(e.target.checked)}
                    className="w-4 h-4 text-[#4A7255] border-[#CAD5CC] rounded focus:ring-[#4A7255] accent-[#4A7255]"
                  />
                  <span className="text-xs text-[#4F6054]">Remember my credentials</span>
                </label>
              </div>

              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full py-2.5 px-4 bg-[#4A7255] hover:bg-[#3C5D45] active:bg-[#314E3A] text-white font-medium text-sm rounded-xl transition-all shadow-sm flex items-center justify-center gap-2 disabled:opacity-70"
              >
                {isSubmitting ? (
                  <span>Authenticating...</span>
                ) : (
                  <>
                    <ShieldCheck className="w-4 h-4" />
                    <span>Sign In to Clinic</span>
                  </>
                )}
              </button>



              <div className="text-center pt-2">
                <p className="text-xs text-[#5D6F63]">
                  Don’t have a staff account yet?{' '}
                  <button
                    type="button"
                    onClick={() => {
                      setErrorMessage('');
                      setMode('register');
                    }}
                    className="font-semibold text-[#4A7255] hover:underline"
                  >
                    Register new account
                  </button>
                </p>
              </div>
            </form>
          )}

          {/* REGISTER FORM */}
          {mode === 'register' && (
            <form onSubmit={handleRegisterSubmit} className="space-y-3.5">
              <div>
                <label className="block text-xs font-semibold text-[#2D3A31] mb-1">
                  Full Name
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-[#7A8E80]">
                    <UserIcon className="w-4 h-4" />
                  </div>
                  <input
                    type="text"
                    required
                    value={regFullName}
                    onChange={(e) => setRegFullName(e.target.value)}
                    placeholder="e.g. Dr. Alexis Morgan, DVM"
                    className="w-full pl-9 pr-3.5 py-2 text-sm rounded-xl border border-[#D5E0D7] bg-[#FBFCFB] focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#4A7255]/25 focus:border-[#4A7255] transition-all text-[#1F2923]"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-[#2D3A31] mb-1">
                    Email Address
                  </label>
                  <input
                    type="email"
                    required
                    value={regEmail}
                    onChange={(e) => setRegEmail(e.target.value)}
                    placeholder="alexis@sagepaw.vet"
                    className="w-full px-3 py-2 text-sm rounded-xl border border-[#D5E0D7] bg-[#FBFCFB] focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#4A7255]/25 focus:border-[#4A7255] transition-all text-[#1F2923]"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-[#2D3A31] mb-1">
                    Username
                  </label>
                  <input
                    type="text"
                    required
                    value={regUsername}
                    onChange={(e) => setRegUsername(e.target.value)}
                    placeholder="dr_morgan"
                    className="w-full px-3 py-2 text-sm rounded-xl border border-[#D5E0D7] bg-[#FBFCFB] focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#4A7255]/25 focus:border-[#4A7255] transition-all text-[#1F2923]"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#2D3A31] mb-1">
                  Password (min 6 characters)
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-[#7A8E80]">
                    <Lock className="w-4 h-4" />
                  </div>
                  <input
                    type={showPassword ? 'text' : 'password'}
                    required
                    minLength={6}
                    value={regPassword}
                    onChange={(e) => setRegPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full pl-9 pr-10 py-2 text-sm rounded-xl border border-[#D5E0D7] bg-[#FBFCFB] focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#4A7255]/25 focus:border-[#4A7255] transition-all text-[#1F2923]"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute inset-y-0 right-0 pr-3 flex items-center text-[#7A8E80] hover:text-[#36573F]"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#2D3A31] mb-1">
                  Confirm Password
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-[#7A8E80]">
                    <Lock className="w-4 h-4" />
                  </div>
                  <input
                    type={showConfirmPassword ? 'text' : 'password'}
                    required
                    minLength={6}
                    value={regConfirmPassword}
                    onChange={(e) => setRegConfirmPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full pl-9 pr-10 py-2 text-sm rounded-xl border border-[#D5E0D7] bg-[#FBFCFB] focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#4A7255]/25 focus:border-[#4A7255] transition-all text-[#1F2923]"
                  />
                  <button
                    type="button"
                    onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                    className="absolute inset-y-0 right-0 pr-3 flex items-center text-[#7A8E80] hover:text-[#36573F]"
                  >
                    {showConfirmPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full mt-2 py-2.5 px-4 bg-[#4A7255] hover:bg-[#3C5D45] text-white font-medium text-sm rounded-xl transition-all shadow-sm flex items-center justify-center gap-2"
              >
                {isSubmitting ? 'Creating Account...' : 'Complete Staff Registration'}
              </button>

              <div className="text-center pt-2">
                <p className="text-xs text-[#5D6F63]">
                  Already registered?{' '}
                  <button
                    type="button"
                    onClick={() => {
                      setErrorMessage('');
                      setMode('login');
                    }}
                    className="font-semibold text-[#4A7255] hover:underline"
                  >
                    Sign in here
                  </button>
                </p>
              </div>
            </form>
          )}

          {/* FORGOT PASSWORD FORM */}
          {mode === 'forgot' && (
            <div>
              {forgotStep === 'request' ? (
                <form onSubmit={handleForgotRequest} className="space-y-4">
                  <div className="p-3 bg-[#EEF4F0] rounded-xl text-xs text-[#35523E] leading-relaxed">
                    Enter your registered email address and we will provide a verified security token to reset your password.
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-[#2D3A31] mb-1.5">
                      Registered Email Address
                    </label>
                    <div className="relative">
                      <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-[#7A8E80]">
                        <Mail className="w-4 h-4" />
                      </div>
                      <input
                        type="email"
                        required
                        value={forgotEmail}
                        onChange={(e) => setForgotEmail(e.target.value)}
                        placeholder="your.email@clinic.vet"
                        className="w-full pl-9 pr-3.5 py-2.5 text-sm rounded-xl border border-[#D5E0D7] bg-[#FBFCFB] focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#4A7255]/25 focus:border-[#4A7255] transition-all text-[#1F2923]"
                      />
                    </div>
                  </div>

                  <button
                    type="submit"
                    className="w-full py-2.5 px-4 bg-[#4A7255] hover:bg-[#3C5D45] text-white font-medium text-sm rounded-xl transition-all shadow-sm"
                  >
                    Send Verification Code
                  </button>

                  <div className="text-center pt-2">
                    <button
                      type="button"
                      onClick={() => {
                        setErrorMessage('');
                        setMode('login');
                      }}
                      className="text-xs text-[#4A7255] hover:underline"
                    >
                      Back to Sign In
                    </button>
                  </div>
                </form>
              ) : (
                <form onSubmit={handleResetSubmit} className="space-y-3.5">
                  <div className="p-3 bg-[#EAF2EC] rounded-xl text-xs text-[#294231] flex items-center gap-2">
                    <Sparkles className="w-4 h-4 text-[#4A7255] shrink-0" />
                    <span>A 6-digit verification code has been simulated for <strong>{forgotEmail}</strong>.</span>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-[#2D3A31] mb-1">
                      Verification Code
                    </label>
                    <input
                      type="text"
                      required
                      value={resetCode}
                      onChange={(e) => setResetCode(e.target.value)}
                      placeholder="e.g. 742198"
                      className="w-full px-3 py-2 text-sm rounded-xl border border-[#D5E0D7] bg-[#FBFCFB] focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#4A7255] text-[#1F2923]"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-[#2D3A31] mb-1">
                      New Password
                    </label>
                    <input
                      type="password"
                      required
                      minLength={6}
                      value={newPassword}
                      onChange={(e) => setNewPassword(e.target.value)}
                      placeholder="At least 6 characters"
                      className="w-full px-3 py-2 text-sm rounded-xl border border-[#D5E0D7] bg-[#FBFCFB] focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#4A7255] text-[#1F2923]"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-[#2D3A31] mb-1">
                      Confirm New Password
                    </label>
                    <input
                      type="password"
                      required
                      minLength={6}
                      value={confirmNewPassword}
                      onChange={(e) => setConfirmNewPassword(e.target.value)}
                      placeholder="Confirm new password"
                      className="w-full px-3 py-2 text-sm rounded-xl border border-[#D5E0D7] bg-[#FBFCFB] focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#4A7255] text-[#1F2923]"
                    />
                  </div>

                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="w-full py-2.5 px-4 bg-[#4A7255] hover:bg-[#3C5D45] text-white font-medium text-sm rounded-xl transition-all shadow-sm"
                  >
                    {isSubmitting ? 'Updating...' : 'Save New Password & Sign In'}
                  </button>

                  <div className="text-center pt-2">
                    <button
                      type="button"
                      onClick={() => setForgotStep('request')}
                      className="text-xs text-[#5D6F63] hover:underline"
                    >
                      Resend code or change email
                    </button>
                  </div>
                </form>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
