import React, { useState } from 'react';
import {
  PawPrint,
  Users,
  CalendarDays,
  CalendarCheck2,
  Clock,
  CheckCircle,
  Plus,
  ArrowRight,
  TrendingUp,
  Sparkles,
  ChevronRight,
  UserCheck,
  Stethoscope,
} from 'lucide-react';
import { db } from '../../services/db';
import { useAuth } from '../../context/AuthContext';
import { Appointment, Pet, PetOwner } from '../../types';
import { NavTab } from '../layout/Sidebar';

interface DashboardViewProps {
  onNavigate: (tab: NavTab) => void;
  onOpenQuickAction: (actionType: 'appointment' | 'pet' | 'owner' | 'record') => void;
  onSelectPet: (petId: string) => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  onNavigate,
  onOpenQuickAction,
  onSelectPet,
}) => {
  const { user } = useAuth();
  const [chartView, setChartView] = useState<'week' | 'month'>('week');

  const stats = db.getDashboardStats();
  const appointments = db.getAppointments();
  const pets = db.getPets();
  const owners = db.getOwners();

  // Map of owners for rapid lookup
  const ownerMap = new Map<string, PetOwner>();
  owners.forEach((o) => ownerMap.set(o.id, o));

  // Map of pets
  const petMap = new Map<string, Pet>();
  pets.forEach((p) => petMap.set(p.id, p));

  // Recent 5 appointments sorted
  const recentAppointments = [...appointments].slice(0, 5);

  // Recently registered 4 pets
  const recentPets = [...pets].slice(0, 4);

  // Weekly data calculations
  const weekDays = [
    { day: 'Mon', count: 4, completed: 3, pending: 1 },
    { day: 'Tue', count: 6, completed: 5, pending: 1 },
    { day: 'Wed', count: 5, completed: 4, pending: 1 },
    { day: 'Thu', count: 8, completed: 6, pending: 2 },
    { day: 'Fri', count: 7, completed: 5, pending: 2 },
    { day: 'Sat', count: 4, completed: 3, pending: 1 },
    { day: 'Sun', count: 2, completed: 2, pending: 0 },
  ];

  const monthWeeks = [
    { label: 'Week 1', count: 24 },
    { label: 'Week 2', count: 31 },
    { label: 'Week 3', count: 28 },
    { label: 'Week 4 (Current)', count: 36 },
  ];

  const maxWeeklyCount = 10;
  const maxMonthlyCount = 40;

  return (
    <div className="space-y-6">
      {/* Welcome Banner Card */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-[#2F4735] to-[#3B5B43] text-white p-6 md:p-8 shadow-sm">
        {/* Subtle decorative background glow */}
        <div className="absolute right-0 top-0 w-80 h-full opacity-20 pointer-events-none">
          <img
            src="/src/assets/images/vet_clinic_hero_1793857119970.jpg"
            alt="Clinic Hero"
            className="w-full h-full object-cover"
            referrerPolicy="no-referrer"
          />
        </div>

        <div className="relative z-10 max-w-2xl">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/15 text-[#D4E8D7] text-xs font-medium mb-3 backdrop-blur-sm">
            <Sparkles className="w-3.5 h-3.5 text-[#A5D2AC]" />
            <span>Clinic Operational Shift · Ready for Consultations</span>
          </div>
          <h2 className="text-xl md:text-2xl font-bold font-display leading-snug">
            Welcome back, {user?.fullName || 'Doctor'}
          </h2>
          <p className="text-[#CDE1D1] text-xs md:text-sm mt-1.5 leading-relaxed">
            There are <strong>{stats.todayAppointments} appointments</strong> scheduled for today, with {stats.pendingAppointments} pending check-ins. All veterinary examination suites are operational.
          </p>

          {/* Quick Actions Row */}
          <div className="mt-5 flex flex-wrap gap-2.5">
            <button
              onClick={() => onOpenQuickAction('appointment')}
              className="inline-flex items-center gap-2 px-3.5 py-2 bg-white text-[#294231] hover:bg-[#F3F7F4] text-xs font-semibold rounded-xl shadow-sm transition-all"
            >
              <Plus className="w-4 h-4 text-[#4A7255]" />
              <span>Schedule Appointment</span>
            </button>
            <button
              onClick={() => onOpenQuickAction('pet')}
              className="inline-flex items-center gap-2 px-3.5 py-2 bg-white/15 hover:bg-white/25 text-white text-xs font-semibold rounded-xl backdrop-blur-sm transition-all"
            >
              <PawPrint className="w-4 h-4 text-[#A8D3AF]" />
              <span>Register Pet</span>
            </button>
            <button
              onClick={() => onOpenQuickAction('owner')}
              className="inline-flex items-center gap-2 px-3.5 py-2 bg-white/15 hover:bg-white/25 text-white text-xs font-semibold rounded-xl backdrop-blur-sm transition-all"
            >
              <Users className="w-4 h-4 text-[#A8D3AF]" />
              <span>Add Pet Owner</span>
            </button>
            <button
              onClick={() => onOpenQuickAction('record')}
              className="inline-flex items-center gap-2 px-3.5 py-2 bg-white/15 hover:bg-white/25 text-white text-xs font-semibold rounded-xl backdrop-blur-sm transition-all"
            >
              <Stethoscope className="w-4 h-4 text-[#A8D3AF]" />
              <span>New Medical Record</span>
            </button>
          </div>
        </div>
      </div>

      {/* 6 Metric Statistics Cards */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3.5">
        {/* Total Pets */}
        <div className="bg-white rounded-2xl p-4 border border-[#E2EAE4] shadow-sm hover:border-[#4A7255]/40 transition-colors">
          <div className="flex items-center justify-between text-[#55695C] mb-2">
            <span className="text-xs font-medium">Total Pets</span>
            <div className="w-8 h-8 rounded-lg bg-[#EBF3ED] text-[#4A7255] flex items-center justify-center">
              <PawPrint className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-bold font-display text-[#1E2922] tabular-nums">
            {stats.totalRegisteredPets}
          </div>
          <span className="text-[11px] text-[#718677] mt-0.5 block">Active canine & feline</span>
        </div>

        {/* Total Pet Owners */}
        <div className="bg-white rounded-2xl p-4 border border-[#E2EAE4] shadow-sm hover:border-[#4A7255]/40 transition-colors">
          <div className="flex items-center justify-between text-[#55695C] mb-2">
            <span className="text-xs font-medium">Pet Owners</span>
            <div className="w-8 h-8 rounded-lg bg-[#F2F5E8] text-[#5F7C3E] flex items-center justify-center">
              <Users className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-bold font-display text-[#1E2922] tabular-nums">
            {stats.totalPetOwners}
          </div>
          <span className="text-[11px] text-[#718677] mt-0.5 block">Registered clients</span>
        </div>

        {/* Total Appointments */}
        <div className="bg-white rounded-2xl p-4 border border-[#E2EAE4] shadow-sm hover:border-[#4A7255]/40 transition-colors">
          <div className="flex items-center justify-between text-[#55695C] mb-2">
            <span className="text-xs font-medium">Total Bookings</span>
            <div className="w-8 h-8 rounded-lg bg-[#EAF2F5] text-[#346F8C] flex items-center justify-center">
              <CalendarDays className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-bold font-display text-[#1E2922] tabular-nums">
            {stats.totalAppointments}
          </div>
          <span className="text-[11px] text-[#718677] mt-0.5 block">All consultations</span>
        </div>

        {/* Today's Appointments */}
        <div className="bg-[#F0F6F2] rounded-2xl p-4 border border-[#CDE0D2] shadow-sm">
          <div className="flex items-center justify-between text-[#385B41] mb-2">
            <span className="text-xs font-semibold">Today's Visits</span>
            <div className="w-8 h-8 rounded-lg bg-[#4A7255] text-white flex items-center justify-center shadow-xs">
              <CalendarCheck2 className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-bold font-display text-[#1E3B25] tabular-nums">
            {stats.todayAppointments}
          </div>
          <span className="text-[11px] text-[#476C50] mt-0.5 block font-medium">Scheduled today</span>
        </div>

        {/* Completed Appointments */}
        <div className="bg-white rounded-2xl p-4 border border-[#E2EAE4] shadow-sm hover:border-[#4A7255]/40 transition-colors">
          <div className="flex items-center justify-between text-[#55695C] mb-2">
            <span className="text-xs font-medium">Completed</span>
            <div className="w-8 h-8 rounded-lg bg-[#E9F5EB] text-[#2F855A] flex items-center justify-center">
              <CheckCircle className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-bold font-display text-[#1E2922] tabular-nums">
            {stats.completedAppointments}
          </div>
          <span className="text-[11px] text-[#718677] mt-0.5 block">Discharged visits</span>
        </div>

        {/* Pending Appointments */}
        <div className="bg-white rounded-2xl p-4 border border-[#E2EAE4] shadow-sm hover:border-[#4A7255]/40 transition-colors">
          <div className="flex items-center justify-between text-[#55695C] mb-2">
            <span className="text-xs font-medium">Pending</span>
            <div className="w-8 h-8 rounded-lg bg-[#FBF3E8] text-[#B06F23] flex items-center justify-center">
              <Clock className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-bold font-display text-[#1E2922] tabular-nums">
            {stats.pendingAppointments}
          </div>
          <span className="text-[11px] text-[#718677] mt-0.5 block">Awaiting consult</span>
        </div>
      </div>

      {/* Interactive Appointment Analytics Chart */}
      <div className="bg-white rounded-2xl p-6 border border-[#E2EAE4] shadow-sm">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-6">
          <div>
            <h3 className="text-base font-bold font-display text-[#1F2923]">
              Consultation Volume & Scheduling Dynamics
            </h3>
            <p className="text-xs text-[#5D7063] mt-0.5">
              Weekly distribution of canine, feline, and exotic veterinary appointments
            </p>
          </div>

          {/* Segmented Chart View Selector */}
          <div className="inline-flex items-center p-1 bg-[#EEF3EF] rounded-xl self-start sm:self-auto">
            <button
              onClick={() => setChartView('week')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all ${
                chartView === 'week'
                  ? 'bg-white text-[#294231] shadow-xs'
                  : 'text-[#5B7162] hover:text-[#294231]'
              }`}
            >
              This Week
            </button>
            <button
              onClick={() => setChartView('month')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all ${
                chartView === 'month'
                  ? 'bg-white text-[#294231] shadow-xs'
                  : 'text-[#5B7162] hover:text-[#294231]'
              }`}
            >
              Monthly Summary
            </button>
          </div>
        </div>

        {/* Visual Bar Chart */}
        {chartView === 'week' ? (
          <div className="space-y-3">
            <div className="grid grid-cols-7 gap-2 md:gap-4 items-end h-44 pt-4 border-b border-[#EDF3EE] pb-2">
              {weekDays.map((item) => {
                const heightPercent = Math.min(100, Math.round((item.count / maxWeeklyCount) * 100));
                return (
                  <div key={item.day} className="flex flex-col items-center h-full justify-end group">
                    <span className="text-[11px] font-mono text-[#586F60] font-semibold mb-1 tabular-nums group-hover:text-[#294231]">
                      {item.count}
                    </span>
                    <div className="w-full max-w-[42px] bg-[#EEF4EF] rounded-t-xl overflow-hidden h-full flex flex-col justify-end p-0.5">
                      <div
                        style={{ height: `${heightPercent}%` }}
                        className="w-full bg-[#4A7255] group-hover:bg-[#3B5D44] transition-all rounded-t-lg relative"
                      />
                    </div>
                    <span className="text-xs font-medium text-[#4D6153] mt-2 block">
                      {item.day}
                    </span>
                  </div>
                );
              })}
            </div>
            <div className="flex items-center justify-between text-xs text-[#6B8272] pt-1">
              <div className="flex items-center gap-4">
                <span className="flex items-center gap-1.5">
                  <span className="w-2.5 h-2.5 rounded-sm bg-[#4A7255]" />
                  <span>Scheduled Consultations</span>
                </span>
                <span className="flex items-center gap-1.5">
                  <span className="w-2.5 h-2.5 rounded-sm bg-[#EEF4EF] border border-[#CCD8CF]" />
                  <span>Available Slot Capacity</span>
                </span>
              </div>
              <span className="tabular-nums font-mono">Capacity Avg: 85%</span>
            </div>
          </div>
        ) : (
          <div className="space-y-3">
            <div className="grid grid-cols-4 gap-4 items-end h-44 pt-4 border-b border-[#EDF3EE] pb-2">
              {monthWeeks.map((item) => {
                const heightPercent = Math.min(100, Math.round((item.count / maxMonthlyCount) * 100));
                return (
                  <div key={item.label} className="flex flex-col items-center h-full justify-end group">
                    <span className="text-xs font-mono text-[#586F60] font-semibold mb-1 tabular-nums group-hover:text-[#294231]">
                      {item.count} visits
                    </span>
                    <div className="w-full max-w-[64px] bg-[#EEF4EF] rounded-t-xl overflow-hidden h-full flex flex-col justify-end p-0.5">
                      <div
                        style={{ height: `${heightPercent}%` }}
                        className="w-full bg-[#5D8569] group-hover:bg-[#4A7255] transition-all rounded-t-lg"
                      />
                    </div>
                    <span className="text-xs font-medium text-[#4D6153] mt-2 block text-center truncate">
                      {item.label}
                    </span>
                  </div>
                );
              })}
            </div>
            <div className="flex items-center justify-between text-xs text-[#6B8272] pt-1">
              <span>Total this calendar month: 119 consultations</span>
              <span className="text-[#327346] font-medium">+14% vs previous month</span>
            </div>
          </div>
        )}
      </div>

      {/* Two Column Grid: Recent Appointments & Recently Registered Pets */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Left: Recent / Upcoming Appointments */}
        <div className="bg-white rounded-2xl p-6 border border-[#E2EAE4] shadow-sm flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="text-base font-bold font-display text-[#1F2923]">
                  Upcoming & Recent Appointments
                </h3>
                <p className="text-xs text-[#667B6D] mt-0.5">
                  Scheduled time slots and verified clinical status
                </p>
              </div>
              <button
                onClick={() => onNavigate('appointments')}
                className="text-xs font-semibold text-[#4A7255] hover:text-[#36573F] inline-flex items-center gap-1 transition-colors"
              >
                <span>View all</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="space-y-3">
              {recentAppointments.length === 0 ? (
                <div className="text-center py-8 text-xs text-[#718778]">
                  No appointments scheduled.
                </div>
              ) : (
                recentAppointments.map((apt) => {
                  const pet = petMap.get(apt.petId);
                  const owner = ownerMap.get(apt.ownerId);

                  const statusColors: Record<string, string> = {
                    Pending: 'bg-[#FFF8EE] text-[#9A6216] border-[#F2D7B2]',
                    Confirmed: 'bg-[#EDF7F0] text-[#2F683D] border-[#C2E4CD]',
                    Completed: 'bg-[#F2F4F7] text-[#475467] border-[#D0D5DD]',
                    Cancelled: 'bg-[#FEF3F2] text-[#B42318] border-[#FECDCA]',
                  };

                  return (
                    <div
                      key={apt.id}
                      className="p-3.5 rounded-xl border border-[#E7EFE9] bg-[#FBFCFB] hover:border-[#CADACD] transition-all flex items-center justify-between gap-3"
                    >
                      <div className="flex items-center gap-3 min-w-0">
                        {pet?.photoUrl ? (
                          <img
                            src={pet.photoUrl}
                            alt={pet.name}
                            className="w-10 h-10 rounded-xl object-cover border border-[#D5E1D7] shrink-0"
                            referrerPolicy="no-referrer"
                          />
                        ) : (
                          <div className="w-10 h-10 rounded-xl bg-[#EAF2EC] text-[#4A7255] flex items-center justify-center font-bold text-sm shrink-0">
                            {pet?.name?.charAt(0) || 'P'}
                          </div>
                        )}

                        <div className="min-w-0">
                          <div className="flex items-center gap-2">
                            <span className="text-xs font-bold text-[#1F2C23] truncate">
                              {pet?.name || 'Pet'}
                            </span>
                            <span className="text-[11px] text-[#6E8173] truncate">
                              ({pet?.species || 'Animal'})
                            </span>
                          </div>
                          <p className="text-xs text-[#4F6355] truncate mt-0.5">
                            {apt.reasonForVisit}
                          </p>
                          <div className="flex items-center gap-2 text-[11px] text-[#7A8E80] mt-0.5">
                            <span className="font-mono tabular-nums">{apt.appointmentDate} at {apt.appointmentTime}</span>
                            <span>·</span>
                            <span className="truncate">{owner?.fullName || 'Owner'}</span>
                          </div>
                        </div>
                      </div>

                      <div className="shrink-0 text-right">
                        <span
                          className={`inline-block px-2.5 py-1 text-[11px] font-semibold rounded-lg border ${
                            statusColors[apt.status] || 'bg-gray-100 text-gray-700'
                          }`}
                        >
                          {apt.status}
                        </span>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-[#EDF3EE] flex items-center justify-between text-xs text-[#6B8272]">
            <span>Active veterinary staff on duty: 2</span>
            <button
              onClick={() => onOpenQuickAction('appointment')}
              className="font-medium text-[#4A7255] hover:underline"
            >
              + Quick booking
            </button>
          </div>
        </div>

        {/* Right: Recently Registered Pets */}
        <div className="bg-white rounded-2xl p-6 border border-[#E2EAE4] shadow-sm flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="text-base font-bold font-display text-[#1F2923]">
                  Recently Registered Pets
                </h3>
                <p className="text-xs text-[#667B6D] mt-0.5">
                  Latest companion animals admitted to the clinic registry
                </p>
              </div>
              <button
                onClick={() => onNavigate('pets')}
                className="text-xs font-semibold text-[#4A7255] hover:text-[#36573F] inline-flex items-center gap-1 transition-colors"
              >
                <span>All pets</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="space-y-3">
              {recentPets.map((pet) => {
                const owner = ownerMap.get(pet.ownerId);
                return (
                  <div
                    key={pet.id}
                    onClick={() => onSelectPet(pet.id)}
                    className="p-3 rounded-xl border border-[#E7EFE9] bg-[#FBFCFB] hover:border-[#4A7255]/40 hover:bg-[#F6FAF7] transition-all cursor-pointer flex items-center justify-between gap-3 group"
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      {pet.photoUrl ? (
                        <img
                          src={pet.photoUrl}
                          alt={pet.name}
                          className="w-11 h-11 rounded-xl object-cover border border-[#D5E1D7] shrink-0 group-hover:scale-105 transition-transform"
                          referrerPolicy="no-referrer"
                        />
                      ) : (
                        <div className="w-11 h-11 rounded-xl bg-[#EAF2EC] text-[#4A7255] flex items-center justify-center font-bold text-sm shrink-0">
                          {pet.name.charAt(0)}
                        </div>
                      )}

                      <div className="min-w-0">
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-bold text-[#1F2C23] group-hover:text-[#32523B] transition-colors truncate">
                            {pet.name}
                          </span>
                          <span className="text-[11px] px-2 py-0.5 rounded-md bg-[#EDF3EF] text-[#415949] font-medium">
                            {pet.species}
                          </span>
                        </div>
                        <p className="text-[11px] text-[#55695C] truncate mt-0.5">
                          {pet.breed} · {pet.gender} · {pet.ageYears}y {pet.ageMonths}m
                        </p>
                        <p className="text-[11px] text-[#7C9081] truncate">
                          Owner: {owner?.fullName || 'Not assigned'} ({owner?.phoneNumber || 'No phone'})
                        </p>
                      </div>
                    </div>

                    <div className="shrink-0 flex items-center gap-2">
                      <span className="text-xs font-mono font-medium text-[#506556] tabular-nums hidden sm:inline">
                        {pet.weight} kg
                      </span>
                      <ChevronRight className="w-4 h-4 text-[#8FA98F] group-hover:translate-x-0.5 transition-transform" />
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-[#EDF3EE] flex items-center justify-between text-xs text-[#6B8272]">
            <span>Total registered patients: {stats.totalRegisteredPets}</span>
            <button
              onClick={() => onOpenQuickAction('pet')}
              className="font-medium text-[#4A7255] hover:underline"
            >
              + Register new pet
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
