import React, { useState } from 'react';
import {
  Settings,
  User as UserIcon,
  Lock,
  Building2,
  Sliders,
  Database,
  Save,
  Download,
  Upload,
  RefreshCw,
  CheckCircle2,
  Shield,
  Heart,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useNotification } from '../../context/NotificationContext';
import { db } from '../../services/db';
import { ClinicSettings } from '../../types';
import { ConfirmationModal } from '../common/ConfirmationModal';

export const SettingsView: React.FC = () => {
  const { user, updateProfile, changePassword } = useAuth();
  const { notify } = useNotification();

  const [activeSection, setActiveSection] = useState<'profile' | 'security' | 'clinic' | 'preferences' | 'database'>('profile');

  // Profile form state
  const [fullName, setFullName] = useState(user?.fullName || '');
  const [email, setEmail] = useState(user?.email || '');
  const [phone, setPhone] = useState(user?.phone || '');
  const [title, setTitle] = useState(user?.title || '');
  const [bio, setBio] = useState(user?.bio || '');
  const [avatarUrl, setAvatarUrl] = useState(user?.avatarUrl || '');

  // Password change state
  const [oldPassword, setOldPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmNewPassword, setConfirmNewPassword] = useState('');

  // Clinic settings state
  const [clinicSettings, setClinicSettings] = useState<ClinicSettings>(db.getSettings());
  const [clinicName, setClinicName] = useState(clinicSettings.clinicName);
  const [tagline, setTagline] = useState(clinicSettings.tagline);
  const [clinicPhone, setClinicPhone] = useState(clinicSettings.phoneNumber);
  const [emergencyHotline, setEmergencyHotline] = useState(clinicSettings.emergencyHotline);
  const [clinicEmail, setClinicEmail] = useState(clinicSettings.emailAddress);
  const [clinicAddress, setClinicAddress] = useState(clinicSettings.address);
  const [weekdaysHours, setWeekdaysHours] = useState(clinicSettings.operatingHours.weekdays);
  const [satHours, setSatHours] = useState(clinicSettings.operatingHours.saturday);
  const [sunHours, setSunHours] = useState(clinicSettings.operatingHours.sunday);
  const [weightUnit, setWeightUnit] = useState<'kg' | 'lbs'>(clinicSettings.weightUnit);
  const [tempUnit, setTempUnit] = useState<'°C' | '°F'>(clinicSettings.temperatureUnit);

  // Database reset modal
  const [isResetConfirmOpen, setIsResetConfirmOpen] = useState(false);

  const handleProfileSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    await updateProfile({
      fullName,
      email,
      phone,
      title,
      bio,
      avatarUrl,
    });
  };

  const handlePasswordSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (newPassword !== confirmNewPassword) {
      notify({
        type: 'error',
        title: 'Password Mismatch',
        message: 'The new passwords do not match.',
      });
      return;
    }
    const success = await changePassword(oldPassword, newPassword);
    if (success) {
      setOldPassword('');
      setNewPassword('');
      setConfirmNewPassword('');
    }
  };

  const handleClinicSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const updated = db.updateSettings({
      clinicName,
      tagline,
      phoneNumber: clinicPhone,
      emergencyHotline,
      emailAddress: clinicEmail,
      address: clinicAddress,
      operatingHours: {
        weekdays: weekdaysHours,
        saturday: satHours,
        sunday: sunHours,
      },
      weightUnit,
      temperatureUnit: tempUnit,
    });
    setClinicSettings(updated);
    notify({
      type: 'success',
      title: 'Clinic Information Saved',
      message: 'Updated operating details and branding across the system.',
    });
  };

  const handleExportDatabase = () => {
    const jsonStr = db.exportData();
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `sage_paw_backup_${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);
    notify({
      type: 'success',
      title: 'Database Exported',
      message: 'Full backup JSON file downloaded successfully.',
    });
  };

  const handleImportDatabase = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      const success = db.importData(content);
      if (success) {
        notify({
          type: 'success',
          title: 'Database Restored',
          message: 'All patients, appointments, and medical records were restored.',
        });
        window.location.reload();
      } else {
        notify({
          type: 'error',
          title: 'Import Failed',
          message: 'Invalid backup file structure.',
        });
      }
    };
    reader.readAsText(file);
  };

  const handleResetToDefaults = () => {
    db.resetToDefaults();
    setIsResetConfirmOpen(false);
    notify({
      type: 'info',
      title: 'Database Re-seeded',
      message: 'Reset clinic records to default verified sample patients.',
    });
    window.location.reload();
  };

  return (
    <div className="space-y-6">
      {/* Settings Navigation Tabs */}
      <div className="flex items-center gap-1.5 p-1.5 bg-white rounded-2xl border border-[#E2EAE4] shadow-sm overflow-x-auto">
        <button
          onClick={() => setActiveSection('profile')}
          className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-semibold transition-all whitespace-nowrap ${
            activeSection === 'profile'
              ? 'bg-[#4A7255] text-white shadow-xs'
              : 'text-[#5A7061] hover:text-[#1F2923] hover:bg-[#F3F6F3]'
          }`}
        >
          <UserIcon className="w-4 h-4" />
          <span>Practitioner Profile</span>
        </button>

        <button
          onClick={() => setActiveSection('clinic')}
          className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-semibold transition-all whitespace-nowrap ${
            activeSection === 'clinic'
              ? 'bg-[#4A7255] text-white shadow-xs'
              : 'text-[#5A7061] hover:text-[#1F2923] hover:bg-[#F3F6F3]'
          }`}
        >
          <Building2 className="w-4 h-4" />
          <span>Clinic Information</span>
        </button>

        <button
          onClick={() => setActiveSection('security')}
          className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-semibold transition-all whitespace-nowrap ${
            activeSection === 'security'
              ? 'bg-[#4A7255] text-white shadow-xs'
              : 'text-[#5A7061] hover:text-[#1F2923] hover:bg-[#F3F6F3]'
          }`}
        >
          <Lock className="w-4 h-4" />
          <span>Security & Password</span>
        </button>

        <button
          onClick={() => setActiveSection('database')}
          className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-semibold transition-all whitespace-nowrap ${
            activeSection === 'database'
              ? 'bg-[#4A7255] text-white shadow-xs'
              : 'text-[#5A7061] hover:text-[#1F2923] hover:bg-[#F3F6F3]'
          }`}
        >
          <Database className="w-4 h-4" />
          <span>Database Management</span>
        </button>
      </div>

      {/* 1. PRACTITIONER PROFILE */}
      {activeSection === 'profile' && (
        <div className="bg-white rounded-2xl border border-[#E2EAE4] p-6 shadow-sm max-w-3xl">
          <div className="mb-5 pb-4 border-b border-[#EDF3EE]">
            <h3 className="text-base font-bold font-display text-[#1F2923]">
              Veterinary Practitioner Profile
            </h3>
            <p className="text-xs text-[#63796A] mt-0.5">
              Personal credentials and contact info displayed on medical consultation dossiers
            </p>
          </div>

          <form onSubmit={handleProfileSubmit} className="space-y-4 text-xs text-[#1F2923]">
            {/* Avatar Row */}
            <div className="flex items-center gap-4 p-4 rounded-xl bg-[#F7FAF8] border border-[#E3ECE5]">
              <img
                src={avatarUrl || '/src/assets/images/vet_doctor_avatar_1793857120858.jpg'}
                alt="Profile Avatar"
                className="w-16 h-16 rounded-2xl object-cover border-2 border-white shadow-xs"
                referrerPolicy="no-referrer"
              />
              <div className="flex-1 min-w-0">
                <span className="font-semibold block text-xs text-[#2A4030]">Profile Photo</span>
                <input
                  type="text"
                  value={avatarUrl}
                  onChange={(e) => setAvatarUrl(e.target.value)}
                  placeholder="Avatar image path or URL"
                  className="mt-1 w-full px-3 py-1.5 rounded-lg border border-[#D5E0D7] bg-white text-xs font-mono"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block font-semibold mb-1 text-[#2D3A31]">Full Name *</label>
                <input
                  type="text"
                  required
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-[#D5E0D7] bg-[#FBFCFB] focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#4A7255]"
                />
              </div>

              <div>
                <label className="block font-semibold mb-1 text-[#2D3A31]">Clinical Title / Specialization</label>
                <input
                  type="text"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="Lead Veterinarian, DVM"
                  className="w-full px-3 py-2 rounded-xl border border-[#D5E0D7] bg-[#FBFCFB] focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#4A7255]"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block font-semibold mb-1 text-[#2D3A31]">Email Address *</label>
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-[#D5E0D7] bg-[#FBFCFB] focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#4A7255]"
                />
              </div>

              <div>
                <label className="block font-semibold mb-1 text-[#2D3A31]">Phone Number</label>
                <input
                  type="tel"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="+1 (555) 234-8901"
                  className="w-full px-3 py-2 rounded-xl border border-[#D5E0D7] bg-[#FBFCFB] focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#4A7255]"
                />
              </div>
            </div>

            <div>
              <label className="block font-semibold mb-1 text-[#2D3A31]">Professional Bio</label>
              <textarea
                rows={3}
                value={bio}
                onChange={(e) => setBio(e.target.value)}
                placeholder="Clinical background, veterinary surgery certifications, patient approach..."
                className="w-full px-3 py-2 rounded-xl border border-[#D5E0D7] bg-[#FBFCFB] focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#4A7255]"
              />
            </div>

            <div className="pt-3 border-t border-[#EDF3EE] flex justify-end">
              <button
                type="submit"
                className="inline-flex items-center gap-2 px-5 py-2 bg-[#4A7255] hover:bg-[#3C5D45] text-white font-semibold rounded-xl shadow-sm transition-all"
              >
                <Save className="w-4 h-4" />
                <span>Save Profile Information</span>
              </button>
            </div>
          </form>
        </div>
      )}

      {/* 2. CLINIC INFORMATION */}
      {activeSection === 'clinic' && (
        <div className="bg-white rounded-2xl border border-[#E2EAE4] p-6 shadow-sm max-w-3xl">
          <div className="mb-5 pb-4 border-b border-[#EDF3EE]">
            <h3 className="text-base font-bold font-display text-[#1F2923]">
              Clinic & Hospital Details
            </h3>
            <p className="text-xs text-[#63796A] mt-0.5">
              Operating hours, emergency contact, clinic location and units
            </p>
          </div>

          <form onSubmit={handleClinicSubmit} className="space-y-4 text-xs text-[#1F2923]">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block font-semibold mb-1 text-[#2D3A31]">Clinic Name *</label>
                <input
                  type="text"
                  required
                  value={clinicName}
                  onChange={(e) => setClinicName(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-[#D5E0D7] bg-[#FBFCFB] focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#4A7255]"
                />
              </div>
              <div>
                <label className="block font-semibold mb-1 text-[#2D3A31]">Tagline / Slogan</label>
                <input
                  type="text"
                  value={tagline}
                  onChange={(e) => setTagline(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-[#D5E0D7] bg-[#FBFCFB] focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#4A7255]"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="block font-semibold mb-1 text-[#2D3A31]">Main Reception Phone</label>
                <input
                  type="tel"
                  value={clinicPhone}
                  onChange={(e) => setClinicPhone(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-[#D5E0D7] bg-[#FBFCFB] focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#4A7255]"
                />
              </div>
              <div>
                <label className="block font-semibold mb-1 text-[#2D3A31]">Emergency 24/7 Hotline</label>
                <input
                  type="tel"
                  value={emergencyHotline}
                  onChange={(e) => setEmergencyHotline(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-[#D5E0D7] bg-[#FBFCFB] focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#4A7255]"
                />
              </div>
              <div>
                <label className="block font-semibold mb-1 text-[#2D3A31]">Clinic Inquiries Email</label>
                <input
                  type="email"
                  value={clinicEmail}
                  onChange={(e) => setClinicEmail(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-[#D5E0D7] bg-[#FBFCFB] focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#4A7255]"
                />
              </div>
            </div>

            <div>
              <label className="block font-semibold mb-1 text-[#2D3A31]">Physical Facility Address</label>
              <input
                type="text"
                value={clinicAddress}
                onChange={(e) => setClinicAddress(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-[#D5E0D7] bg-[#FBFCFB] focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#4A7255]"
              />
            </div>

            <div className="p-3.5 rounded-xl border border-[#E3ECE5] bg-[#F8FAF8] space-y-3">
              <span className="font-bold text-[#2C4432] block">Operating Hours</span>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-[11px] font-semibold text-[#576D5E] mb-1">
                    Monday – Friday
                  </label>
                  <input
                    type="text"
                    value={weekdaysHours}
                    onChange={(e) => setWeekdaysHours(e.target.value)}
                    className="w-full px-2.5 py-1.5 rounded-lg border border-[#D5E0D7] bg-white text-xs"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-semibold text-[#576D5E] mb-1">
                    Saturday
                  </label>
                  <input
                    type="text"
                    value={satHours}
                    onChange={(e) => setSatHours(e.target.value)}
                    className="w-full px-2.5 py-1.5 rounded-lg border border-[#D5E0D7] bg-white text-xs"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-semibold text-[#576D5E] mb-1">
                    Sunday
                  </label>
                  <input
                    type="text"
                    value={sunHours}
                    onChange={(e) => setSunHours(e.target.value)}
                    className="w-full px-2.5 py-1.5 rounded-lg border border-[#D5E0D7] bg-white text-xs"
                  />
                </div>
              </div>
            </div>

            {/* Units */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-1">
              <div>
                <label className="block font-semibold mb-1 text-[#2D3A31]">Measurement Unit (Weight)</label>
                <select
                  value={weightUnit}
                  onChange={(e) => setWeightUnit(e.target.value as 'kg' | 'lbs')}
                  className="w-full px-3 py-2 rounded-xl border border-[#D5E0D7] bg-[#FBFCFB]"
                >
                  <option value="kg">Kilograms (kg)</option>
                  <option value="lbs">Pounds (lbs)</option>
                </select>
              </div>
              <div>
                <label className="block font-semibold mb-1 text-[#2D3A31]">Measurement Unit (Temperature)</label>
                <select
                  value={tempUnit}
                  onChange={(e) => setTempUnit(e.target.value as '°C' | '°F')}
                  className="w-full px-3 py-2 rounded-xl border border-[#D5E0D7] bg-[#FBFCFB]"
                >
                  <option value="°C">Celsius (°C)</option>
                  <option value="°F">Fahrenheit (°F)</option>
                </select>
              </div>
            </div>

            <div className="pt-3 border-t border-[#EDF3EE] flex justify-end">
              <button
                type="submit"
                className="inline-flex items-center gap-2 px-5 py-2 bg-[#4A7255] hover:bg-[#3C5D45] text-white font-semibold rounded-xl shadow-sm transition-all"
              >
                <Save className="w-4 h-4" />
                <span>Save Clinic Settings</span>
              </button>
            </div>
          </form>
        </div>
      )}

      {/* 3. SECURITY & PASSWORD */}
      {activeSection === 'security' && (
        <div className="bg-white rounded-2xl border border-[#E2EAE4] p-6 shadow-sm max-w-xl">
          <div className="mb-5 pb-4 border-b border-[#EDF3EE]">
            <h3 className="text-base font-bold font-display text-[#1F2923]">
              Update Security Password
            </h3>
            <p className="text-xs text-[#63796A] mt-0.5">
              Ensure your veterinary staff account uses a strong, secure passphrase
            </p>
          </div>

          <form onSubmit={handlePasswordSubmit} className="space-y-4 text-xs text-[#1F2923]">
            <div>
              <label className="block font-semibold mb-1 text-[#2D3A31]">Current Password *</label>
              <input
                type="password"
                required
                value={oldPassword}
                onChange={(e) => setOldPassword(e.target.value)}
                placeholder="Enter current password"
                className="w-full px-3 py-2 rounded-xl border border-[#D5E0D7] bg-[#FBFCFB] focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#4A7255]"
              />
            </div>

            <div>
              <label className="block font-semibold mb-1 text-[#2D3A31]">New Password (min 6 chars) *</label>
              <input
                type="password"
                required
                minLength={6}
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                placeholder="New password"
                className="w-full px-3 py-2 rounded-xl border border-[#D5E0D7] bg-[#FBFCFB] focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#4A7255]"
              />
            </div>

            <div>
              <label className="block font-semibold mb-1 text-[#2D3A31]">Confirm New Password *</label>
              <input
                type="password"
                required
                minLength={6}
                value={confirmNewPassword}
                onChange={(e) => setConfirmNewPassword(e.target.value)}
                placeholder="Re-enter new password"
                className="w-full px-3 py-2 rounded-xl border border-[#D5E0D7] bg-[#FBFCFB] focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#4A7255]"
              />
            </div>

            <div className="pt-3 border-t border-[#EDF3EE] flex justify-end">
              <button
                type="submit"
                className="inline-flex items-center gap-2 px-5 py-2 bg-[#4A7255] hover:bg-[#3C5D45] text-white font-semibold rounded-xl shadow-sm transition-all"
              >
                <Lock className="w-4 h-4" />
                <span>Update Password</span>
              </button>
            </div>
          </form>
        </div>
      )}

      {/* 4. DATABASE MANAGEMENT */}
      {activeSection === 'database' && (
        <div className="bg-white rounded-2xl border border-[#E2EAE4] p-6 shadow-sm max-w-2xl space-y-6">
          <div className="pb-4 border-b border-[#EDF3EE]">
            <h3 className="text-base font-bold font-display text-[#1F2923]">
              Database Operations & Data Portability
            </h3>
            <p className="text-xs text-[#63796A] mt-0.5">
              Permanent persistence, JSON backups, and sample records management
            </p>
          </div>

          {/* Backup Export */}
          <div className="p-4 rounded-xl bg-[#F7FAF8] border border-[#E3ECE5] flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <span className="font-bold text-xs text-[#283E2D] block">Export Full Database Backup</span>
              <p className="text-[11px] text-[#63796A] mt-0.5">
                Download a verified JSON backup containing all patients, owners, appointments, and medical records.
              </p>
            </div>
            <button
              onClick={handleExportDatabase}
              className="inline-flex items-center gap-1.5 px-4 py-2 bg-[#4A7255] hover:bg-[#3C5D45] text-white text-xs font-semibold rounded-xl shadow-sm transition-all shrink-0"
            >
              <Download className="w-4 h-4" />
              <span>Export JSON</span>
            </button>
          </div>

          {/* Backup Import */}
          <div className="p-4 rounded-xl bg-[#F7FAF8] border border-[#E3ECE5] flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <span className="font-bold text-xs text-[#283E2D] block">Import Database from JSON</span>
              <p className="text-[11px] text-[#63796A] mt-0.5">
                Restore clinical records from an existing backup file.
              </p>
            </div>
            <label className="inline-flex items-center gap-1.5 px-4 py-2 bg-[#EEF4EF] hover:bg-[#E2ECE4] text-[#294231] text-xs font-semibold rounded-xl transition-all cursor-pointer shrink-0">
              <Upload className="w-4 h-4" />
              <span>Upload Backup</span>
              <input
                type="file"
                accept=".json"
                onChange={handleImportDatabase}
                className="hidden"
              />
            </label>
          </div>

          {/* Reset to Sample State */}
          <div className="p-4 rounded-xl bg-[#FEF6F6] border border-[#FAD7D7] flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <span className="font-bold text-xs text-[#9E2A2B] block">Re-seed Default Sample Clinic Data</span>
              <p className="text-[11px] text-[#9E2A2B]/80 mt-0.5">
                Restores the verified sample veterinary clinic database with pre-configured pets, owners, and consultations.
              </p>
            </div>
            <button
              onClick={() => setIsResetConfirmOpen(true)}
              className="inline-flex items-center gap-1.5 px-4 py-2 bg-[#B92A2A] hover:bg-[#A32222] text-white text-xs font-semibold rounded-xl shadow-sm transition-all shrink-0"
            >
              <RefreshCw className="w-4 h-4" />
              <span>Reset Database</span>
            </button>
          </div>
        </div>
      )}

      {/* Confirmation Modal for Reset */}
      <ConfirmationModal
        isOpen={isResetConfirmOpen}
        title="Reset Entire Database to Default State?"
        message="This will overwrite current records with default sample clinical data (sample patients Bella, Oliver, Luna, Milo, Clover, Kiwi, and scheduled visits). Are you sure?"
        confirmLabel="Reset to Defaults"
        isDestructive={true}
        onConfirm={handleResetToDefaults}
        onCancel={() => setIsResetConfirmOpen(false)}
      />
    </div>
  );
};
