import React from 'react';
import {
  X,
  Users,
  Phone,
  Mail,
  MapPin,
  ShieldAlert,
  PawPrint,
  Plus,
  Edit2,
  Trash2,
} from 'lucide-react';
import { PetOwner, Pet } from '../../types';
import { db } from '../../services/db';

interface OwnerDetailsModalProps {
  owner: PetOwner | null;
  isOpen: boolean;
  onClose: () => void;
  onEdit: (owner: PetOwner) => void;
  onDelete: (owner: PetOwner) => void;
  onSelectPet: (petId: string) => void;
  onAddPetForOwner: (ownerId: string) => void;
}

export const OwnerDetailsModal: React.FC<OwnerDetailsModalProps> = ({
  owner,
  isOpen,
  onClose,
  onEdit,
  onDelete,
  onSelectPet,
  onAddPetForOwner,
}) => {
  if (!isOpen || !owner) return null;

  const pets = db.getPetsByOwnerId(owner.id);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/45 backdrop-blur-[2px] overflow-y-auto">
      <div className="bg-white rounded-2xl max-w-2xl w-full shadow-2xl border border-[#DCE4DF] max-h-[92vh] flex flex-col overflow-hidden animate-in fade-in zoom-in-95 my-auto">
        {/* Header */}
        <div className="p-5 border-b border-[#E8EFEA] flex items-center justify-between bg-[#F8FAF8]">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#E8F0EA] text-[#3E6548] flex items-center justify-center font-bold text-lg">
              <Users className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-lg font-bold font-display text-[#1F2923]">
                  {owner.fullName}
                </h3>
                <span className="font-mono text-xs text-[#718677]">{owner.id}</span>
              </div>
              <p className="text-xs text-[#5D7063]">Registered Pet Client</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => onEdit(owner)}
              className="p-2 text-[#566B5C] hover:text-[#213025] hover:bg-[#EAEFEA] rounded-xl transition-colors"
              title="Edit Owner Profile"
            >
              <Edit2 className="w-4 h-4" />
            </button>
            <button
              onClick={() => onDelete(owner)}
              className="p-2 text-[#B92A2A] hover:bg-[#FDF2F2] rounded-xl transition-colors"
              title="Delete Owner"
            >
              <Trash2 className="w-4 h-4" />
            </button>
            <button
              onClick={onClose}
              className="p-2 text-[#738879] hover:text-[#1E2820] hover:bg-[#EAEFEA] rounded-xl"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Modal Scrollable Body */}
        <div className="p-6 overflow-y-auto space-y-6 flex-1 text-xs text-[#202E24]">
          {/* Contact Details Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 bg-[#F8FAF8] p-4 rounded-2xl border border-[#E3ECE5]">
            <div className="flex items-start gap-2.5">
              <Phone className="w-4 h-4 text-[#4A7255] shrink-0 mt-0.5" />
              <div>
                <span className="text-[11px] text-[#697E70] block">Phone Number</span>
                <span className="font-semibold text-[#1F2923] font-mono text-sm">{owner.phoneNumber}</span>
              </div>
            </div>

            <div className="flex items-start gap-2.5">
              <Mail className="w-4 h-4 text-[#4A7255] shrink-0 mt-0.5" />
              <div>
                <span className="text-[11px] text-[#697E70] block">Email Address</span>
                <span className="font-semibold text-[#1F2923] break-all">{owner.emailAddress}</span>
              </div>
            </div>

            <div className="flex items-start gap-2.5 sm:col-span-2">
              <MapPin className="w-4 h-4 text-[#4A7255] shrink-0 mt-0.5" />
              <div>
                <span className="text-[11px] text-[#697E70] block">Complete Address</span>
                <span className="text-[#1F2923] leading-relaxed">{owner.completeAddress}</span>
              </div>
            </div>
          </div>

          {/* Emergency Contact */}
          <div className="p-4 rounded-2xl border border-[#EBE3D7] bg-[#FCFAF6]">
            <div className="flex items-center gap-2 font-bold text-[#8A5A19] mb-2">
              <ShieldAlert className="w-4 h-4" />
              <span>Designated Emergency Contact</span>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-xs">
              <div>
                <span className="text-[11px] text-[#847B6F] block">Name</span>
                <span className="font-semibold text-[#1F2923]">{owner.emergencyContact.name}</span>
              </div>
              <div>
                <span className="text-[11px] text-[#847B6F] block">Relationship</span>
                <span className="text-[#324536]">{owner.emergencyContact.relationship}</span>
              </div>
              <div>
                <span className="text-[11px] text-[#847B6F] block">Emergency Phone</span>
                <span className="font-mono text-[#324536]">{owner.emergencyContact.phone}</span>
              </div>
            </div>
          </div>

          {/* Client Notes */}
          {owner.notes && (
            <div className="p-3.5 rounded-xl border border-[#E3ECE5] bg-white text-xs">
              <span className="font-bold text-[#324536] block mb-1">Client Preferences & Notes</span>
              <p className="text-[#55695B] leading-relaxed">{owner.notes}</p>
            </div>
          )}

          {/* Registered Pets Section */}
          <div>
            <div className="flex items-center justify-between mb-3">
              <h4 className="text-sm font-bold font-display text-[#1F2923] flex items-center gap-2">
                <PawPrint className="w-4 h-4 text-[#4A7255]" />
                <span>Registered Pets ({pets.length})</span>
              </h4>
              <button
                onClick={() => onAddPetForOwner(owner.id)}
                className="inline-flex items-center gap-1.5 px-3 py-1 bg-[#EEF4EF] hover:bg-[#E2ECE4] text-[#294231] font-semibold text-xs rounded-xl transition-colors"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Register Pet for {owner.fullName.split(' ')[0]}</span>
              </button>
            </div>

            {pets.length === 0 ? (
              <div className="p-4 text-center rounded-xl border border-dashed border-[#D2DCD4] text-xs text-[#718778]">
                No pets registered under this client yet.
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {pets.map((p) => (
                  <div
                    key={p.id}
                    onClick={() => onSelectPet(p.id)}
                    className="p-3 rounded-xl border border-[#E5EDE7] hover:border-[#4A7255]/40 hover:bg-[#F6FAF7] transition-all cursor-pointer flex items-center gap-3 group"
                  >
                    {p.photoUrl ? (
                      <img
                        src={p.photoUrl}
                        alt={p.name}
                        className="w-12 h-12 rounded-xl object-cover border border-[#D5E1D7] shrink-0"
                        referrerPolicy="no-referrer"
                      />
                    ) : (
                      <div className="w-12 h-12 rounded-xl bg-[#E8F0EA] text-[#4A7255] flex items-center justify-center font-bold text-sm shrink-0">
                        {p.name.charAt(0)}
                      </div>
                    )}
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-[#1F2C23] group-hover:text-[#32523B] transition-colors truncate">
                          {p.name}
                        </span>
                        <span className="text-[10px] text-[#718677] font-mono">{p.species}</span>
                      </div>
                      <p className="text-[11px] text-[#55695C] truncate">{p.breed}</p>
                      <span className="text-[10px] text-[#788E7E] block font-mono tabular-nums">
                        {p.weight} kg · {p.ageYears}y {p.ageMonths}m
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Modal Footer */}
        <div className="p-4 border-t border-[#E8EFEA] bg-[#F8FAF8] flex items-center justify-between">
          <span className="text-xs text-[#738879]">Client ID: {owner.id}</span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 bg-[#E8EFEA] hover:bg-[#DCE6DE] text-[#2F4134] text-xs font-semibold rounded-xl transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
