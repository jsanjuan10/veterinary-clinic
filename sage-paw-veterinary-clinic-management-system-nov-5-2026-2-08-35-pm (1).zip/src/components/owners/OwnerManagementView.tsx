import React, { useState } from 'react';
import {
  Users,
  Search,
  Plus,
  Phone,
  Mail,
  MapPin,
  PawPrint,
  Eye,
  Edit,
  Trash2,
  LayoutGrid,
  Table as TableIcon,
  ChevronRight,
  ShieldAlert,
} from 'lucide-react';
import { PetOwner, Pet } from '../../types';
import { db } from '../../services/db';
import { useNotification } from '../../context/NotificationContext';
import { OwnerDetailsModal } from './OwnerDetailsModal';
import { OwnerFormModal } from './OwnerFormModal';
import { PetFormModal } from '../pets/PetFormModal';
import { ConfirmationModal } from '../common/ConfirmationModal';
import { EmptyState } from '../common/EmptyState';

interface OwnerManagementViewProps {
  onSelectPet: (petId: string) => void;
}

export const OwnerManagementView: React.FC<OwnerManagementViewProps> = ({
  onSelectPet,
}) => {
  const { notify } = useNotification();
  const [owners, setOwners] = useState<PetOwner[]>(db.getOwners());
  const [pets, setPets] = useState<Pet[]>(db.getPets());

  const [searchTerm, setSearchTerm] = useState('');
  const [viewMode, setViewMode] = useState<'grid' | 'table'>('grid');

  // Modal states
  const [selectedOwner, setSelectedOwner] = useState<PetOwner | null>(null);
  const [isDetailsOpen, setIsDetailsOpen] = useState(false);
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [ownerToEdit, setOwnerToEdit] = useState<PetOwner | null>(null);
  const [ownerToDelete, setOwnerToDelete] = useState<PetOwner | null>(null);

  // Quick add pet for owner
  const [isAddPetOpen, setIsAddPetOpen] = useState(false);
  const [targetOwnerForPet, setTargetOwnerForPet] = useState<string>('');

  const refreshData = () => {
    setOwners(db.getOwners());
    setPets(db.getPets());
  };

  const filteredOwners = owners.filter((owner) => {
    const term = searchTerm.toLowerCase();
    return (
      owner.fullName.toLowerCase().includes(term) ||
      owner.phoneNumber.toLowerCase().includes(term) ||
      owner.emailAddress.toLowerCase().includes(term) ||
      owner.completeAddress.toLowerCase().includes(term) ||
      owner.id.toLowerCase().includes(term)
    );
  });

  const handleOpenAdd = () => {
    setOwnerToEdit(null);
    setIsFormOpen(true);
  };

  const handleOpenEdit = (owner: PetOwner) => {
    setOwnerToEdit(owner);
    setIsFormOpen(true);
  };

  const handleSaveOwner = (data: Omit<PetOwner, 'id' | 'createdAt' | 'updatedAt'>) => {
    try {
      if (ownerToEdit) {
        db.updateOwner(ownerToEdit.id, data);
        notify({
          type: 'success',
          title: 'Owner Record Updated',
          message: `${data.fullName}'s profile information was saved.`,
        });
      } else {
        db.createOwner(data);
        notify({
          type: 'success',
          title: 'New Client Registered',
          message: `${data.fullName} was added to the clinic directory.`,
        });
      }
      refreshData();
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Could not save owner.';
      notify({ type: 'error', title: 'Action Failed', message: msg });
    }
  };

  const handleDeleteConfirm = () => {
    if (!ownerToDelete) return;
    try {
      db.deleteOwner(ownerToDelete.id);
      notify({
        type: 'info',
        title: 'Client Record Deleted',
        message: `${ownerToDelete.fullName} has been removed from the registry.`,
      });
      setOwnerToDelete(null);
      setIsDetailsOpen(false);
      refreshData();
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Could not delete owner.';
      notify({
        type: 'error',
        title: 'Delete Blocked',
        message: msg,
      });
    }
  };

  const handleAddPetForOwner = (ownerId: string) => {
    setTargetOwnerForPet(ownerId);
    setIsAddPetOpen(true);
  };

  const handleSavePetForOwner = (petData: Omit<Pet, 'id' | 'createdAt' | 'updatedAt'>) => {
    db.createPet(petData);
    notify({
      type: 'success',
      title: 'Pet Registered to Client',
      message: `${petData.name} has been added.`,
    });
    refreshData();
  };

  return (
    <div className="space-y-6">
      {/* Search & Actions Bar */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white p-4 md:p-5 rounded-2xl border border-[#E2EAE4] shadow-sm">
        <div className="relative flex-1 max-w-lg">
          <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-[#738879]">
            <Search className="w-4 h-4" />
          </div>
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search owners by name, phone, email, address, or ID..."
            className="w-full pl-10 pr-4 py-2 text-xs md:text-sm rounded-xl border border-[#D5E0D7] bg-[#FBFCFB] focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#4A7255]/20 focus:border-[#4A7255] transition-all text-[#1F2923]"
          />
        </div>

        <div className="flex items-center gap-2.5 shrink-0 justify-end">
          <div className="inline-flex items-center p-1 bg-[#F0F4F1] rounded-xl border border-[#DFE7E1]">
            <button
              onClick={() => setViewMode('grid')}
              className={`p-1.5 rounded-lg transition-all ${
                viewMode === 'grid'
                  ? 'bg-white text-[#294231] shadow-xs'
                  : 'text-[#647C6B] hover:text-[#294231]'
              }`}
              title="Grid View"
            >
              <LayoutGrid className="w-4 h-4" />
            </button>
            <button
              onClick={() => setViewMode('table')}
              className={`p-1.5 rounded-lg transition-all ${
                viewMode === 'table'
                  ? 'bg-white text-[#294231] shadow-xs'
                  : 'text-[#647C6B] hover:text-[#294231]'
              }`}
              title="Table View"
            >
              <TableIcon className="w-4 h-4" />
            </button>
          </div>

          <button
            onClick={handleOpenAdd}
            className="inline-flex items-center gap-2 px-4 py-2 bg-[#4A7255] hover:bg-[#3C5D45] text-white text-xs font-semibold rounded-xl shadow-sm transition-all"
          >
            <Plus className="w-4 h-4" />
            <span>Add New Owner</span>
          </button>
        </div>
      </div>

      {/* Main Content */}
      {filteredOwners.length === 0 ? (
        <EmptyState
          icon={Users}
          title="No pet owners found"
          description={
            searchTerm
              ? 'No registered pet owners match your search terms.'
              : 'Start by registering your clinic’s first client.'
          }
          actionLabel="Register First Client"
          onAction={handleOpenAdd}
        />
      ) : viewMode === 'grid' ? (
        /* GRID VIEW */
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {filteredOwners.map((owner) => {
            const clientPets = pets.filter((p) => p.ownerId === owner.id);
            return (
              <div
                key={owner.id}
                className="bg-white rounded-2xl border border-[#E2EAE4] p-5 shadow-sm hover:border-[#4A7255]/40 hover:shadow-md transition-all flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-start justify-between gap-2 mb-3">
                    <div className="flex items-center gap-3">
                      <div className="w-11 h-11 rounded-2xl bg-[#E8F0EA] text-[#34533C] flex items-center justify-center font-bold text-base">
                        {owner.fullName.charAt(0)}
                      </div>
                      <div className="min-w-0">
                        <h4 className="text-sm font-bold font-display text-[#1F2923] truncate">
                          {owner.fullName}
                        </h4>
                        <span className="font-mono text-[10px] text-[#718677]">{owner.id}</span>
                      </div>
                    </div>

                    <span className="px-2 py-0.5 rounded-md bg-[#EDF3EF] text-[#34523C] font-semibold text-[11px] whitespace-nowrap">
                      {clientPets.length} {clientPets.length === 1 ? 'Pet' : 'Pets'}
                    </span>
                  </div>

                  <div className="space-y-2 text-xs text-[#526657] pt-2 border-t border-[#EEF4F0]">
                    <div className="flex items-center gap-2">
                      <Phone className="w-3.5 h-3.5 text-[#4A7255] shrink-0" />
                      <span className="font-mono truncate">{owner.phoneNumber}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Mail className="w-3.5 h-3.5 text-[#4A7255] shrink-0" />
                      <span className="truncate">{owner.emailAddress}</span>
                    </div>
                    <div className="flex items-start gap-2">
                      <MapPin className="w-3.5 h-3.5 text-[#4A7255] shrink-0 mt-0.5" />
                      <span className="truncate leading-tight">{owner.completeAddress}</span>
                    </div>
                  </div>

                  {/* Registered Pets Pill List */}
                  <div className="mt-3 pt-3 border-t border-[#EEF4F0]">
                    <span className="text-[10px] font-bold uppercase tracking-wider text-[#798D7E] block mb-1.5">
                      Registered Animals:
                    </span>
                    {clientPets.length === 0 ? (
                      <span className="text-[11px] text-[#8DA092] italic">No pets linked yet</span>
                    ) : (
                      <div className="flex flex-wrap gap-1.5">
                        {clientPets.map((p) => (
                          <button
                            key={p.id}
                            onClick={() => onSelectPet(p.id)}
                            className="inline-flex items-center gap-1 px-2 py-1 bg-[#F5F8F5] hover:bg-[#EAF1EB] text-[#294231] rounded-lg text-xs font-medium border border-[#E2EAE4] transition-colors"
                          >
                            <PawPrint className="w-3 h-3 text-[#52795B]" />
                            <span>{p.name}</span>
                            <span className="text-[10px] text-[#718677]">({p.species})</span>
                          </button>
                        ))}
                      </div>
                    )}
                  </div>
                </div>

                {/* Bottom Actions */}
                <div className="mt-4 pt-3 border-t border-[#EEF4F0] flex items-center justify-between gap-2">
                  <button
                    onClick={() => {
                      setSelectedOwner(owner);
                      setIsDetailsOpen(true);
                    }}
                    className="flex-1 py-1.5 px-3 bg-[#EEF4EF] hover:bg-[#E2ECE4] text-[#294231] text-xs font-semibold rounded-xl transition-colors inline-flex items-center justify-center gap-1.5"
                  >
                    <Eye className="w-3.5 h-3.5" />
                    <span>View Profile</span>
                  </button>

                  <div className="flex items-center gap-1">
                    <button
                      onClick={() => handleOpenEdit(owner)}
                      className="p-1.5 text-[#5B7162] hover:bg-[#EEF4EF] rounded-lg transition-colors"
                      title="Edit Owner"
                    >
                      <Edit className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => setOwnerToDelete(owner)}
                      className="p-1.5 text-[#B92A2A] hover:bg-[#FDF2F2] rounded-lg transition-colors"
                      title="Delete Owner"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        /* TABLE VIEW */
        <div className="bg-white rounded-2xl border border-[#E2EAE4] shadow-sm overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-[#F7FAF8] border-b border-[#E2EAE4] text-[#55695B] uppercase font-semibold text-[11px] tracking-wider">
                <tr>
                  <th className="py-3 px-4">Owner Name & ID</th>
                  <th className="py-3 px-4">Contact Phone</th>
                  <th className="py-3 px-4">Email</th>
                  <th className="py-3 px-4">Registered Pets</th>
                  <th className="py-3 px-4">Emergency Contact</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#EEF4F0]">
                {filteredOwners.map((owner) => {
                  const clientPets = pets.filter((p) => p.ownerId === owner.id);
                  return (
                    <tr
                      key={owner.id}
                      className="hover:bg-[#F9FAF9] transition-colors cursor-pointer"
                      onClick={() => {
                        setSelectedOwner(owner);
                        setIsDetailsOpen(true);
                      }}
                    >
                      <td className="py-3 px-4">
                        <span className="font-bold text-[#1F2923] block">{owner.fullName}</span>
                        <span className="font-mono text-[10px] text-[#788E7E]">{owner.id}</span>
                      </td>
                      <td className="py-3 px-4 font-mono text-[#2B3E31]">{owner.phoneNumber}</td>
                      <td className="py-3 px-4 text-[#526657]">{owner.emailAddress}</td>
                      <td className="py-3 px-4">
                        <span className="inline-block px-2 py-0.5 rounded-md bg-[#EDF3EF] text-[#2F4A37] font-semibold text-[11px]">
                          {clientPets.length} {clientPets.length === 1 ? 'Pet' : 'Pets'}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-[#526657]">
                        {owner.emergencyContact.name} ({owner.emergencyContact.relationship})
                      </td>
                      <td className="py-3 px-4 text-right" onClick={(e) => e.stopPropagation()}>
                        <div className="flex items-center justify-end gap-1.5">
                          <button
                            onClick={() => {
                              setSelectedOwner(owner);
                              setIsDetailsOpen(true);
                            }}
                            className="p-1.5 text-[#4A7255] hover:bg-[#EEF4EF] rounded-lg transition-colors"
                            title="View"
                          >
                            <Eye className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => handleOpenEdit(owner)}
                            className="p-1.5 text-[#5B7162] hover:bg-[#EEF4EF] rounded-lg transition-colors"
                            title="Edit"
                          >
                            <Edit className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => setOwnerToDelete(owner)}
                            className="p-1.5 text-[#B92A2A] hover:bg-[#FDF2F2] rounded-lg transition-colors"
                            title="Delete"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Owner Details Modal */}
      <OwnerDetailsModal
        owner={selectedOwner}
        isOpen={isDetailsOpen}
        onClose={() => setIsDetailsOpen(false)}
        onEdit={(o) => {
          setIsDetailsOpen(false);
          handleOpenEdit(o);
        }}
        onDelete={(o) => {
          setIsDetailsOpen(false);
          setOwnerToDelete(o);
        }}
        onSelectPet={(petId) => {
          setIsDetailsOpen(false);
          onSelectPet(petId);
        }}
        onAddPetForOwner={(ownerId) => {
          setIsDetailsOpen(false);
          handleAddPetForOwner(ownerId);
        }}
      />

      {/* Owner Form Modal */}
      <OwnerFormModal
        isOpen={isFormOpen}
        ownerToEdit={ownerToEdit}
        onClose={() => setIsFormOpen(false)}
        onSave={handleSaveOwner}
      />

      {/* Quick Add Pet Form for specific Owner */}
      <PetFormModal
        isOpen={isAddPetOpen}
        defaultOwnerId={targetOwnerForPet}
        onClose={() => setIsAddPetOpen(false)}
        onSave={handleSavePetForOwner}
      />

      {/* Confirmation Modal */}
      <ConfirmationModal
        isOpen={!!ownerToDelete}
        title={`Delete Owner: ${ownerToDelete?.fullName}?`}
        message="Are you sure you want to delete this owner profile? Note: If this client has registered pets, they must be reassigned or deleted first."
        confirmLabel="Delete Owner"
        isDestructive={true}
        onConfirm={handleDeleteConfirm}
        onCancel={() => setOwnerToDelete(null)}
      />
    </div>
  );
};
