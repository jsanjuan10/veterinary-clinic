import React, { useState, useEffect } from 'react';
import { X, Users, Phone, Mail, MapPin } from 'lucide-react';
import { PetOwner } from '../../types';

interface OwnerFormModalProps {
  isOpen: boolean;
  ownerToEdit?: PetOwner | null;
  onClose: () => void;
  onSave: (data: Omit<PetOwner, 'id' | 'createdAt' | 'updatedAt'>) => void;
}

export const OwnerFormModal: React.FC<OwnerFormModalProps> = ({
  isOpen,
  ownerToEdit,
  onClose,
  onSave,
}) => {
  const [fullName, setFullName] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [emailAddress, setEmailAddress] = useState('');
  const [completeAddress, setCompleteAddress] = useState('');
  const [emergencyName, setEmergencyName] = useState('');
  const [emergencyPhone, setEmergencyPhone] = useState('');
  const [emergencyRelationship, setEmergencyRelationship] = useState('Spouse');
  const [notes, setNotes] = useState('');
  const [errorMsg, setErrorMsg] = useState('');

  useEffect(() => {
    if (ownerToEdit) {
      setFullName(ownerToEdit.fullName);
      setPhoneNumber(ownerToEdit.phoneNumber);
      setEmailAddress(ownerToEdit.emailAddress);
      setCompleteAddress(ownerToEdit.completeAddress);
      setEmergencyName(ownerToEdit.emergencyContact.name);
      setEmergencyPhone(ownerToEdit.emergencyContact.phone);
      setEmergencyRelationship(ownerToEdit.emergencyContact.relationship);
      setNotes(ownerToEdit.notes || '');
    } else {
      setFullName('');
      setPhoneNumber('');
      setEmailAddress('');
      setCompleteAddress('');
      setEmergencyName('');
      setEmergencyPhone('');
      setEmergencyRelationship('Family Member');
      setNotes('');
    }
    setErrorMsg('');
  }, [ownerToEdit, isOpen]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!fullName.trim()) {
      setErrorMsg('Full name is required.');
      return;
    }
    if (!phoneNumber.trim()) {
      setErrorMsg('Phone number is required.');
      return;
    }
    if (!emailAddress.trim() || !emailAddress.includes('@')) {
      setErrorMsg('Valid email address is required.');
      return;
    }

    onSave({
      fullName: fullName.trim(),
      phoneNumber: phoneNumber.trim(),
      emailAddress: emailAddress.trim().toLowerCase(),
      completeAddress: completeAddress.trim(),
      emergencyContact: {
        name: emergencyName.trim() || 'Not specified',
        phone: emergencyPhone.trim() || phoneNumber.trim(),
        relationship: emergencyRelationship.trim() || 'Emergency Contact',
      },
      notes: notes.trim() || undefined,
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/45 backdrop-blur-[2px] overflow-y-auto">
      <div className="bg-white rounded-2xl max-w-xl w-full shadow-2xl border border-[#DCE4DF] max-h-[92vh] flex flex-col overflow-hidden animate-in fade-in zoom-in-95 my-auto">
        <div className="p-5 border-b border-[#E8EFEA] flex items-center justify-between bg-[#F8FAF8]">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#E8F0EA] text-[#3E6548] flex items-center justify-center font-bold">
              <Users className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold font-display text-[#1F2923]">
                {ownerToEdit ? `Edit Client: ${ownerToEdit.fullName}` : 'Register New Pet Owner'}
              </h3>
              <p className="text-xs text-[#5D7063]">
                Contact information and designated emergency contact
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-[#738879] hover:text-[#1E2820] hover:bg-[#EAEFEA] rounded-xl"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 overflow-y-auto space-y-4 flex-1 text-xs text-[#1F2923]">
          {errorMsg && (
            <div className="p-3 bg-[#FDF2F2] border border-[#F8D7DA] text-[#9E2A2B] rounded-xl">
              {errorMsg}
            </div>
          )}

          <div>
            <label className="block font-semibold mb-1 text-[#2D3A31]">Full Name *</label>
            <input
              type="text"
              required
              value={fullName}
              onChange={(e) => setFullName(e.target.value)}
              placeholder="e.g. Eleanor Vance"
              className="w-full px-3 py-2 rounded-xl border border-[#D5E0D7] bg-[#FBFCFB] focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#4A7255]"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block font-semibold mb-1 text-[#2D3A31]">Phone Number *</label>
              <input
                type="tel"
                required
                value={phoneNumber}
                onChange={(e) => setPhoneNumber(e.target.value)}
                placeholder="+1 (555) 000-0000"
                className="w-full px-3 py-2 rounded-xl border border-[#D5E0D7] bg-[#FBFCFB] focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#4A7255]"
              />
            </div>
            <div>
              <label className="block font-semibold mb-1 text-[#2D3A31]">Email Address *</label>
              <input
                type="email"
                required
                value={emailAddress}
                onChange={(e) => setEmailAddress(e.target.value)}
                placeholder="client@example.com"
                className="w-full px-3 py-2 rounded-xl border border-[#D5E0D7] bg-[#FBFCFB] focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#4A7255]"
              />
            </div>
          </div>

          <div>
            <label className="block font-semibold mb-1 text-[#2D3A31]">Complete Physical Address</label>
            <input
              type="text"
              value={completeAddress}
              onChange={(e) => setCompleteAddress(e.target.value)}
              placeholder="e.g. 104 Willow Glen Road, Meadowbrook, CA 94112"
              className="w-full px-3 py-2 rounded-xl border border-[#D5E0D7] bg-[#FBFCFB] focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#4A7255]"
            />
          </div>

          {/* Emergency Contact Block */}
          <div className="p-3.5 rounded-xl border border-[#E9E1D2] bg-[#FCFAF6] space-y-3">
            <span className="font-bold text-[#8A5A19] block text-xs">Emergency Contact Details</span>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="block text-[11px] font-semibold mb-1 text-[#4F453B]">Contact Name</label>
                <input
                  type="text"
                  value={emergencyName}
                  onChange={(e) => setEmergencyName(e.target.value)}
                  placeholder="e.g. John Doe"
                  className="w-full px-2.5 py-1.5 rounded-lg border border-[#E0D8C8] bg-white focus:outline-none focus:ring-1 focus:ring-[#8A5A19]"
                />
              </div>
              <div>
                <label className="block text-[11px] font-semibold mb-1 text-[#4F453B]">Phone</label>
                <input
                  type="tel"
                  value={emergencyPhone}
                  onChange={(e) => setEmergencyPhone(e.target.value)}
                  placeholder="+1 (555) 123-4567"
                  className="w-full px-2.5 py-1.5 rounded-lg border border-[#E0D8C8] bg-white focus:outline-none focus:ring-1 focus:ring-[#8A5A19]"
                />
              </div>
              <div>
                <label className="block text-[11px] font-semibold mb-1 text-[#4F453B]">Relationship</label>
                <input
                  type="text"
                  value={emergencyRelationship}
                  onChange={(e) => setEmergencyRelationship(e.target.value)}
                  placeholder="Spouse / Parent / Friend"
                  className="w-full px-2.5 py-1.5 rounded-lg border border-[#E0D8C8] bg-white focus:outline-none focus:ring-1 focus:ring-[#8A5A19]"
                />
              </div>
            </div>
          </div>

          <div>
            <label className="block font-semibold mb-1 text-[#2D3A31]">Special Client Notes / Preferences</label>
            <textarea
              rows={2}
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="e.g. Prefers morning appointments; uses pet insurance provider..."
              className="w-full px-3 py-2 rounded-xl border border-[#D5E0D7] bg-[#FBFCFB] focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#4A7255]"
            />
          </div>

          <div className="pt-3 border-t border-[#E8EFEA] flex items-center justify-end gap-2.5">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-[#EEF3EF] hover:bg-[#E3ECE5] text-[#2F4134] font-semibold rounded-xl"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 bg-[#4A7255] hover:bg-[#3C5D45] text-white font-semibold rounded-xl shadow-sm transition-all"
            >
              {ownerToEdit ? 'Save Changes' : 'Register Owner'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
