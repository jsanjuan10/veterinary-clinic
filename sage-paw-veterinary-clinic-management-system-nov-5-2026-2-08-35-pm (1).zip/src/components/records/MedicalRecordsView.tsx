import React, { useState } from 'react';
import {
  FileText,
  Search,
  Plus,
  Eye,
  Edit,
  Trash2,
  Calendar,
  PawPrint,
  Stethoscope,
  Filter,
  Syringe,
  Pill,
} from 'lucide-react';
import { MedicalRecord, Pet, PetOwner } from '../../types';
import { db } from '../../services/db';
import { useNotification } from '../../context/NotificationContext';
import { MedicalRecordDetailsModal } from './MedicalRecordDetailsModal';
import { MedicalRecordFormModal } from './MedicalRecordFormModal';
import { ConfirmationModal } from '../common/ConfirmationModal';
import { EmptyState } from '../common/EmptyState';

interface MedicalRecordsViewProps {
  onSelectPet: (petId: string) => void;
  onSelectOwner: (ownerId: string) => void;
}

export const MedicalRecordsView: React.FC<MedicalRecordsViewProps> = ({
  onSelectPet,
  onSelectOwner,
}) => {
  const { notify } = useNotification();
  const [records, setRecords] = useState<MedicalRecord[]>(db.getMedicalRecords());
  const [pets, setPets] = useState<Pet[]>(db.getPets());
  const [owners, setOwners] = useState<PetOwner[]>(db.getOwners());

  const [searchTerm, setSearchTerm] = useState('');
  const [selectedPetFilter, setSelectedPetFilter] = useState<string>('All');

  // Modals
  const [selectedRecord, setSelectedRecord] = useState<MedicalRecord | null>(null);
  const [isDetailsOpen, setIsDetailsOpen] = useState(false);
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [recordToEdit, setRecordToEdit] = useState<MedicalRecord | null>(null);
  const [recordToDelete, setRecordToDelete] = useState<MedicalRecord | null>(null);

  const refreshData = () => {
    setRecords(db.getMedicalRecords());
    setPets(db.getPets());
    setOwners(db.getOwners());
  };

  const petMap = new Map<string, Pet>();
  pets.forEach((p) => petMap.set(p.id, p));

  const ownerMap = new Map<string, PetOwner>();
  owners.forEach((o) => ownerMap.set(o.id, o));

  const filteredRecords = records.filter((rec) => {
    const pet = petMap.get(rec.petId);
    const owner = ownerMap.get(rec.ownerId);
    const term = searchTerm.toLowerCase();

    const matchesSearch =
      rec.diagnosis.toLowerCase().includes(term) ||
      rec.symptoms.toLowerCase().includes(term) ||
      rec.treatment.toLowerCase().includes(term) ||
      rec.prescribedMedication.toLowerCase().includes(term) ||
      rec.veterinarian.toLowerCase().includes(term) ||
      rec.id.toLowerCase().includes(term) ||
      (pet && pet.name.toLowerCase().includes(term)) ||
      (owner && owner.fullName.toLowerCase().includes(term));

    const matchesPet = selectedPetFilter === 'All' ? true : rec.petId === selectedPetFilter;

    return matchesSearch && matchesPet;
  });

  const handleOpenAdd = () => {
    setRecordToEdit(null);
    setIsFormOpen(true);
  };

  const handleOpenEdit = (rec: MedicalRecord) => {
    setRecordToEdit(rec);
    setIsFormOpen(true);
  };

  const handleSaveRecord = (data: Omit<MedicalRecord, 'id' | 'createdAt' | 'updatedAt'>) => {
    try {
      if (recordToEdit) {
        db.updateMedicalRecord(recordToEdit.id, data);
        notify({
          type: 'success',
          title: 'Consultation Note Updated',
          message: `Medical assessment for ${data.diagnosis} was updated.`,
        });
      } else {
        db.createMedicalRecord(data);
        notify({
          type: 'success',
          title: 'Consultation Logged',
          message: `New medical record successfully saved.`,
        });
      }
      refreshData();
      if (selectedRecord && recordToEdit && selectedRecord.id === recordToEdit.id) {
        setSelectedRecord(db.getMedicalRecordById(selectedRecord.id) || null);
      }
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Could not save record.';
      notify({ type: 'error', title: 'Save Failed', message: msg });
    }
  };

  const handleDeleteConfirm = () => {
    if (!recordToDelete) return;
    try {
      db.deleteMedicalRecord(recordToDelete.id);
      notify({
        type: 'info',
        title: 'Record Deleted',
        message: 'The consultation dossier has been removed.',
      });
      setRecordToDelete(null);
      setIsDetailsOpen(false);
      refreshData();
    } catch {
      notify({ type: 'error', title: 'Delete Failed', message: 'Could not delete record.' });
    }
  };

  return (
    <div className="space-y-6">
      {/* Search and Filters Strip */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white p-4 md:p-5 rounded-2xl border border-[#E2EAE4] shadow-sm">
        <div className="flex-1 flex flex-col sm:flex-row gap-3">
          {/* Search */}
          <div className="relative flex-1">
            <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-[#738879]">
              <Search className="w-4 h-4" />
            </div>
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search diagnoses, symptoms, treatments, medications, or doctors..."
              className="w-full pl-10 pr-4 py-2 text-xs md:text-sm rounded-xl border border-[#D5E0D7] bg-[#FBFCFB] focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#4A7255]/20 focus:border-[#4A7255] transition-all text-[#1F2923]"
            />
          </div>

          {/* Filter by Pet */}
          <div className="flex items-center gap-2">
            <Filter className="w-4 h-4 text-[#607767] shrink-0" />
            <select
              value={selectedPetFilter}
              onChange={(e) => setSelectedPetFilter(e.target.value)}
              className="px-3 py-2 text-xs rounded-xl border border-[#D5E0D7] bg-[#FBFCFB] focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#4A7255] text-[#1F2923]"
            >
              <option value="All">All Patients ({records.length})</option>
              {pets.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.name} ({p.species})
                </option>
              ))}
            </select>
          </div>
        </div>

        <button
          onClick={handleOpenAdd}
          className="inline-flex items-center gap-2 px-4 py-2 bg-[#4A7255] hover:bg-[#3C5D45] text-white text-xs font-semibold rounded-xl shadow-sm transition-all shrink-0 self-end sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>New Medical Record</span>
        </button>
      </div>

      {/* Main List */}
      {filteredRecords.length === 0 ? (
        <EmptyState
          icon={FileText}
          title="No medical records found"
          description={
            searchTerm || selectedPetFilter !== 'All'
              ? 'No consultation notes match your search parameters.'
              : 'Log patient consultations, vital diagnostics, and prescription treatments.'
          }
          actionLabel="Log First Consultation"
          onAction={handleOpenAdd}
        />
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {filteredRecords.map((rec) => {
            const pet = petMap.get(rec.petId);
            const owner = ownerMap.get(rec.ownerId);

            return (
              <div
                key={rec.id}
                className="bg-white rounded-2xl border border-[#E2EAE4] p-5 shadow-sm hover:border-[#4A7255]/40 hover:shadow-md transition-all flex flex-col justify-between"
              >
                <div>
                  {/* Top Bar: Diagnosis & Date */}
                  <div className="flex items-start justify-between gap-2 mb-3">
                    <div>
                      <span className="font-mono text-[10px] text-[#718677] uppercase block">
                        {rec.id} · {rec.consultationDate}
                      </span>
                      <h4 className="text-base font-bold font-display text-[#1F2923] mt-0.5">
                        {rec.diagnosis}
                      </h4>
                    </div>

                    <div className="text-right shrink-0">
                      <span className="inline-block px-2 py-0.5 rounded-md bg-[#EDF3EF] text-[#334E3A] font-semibold text-[11px] font-mono tabular-nums">
                        {rec.weight} kg · {rec.temperature}°C
                      </span>
                    </div>
                  </div>

                  {/* Patient Info Strip */}
                  <div className="flex items-center gap-3 p-2.5 rounded-xl bg-[#F7FAF8] border border-[#E3ECE5] mb-3">
                    {pet?.photoUrl ? (
                      <img
                        src={pet.photoUrl}
                        alt={pet.name}
                        className="w-10 h-10 rounded-xl object-cover border"
                        referrerPolicy="no-referrer"
                      />
                    ) : (
                      <div className="w-10 h-10 rounded-xl bg-[#E8F0EA] text-[#4A7255] flex items-center justify-center font-bold text-xs">
                        {pet?.name?.charAt(0) || 'P'}
                      </div>
                    )}
                    <div className="min-w-0 flex-1 text-xs">
                      <div className="flex items-center gap-1.5">
                        <span className="font-bold text-[#1F2C23] truncate">{pet?.name || 'Pet'}</span>
                        <span className="text-[#687C6D]">({pet?.species} - {pet?.breed})</span>
                      </div>
                      <span className="text-[11px] text-[#788E7E] block truncate">
                        Owner: {owner?.fullName || 'Not assigned'}
                      </span>
                    </div>
                  </div>

                  {/* Clinical Description Snippets */}
                  <div className="space-y-2 text-xs text-[#4F6456]">
                    <div>
                      <strong className="text-[#2B3E31]">Symptoms:</strong> {rec.symptoms}
                    </div>
                    <div>
                      <strong className="text-[#2B3E31]">Treatment:</strong> {rec.treatment}
                    </div>
                    {rec.prescribedMedication && (
                      <div className="p-2.5 rounded-lg bg-[#F3F7F4] border border-[#D9E6DC] text-[#294231] font-mono text-[11px]">
                        <strong>Rx:</strong> {rec.prescribedMedication}
                      </div>
                    )}
                  </div>

                  {/* Vaccines & Followup Strip */}
                  <div className="mt-3 pt-3 border-t border-[#EEF4F0] flex items-center justify-between text-[11px] text-[#697E70]">
                    <span className="truncate">Attending: {rec.veterinarian}</span>
                    {rec.followUpDate && (
                      <span className="font-semibold text-[#3E6548] font-mono tabular-nums">
                        Follow-up: {rec.followUpDate}
                      </span>
                    )}
                  </div>
                </div>

                {/* Bottom Actions */}
                <div className="mt-4 pt-3 border-t border-[#EEF4F0] flex items-center justify-between gap-2">
                  <button
                    onClick={() => {
                      setSelectedRecord(rec);
                      setIsDetailsOpen(true);
                    }}
                    className="flex-1 py-1.5 px-3 bg-[#EEF4EF] hover:bg-[#E2ECE4] text-[#294231] text-xs font-semibold rounded-xl transition-colors inline-flex items-center justify-center gap-1.5"
                  >
                    <Eye className="w-3.5 h-3.5" />
                    <span>View Dossier & Print</span>
                  </button>

                  <div className="flex items-center gap-1">
                    <button
                      onClick={() => handleOpenEdit(rec)}
                      className="p-1.5 text-[#5B7162] hover:bg-[#EEF4EF] rounded-lg transition-colors"
                      title="Edit Record"
                    >
                      <Edit className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => setRecordToDelete(rec)}
                      className="p-1.5 text-[#B92A2A] hover:bg-[#FDF2F2] rounded-lg transition-colors"
                      title="Delete Record"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Record Details Modal */}
      <MedicalRecordDetailsModal
        record={selectedRecord}
        isOpen={isDetailsOpen}
        onClose={() => setIsDetailsOpen(false)}
        onEdit={(r) => {
          setIsDetailsOpen(false);
          handleOpenEdit(r);
        }}
        onDelete={(r) => {
          setIsDetailsOpen(false);
          setRecordToDelete(r);
        }}
        onSelectPet={(petId) => {
          setIsDetailsOpen(false);
          onSelectPet(petId);
        }}
      />

      {/* Record Form Modal */}
      <MedicalRecordFormModal
        isOpen={isFormOpen}
        recordToEdit={recordToEdit}
        onClose={() => setIsFormOpen(false)}
        onSave={handleSaveRecord}
      />

      {/* Delete Confirmation */}
      <ConfirmationModal
        isOpen={!!recordToDelete}
        title="Delete Medical Record?"
        message="Are you sure you want to delete this clinical consultation note? This action is permanent."
        confirmLabel="Delete Record"
        isDestructive={true}
        onConfirm={handleDeleteConfirm}
        onCancel={() => setRecordToDelete(null)}
      />
    </div>
  );
};
