import React, { useState, useEffect } from 'react';
import { X, FileText, Plus, Trash, Stethoscope, Syringe } from 'lucide-react';
import { MedicalRecord, VaccinationEntry, Pet, PetOwner } from '../../types';
import { db } from '../../services/db';

interface MedicalRecordFormModalProps {
  isOpen: boolean;
  recordToEdit?: MedicalRecord | null;
  defaultPetId?: string;
  onClose: () => void;
  onSave: (data: Omit<MedicalRecord, 'id' | 'createdAt' | 'updatedAt'>) => void;
}

export const MedicalRecordFormModal: React.FC<MedicalRecordFormModalProps> = ({
  isOpen,
  recordToEdit,
  defaultPetId,
  onClose,
  onSave,
}) => {
  const [petId, setPetId] = useState('');
  const [ownerId, setOwnerId] = useState('');
  const [veterinarian, setVeterinarian] = useState('Dr. Sophia Jenkins, DVM');
  const [consultationDate, setConsultationDate] = useState('');
  const [symptoms, setSymptoms] = useState('');
  const [diagnosis, setDiagnosis] = useState('');
  const [treatment, setTreatment] = useState('');
  const [prescribedMedication, setPrescribedMedication] = useState('');
  const [vaccinations, setVaccinations] = useState<VaccinationEntry[]>([]);
  const [weight, setWeight] = useState<number>(5.0);
  const [temperature, setTemperature] = useState<number>(38.5);
  const [followUpDate, setFollowUpDate] = useState('');
  const [additionalNotes, setAdditionalNotes] = useState('');
  const [errorMsg, setErrorMsg] = useState('');

  const pets = db.getPets();
  const owners = db.getOwners();
  const doctors = db.getUsers().filter((u) => u.role === 'veterinarian');

  useEffect(() => {
    if (recordToEdit) {
      setPetId(recordToEdit.petId);
      setOwnerId(recordToEdit.ownerId);
      setVeterinarian(recordToEdit.veterinarian);
      setConsultationDate(recordToEdit.consultationDate);
      setSymptoms(recordToEdit.symptoms);
      setDiagnosis(recordToEdit.diagnosis);
      setTreatment(recordToEdit.treatment);
      setPrescribedMedication(recordToEdit.prescribedMedication);
      setVaccinations(recordToEdit.vaccinationRecords || []);
      setWeight(recordToEdit.weight);
      setTemperature(recordToEdit.temperature);
      setFollowUpDate(recordToEdit.followUpDate || '');
      setAdditionalNotes(recordToEdit.additionalNotes || '');
    } else {
      const initialPetId = defaultPetId || (pets[0] ? pets[0].id : '');
      const pet = pets.find((p) => p.id === initialPetId);
      setPetId(initialPetId);
      setOwnerId(pet ? pet.ownerId : (owners[0] ? owners[0].id : ''));
      setVeterinarian(doctors[0]?.fullName || 'Dr. Sophia Jenkins, DVM');
      setConsultationDate(new Date().toISOString().split('T')[0]);
      setSymptoms('');
      setDiagnosis('');
      setTreatment('');
      setPrescribedMedication('');
      setVaccinations([]);
      setWeight(pet ? pet.weight : 5.0);
      setTemperature(38.5);
      setFollowUpDate('');
      setAdditionalNotes('');
    }
    setErrorMsg('');
  }, [recordToEdit, isOpen, defaultPetId]);

  if (!isOpen) return null;

  const handlePetChange = (newPetId: string) => {
    setPetId(newPetId);
    const pet = pets.find((p) => p.id === newPetId);
    if (pet) {
      setOwnerId(pet.ownerId);
      setWeight(pet.weight);
    }
  };

  const handleAddVaccine = () => {
    setVaccinations([
      ...vaccinations,
      {
        vaccineName: '',
        administeredDate: consultationDate || new Date().toISOString().split('T')[0],
        nextDueDate: '',
        batchNumber: '',
      },
    ]);
  };

  const handleRemoveVaccine = (index: number) => {
    setVaccinations(vaccinations.filter((_, i) => i !== index));
  };

  const handleVaccineChange = (
    index: number,
    field: keyof VaccinationEntry,
    value: string
  ) => {
    const updated = [...vaccinations];
    updated[index] = { ...updated[index], [field]: value };
    setVaccinations(updated);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!petId) {
      setErrorMsg('Please select a pet patient.');
      return;
    }
    if (!diagnosis.trim()) {
      setErrorMsg('Diagnosis or primary clinical assessment is required.');
      return;
    }
    if (!treatment.trim()) {
      setErrorMsg('Clinical treatment plan is required.');
      return;
    }

    onSave({
      petId,
      ownerId,
      veterinarian,
      consultationDate,
      symptoms: symptoms.trim() || 'Routine healthy wellness check.',
      diagnosis: diagnosis.trim(),
      treatment: treatment.trim(),
      prescribedMedication: prescribedMedication.trim(),
      vaccinationRecords: vaccinations.filter((v) => v.vaccineName.trim().length > 0),
      weight: Number(weight) || 1,
      temperature: Number(temperature) || 38.5,
      followUpDate: followUpDate || undefined,
      additionalNotes: additionalNotes.trim() || undefined,
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/45 backdrop-blur-[2px] overflow-y-auto">
      <div className="bg-white rounded-2xl max-w-2xl w-full shadow-2xl border border-[#DCE4DF] max-h-[92vh] flex flex-col overflow-hidden animate-in fade-in zoom-in-95 my-auto">
        <div className="p-5 border-b border-[#E8EFEA] flex items-center justify-between bg-[#F8FAF8]">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#E8F0EA] text-[#3E6548] flex items-center justify-center font-bold">
              <Stethoscope className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold font-display text-[#1F2923]">
                {recordToEdit ? 'Edit Medical Consultation' : 'Log New Medical Consultation'}
              </h3>
              <p className="text-xs text-[#5D7063]">
                Clinical symptoms, diagnostic assessment, prescriptions & vitals
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-[#738879] hover:text-[#1E2820] hover:bg-[#EAEFEA] rounded-xl"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 overflow-y-auto space-y-4 flex-1 text-xs text-[#1F2923]">
          {errorMsg && (
            <div className="p-3 bg-[#FDF2F2] border border-[#F8D7DA] text-[#9E2A2B] rounded-xl">
              {errorMsg}
            </div>
          )}

          {/* Pet & Doctor */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block font-semibold mb-1 text-[#2D3A31]">Pet Patient *</label>
              <select
                required
                value={petId}
                onChange={(e) => handlePetChange(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-[#D5E0D7] bg-[#FBFCFB] focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#4A7255]"
              >
                <option value="">-- Choose Patient --</option>
                {pets.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.name} ({p.species} - {p.breed})
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block font-semibold mb-1 text-[#2D3A31]">Attending Veterinarian *</label>
              <select
                required
                value={veterinarian}
                onChange={(e) => setVeterinarian(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-[#D5E0D7] bg-[#FBFCFB] focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#4A7255]"
              >
                {doctors.map((d) => (
                  <option key={d.id} value={d.fullName}>
                    {d.fullName}
                  </option>
                ))}
                {doctors.length === 0 && (
                  <option value="Attending Veterinarian">Attending Veterinarian</option>
                )}
              </select>
            </div>
          </div>

          {/* Vitals: Consultation Date, Weight, Temp */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="block font-semibold mb-1 text-[#2D3A31]">Consultation Date *</label>
              <input
                type="date"
                required
                value={consultationDate}
                onChange={(e) => setConsultationDate(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-[#D5E0D7] bg-[#FBFCFB] focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#4A7255]"
              />
            </div>
            <div>
              <label className="block font-semibold mb-1 text-[#2D3A31]">Weight (kg) *</label>
              <input
                type="number"
                step="0.01"
                required
                value={weight}
                onChange={(e) => setWeight(parseFloat(e.target.value) || 0)}
                className="w-full px-3 py-2 rounded-xl border border-[#D5E0D7] bg-[#FBFCFB] focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#4A7255]"
              />
            </div>
            <div>
              <label className="block font-semibold mb-1 text-[#2D3A31]">Temperature (°C) *</label>
              <input
                type="number"
                step="0.1"
                required
                value={temperature}
                onChange={(e) => setTemperature(parseFloat(e.target.value) || 0)}
                className="w-full px-3 py-2 rounded-xl border border-[#D5E0D7] bg-[#FBFCFB] focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#4A7255]"
              />
            </div>
          </div>

          {/* Symptoms & Diagnosis */}
          <div>
            <label className="block font-semibold mb-1 text-[#2D3A31]">Presenting Symptoms & Clinical History</label>
            <textarea
              rows={2}
              value={symptoms}
              onChange={(e) => setSymptoms(e.target.value)}
              placeholder="e.g. Mild lameness on right paw, scratching ears, routine checkup..."
              className="w-full px-3 py-2 rounded-xl border border-[#D5E0D7] bg-[#FBFCFB] focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#4A7255]"
            />
          </div>

          <div>
            <label className="block font-semibold mb-1 text-[#2D3A31]">Clinical Diagnosis *</label>
            <input
              type="text"
              required
              value={diagnosis}
              onChange={(e) => setDiagnosis(e.target.value)}
              placeholder="e.g. Grade 1 Carpal Sprain, Otitis Externa, Healthy Annual Exam"
              className="w-full px-3 py-2 rounded-xl border border-[#D5E0D7] bg-[#FBFCFB] focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#4A7255]"
            />
          </div>

          {/* Treatment & Medication */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block font-semibold mb-1 text-[#2D3A31]">Treatment Rendered *</label>
              <textarea
                rows={2}
                required
                value={treatment}
                onChange={(e) => setTreatment(e.target.value)}
                placeholder="In-clinic ear flush, suture removal, fluid therapy..."
                className="w-full px-3 py-2 rounded-xl border border-[#D5E0D7] bg-[#FBFCFB] focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#4A7255]"
              />
            </div>

            <div>
              <label className="block font-semibold mb-1 text-[#2D3A31]">Prescribed Medication & Dosage</label>
              <textarea
                rows={2}
                value={prescribedMedication}
                onChange={(e) => setPrescribedMedication(e.target.value)}
                placeholder="e.g. Carprofen 75mg PO q24h x 5 days, Otic drops..."
                className="w-full px-3 py-2 rounded-xl border border-[#D5E0D7] bg-[#FBFCFB] focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#4A7255]"
              />
            </div>
          </div>

          {/* Vaccination Administered */}
          <div className="p-3.5 rounded-xl border border-[#DCE6DE] bg-[#F7FAF8]">
            <div className="flex items-center justify-between mb-2">
              <span className="font-bold text-[#2E4734] flex items-center gap-1.5 text-xs">
                <Syringe className="w-3.5 h-3.5 text-[#4A7255]" />
                <span>Administered Vaccinations</span>
              </span>
              <button
                type="button"
                onClick={handleAddVaccine}
                className="inline-flex items-center gap-1 text-[11px] font-semibold text-[#4A7255] hover:underline"
              >
                <Plus className="w-3 h-3" />
                <span>Add Vaccine</span>
              </button>
            </div>

            {vaccinations.length === 0 ? (
              <p className="text-[11px] text-[#718778] italic">No vaccines logged during this consultation.</p>
            ) : (
              <div className="space-y-2">
                {vaccinations.map((vac, idx) => (
                  <div key={idx} className="grid grid-cols-1 sm:grid-cols-4 gap-2 items-center bg-white p-2 rounded-lg border border-[#E3ECE5]">
                    <input
                      type="text"
                      placeholder="Vaccine Name (e.g. Rabies 3-Yr)"
                      value={vac.vaccineName}
                      onChange={(e) => handleVaccineChange(idx, 'vaccineName', e.target.value)}
                      className="px-2 py-1 text-xs border rounded-md"
                    />
                    <input
                      type="date"
                      value={vac.administeredDate}
                      onChange={(e) => handleVaccineChange(idx, 'administeredDate', e.target.value)}
                      className="px-2 py-1 text-xs border rounded-md"
                    />
                    <input
                      type="date"
                      placeholder="Next Due Date"
                      value={vac.nextDueDate || ''}
                      onChange={(e) => handleVaccineChange(idx, 'nextDueDate', e.target.value)}
                      className="px-2 py-1 text-xs border rounded-md"
                    />
                    <div className="flex items-center gap-1">
                      <input
                        type="text"
                        placeholder="Batch #"
                        value={vac.batchNumber || ''}
                        onChange={(e) => handleVaccineChange(idx, 'batchNumber', e.target.value)}
                        className="px-2 py-1 text-xs border rounded-md w-full"
                      />
                      <button
                        type="button"
                        onClick={() => handleRemoveVaccine(idx)}
                        className="p-1 text-[#B92A2A] hover:bg-[#FDF2F2] rounded"
                      >
                        <Trash className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Follow-up date & Notes */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block font-semibold mb-1 text-[#2D3A31]">Recommended Follow-up Date</label>
              <input
                type="date"
                value={followUpDate}
                onChange={(e) => setFollowUpDate(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-[#D5E0D7] bg-[#FBFCFB] focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#4A7255]"
              />
            </div>
            <div>
              <label className="block font-semibold mb-1 text-[#2D3A31]">Additional Clinical Remarks</label>
              <input
                type="text"
                value={additionalNotes}
                onChange={(e) => setAdditionalNotes(e.target.value)}
                placeholder="Discharge notes, behavioral response..."
                className="w-full px-3 py-2 rounded-xl border border-[#D5E0D7] bg-[#FBFCFB] focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#4A7255]"
              />
            </div>
          </div>

          <div className="pt-3 border-t border-[#E8EFEA] flex items-center justify-end gap-2.5">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-[#EEF3EF] hover:bg-[#E3ECE5] text-[#2F4134] font-semibold rounded-xl"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 bg-[#4A7255] hover:bg-[#3C5D45] text-white font-semibold rounded-xl shadow-sm transition-all"
            >
              {recordToEdit ? 'Save Changes' : 'Save Medical Record'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
