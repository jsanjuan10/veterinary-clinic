import React from 'react';
import {
  X,
  Stethoscope,
  PawPrint,
  User,
  Calendar,
  Thermometer,
  Scale,
  Pill,
  Syringe,
  Printer,
  Edit2,
  Trash2,
} from 'lucide-react';
import { MedicalRecord, Pet, PetOwner } from '../../types';
import { db } from '../../services/db';

interface MedicalRecordDetailsModalProps {
  record: MedicalRecord | null;
  isOpen: boolean;
  onClose: () => void;
  onEdit: (rec: MedicalRecord) => void;
  onDelete: (rec: MedicalRecord) => void;
  onSelectPet: (petId: string) => void;
}

export const MedicalRecordDetailsModal: React.FC<MedicalRecordDetailsModalProps> = ({
  record,
  isOpen,
  onClose,
  onEdit,
  onDelete,
  onSelectPet,
}) => {
  if (!isOpen || !record) return null;

  const pet = db.getPetById(record.petId);
  const owner = db.getOwnerById(record.ownerId);

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/45 backdrop-blur-[2px] overflow-y-auto">
      <div className="bg-white rounded-2xl max-w-2xl w-full shadow-2xl border border-[#DCE4DF] max-h-[92vh] flex flex-col overflow-hidden animate-in fade-in zoom-in-95 my-auto">
        {/* Header */}
        <div className="p-5 border-b border-[#E8EFEA] flex items-center justify-between bg-[#F8FAF8]">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#E8F0EA] text-[#3E6548] flex items-center justify-center font-bold">
              <Stethoscope className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-bold font-display text-[#1F2923]">
                  Consultation Dossier: {record.diagnosis}
                </h3>
                <span className="font-mono text-xs text-[#718677]">{record.id}</span>
              </div>
              <p className="text-xs text-[#5D7063]">
                Examined on {record.consultationDate} by {record.veterinarian}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="p-2 text-[#566B5C] hover:text-[#213025] hover:bg-[#EAEFEA] rounded-xl transition-colors"
              title="Print Clinical Note"
            >
              <Printer className="w-4 h-4" />
            </button>
            <button
              onClick={() => onEdit(record)}
              className="p-2 text-[#566B5C] hover:text-[#213025] hover:bg-[#EAEFEA] rounded-xl transition-colors"
              title="Edit Record"
            >
              <Edit2 className="w-4 h-4" />
            </button>
            <button
              onClick={() => onDelete(record)}
              className="p-2 text-[#B92A2A] hover:bg-[#FDF2F2] rounded-xl transition-colors"
              title="Delete Record"
            >
              <Trash2 className="w-4 h-4" />
            </button>
            <button
              onClick={onClose}
              className="p-2 text-[#738879] hover:text-[#1E2820] hover:bg-[#EAEFEA] rounded-xl"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Modal Scrollable Body */}
        <div className="p-6 overflow-y-auto space-y-5 flex-1 text-xs text-[#1F2923]">
          {/* Patient & Owner Quick Strip */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 bg-[#F8FAF8] p-4 rounded-2xl border border-[#E3ECE5]">
            <div className="flex items-center gap-3">
              {pet?.photoUrl ? (
                <img
                  src={pet.photoUrl}
                  alt={pet.name}
                  className="w-12 h-12 rounded-xl object-cover border"
                  referrerPolicy="no-referrer"
                />
              ) : (
                <div className="w-12 h-12 rounded-xl bg-[#E8F0EA] text-[#4A7255] flex items-center justify-center font-bold">
                  {pet?.name?.charAt(0) || 'P'}
                </div>
              )}
              <div>
                <button
                  onClick={() => pet && onSelectPet(pet.id)}
                  className="font-bold text-sm text-[#273F2E] hover:underline block text-left"
                >
                  {pet?.name || 'Pet'} ({pet?.species})
                </button>
                <span className="text-[#647C6A] block">
                  {pet?.breed} · {pet?.gender} · {pet?.ageYears}y {pet?.ageMonths}m
                </span>
              </div>
            </div>

            <div className="border-t sm:border-t-0 sm:border-l border-[#E2EAE4] sm:pl-4 pt-2 sm:pt-0">
              <span className="text-[11px] text-[#697E70] block">Owner of Record</span>
              <span className="font-bold text-[#1F2923] text-sm block">{owner?.fullName}</span>
              <span className="font-mono text-[#526657]">{owner?.phoneNumber}</span>
            </div>
          </div>

          {/* Vitals Strip */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="p-3 rounded-xl bg-[#F4F8F5] border border-[#DEEBE1]">
              <span className="text-[11px] text-[#556D5B] block flex items-center gap-1">
                <Scale className="w-3.5 h-3.5 text-[#4A7255]" />
                Weight
              </span>
              <span className="text-base font-bold font-mono text-[#1F2923] tabular-nums mt-0.5 block">
                {record.weight} kg
              </span>
            </div>

            <div className="p-3 rounded-xl bg-[#F4F8F5] border border-[#DEEBE1]">
              <span className="text-[11px] text-[#556D5B] block flex items-center gap-1">
                <Thermometer className="w-3.5 h-3.5 text-[#4A7255]" />
                Temperature
              </span>
              <span className="text-base font-bold font-mono text-[#1F2923] tabular-nums mt-0.5 block">
                {record.temperature} °C
              </span>
            </div>

            <div className="p-3 rounded-xl bg-[#F4F8F5] border border-[#DEEBE1]">
              <span className="text-[11px] text-[#556D5B] block flex items-center gap-1">
                <Calendar className="w-3.5 h-3.5 text-[#4A7255]" />
                Consultation Date
              </span>
              <span className="text-xs font-bold font-mono text-[#1F2923] tabular-nums mt-1 block">
                {record.consultationDate}
              </span>
            </div>

            <div className="p-3 rounded-xl bg-[#F4F8F5] border border-[#DEEBE1]">
              <span className="text-[11px] text-[#556D5B] block flex items-center gap-1">
                <Calendar className="w-3.5 h-3.5 text-[#4A7255]" />
                Next Follow-up
              </span>
              <span className="text-xs font-bold font-mono text-[#1F2923] tabular-nums mt-1 block">
                {record.followUpDate || 'None required'}
              </span>
            </div>
          </div>

          {/* Symptoms, Diagnosis, Treatment */}
          <div className="space-y-3">
            <div className="p-3.5 rounded-xl border border-[#E3ECE5] bg-white">
              <span className="font-bold text-[#324536] block mb-1">Presenting Clinical Symptoms</span>
              <p className="text-[#55695B] leading-relaxed">{record.symptoms}</p>
            </div>

            <div className="p-3.5 rounded-xl border border-[#E3ECE5] bg-white">
              <span className="font-bold text-[#324536] block mb-1">Diagnosis & Assessment</span>
              <p className="text-[#1F2923] font-semibold leading-relaxed">{record.diagnosis}</p>
            </div>

            <div className="p-3.5 rounded-xl border border-[#E3ECE5] bg-white">
              <span className="font-bold text-[#324536] block mb-1">Treatment Rendered in Clinic</span>
              <p className="text-[#55695B] leading-relaxed">{record.treatment}</p>
            </div>

            {/* Prescribed Medication */}
            {record.prescribedMedication && (
              <div className="p-4 rounded-xl border border-[#D5E4D8] bg-[#F2F7F3]">
                <div className="flex items-center gap-2 font-bold text-[#2A4B33] mb-1.5">
                  <Pill className="w-4 h-4 text-[#4A7255]" />
                  <span>Prescribed Take-Home Medication & Instructions</span>
                </div>
                <p className="text-[#2F4A37] font-medium leading-relaxed font-mono text-xs">
                  {record.prescribedMedication}
                </p>
              </div>
            )}

            {/* Vaccinations */}
            {record.vaccinationRecords && record.vaccinationRecords.length > 0 && (
              <div className="p-4 rounded-xl border border-[#DCE6DE] bg-[#FAFBF9]">
                <div className="flex items-center gap-2 font-bold text-[#2F4735] mb-2.5">
                  <Syringe className="w-4 h-4 text-[#4A7255]" />
                  <span>Vaccination Inoculation History</span>
                </div>
                <div className="space-y-2">
                  {record.vaccinationRecords.map((vac, i) => (
                    <div
                      key={i}
                      className="p-2.5 bg-white rounded-lg border border-[#E3ECE5] flex items-center justify-between"
                    >
                      <div>
                        <span className="font-bold text-[#1F2923] block">{vac.vaccineName}</span>
                        <span className="text-[11px] text-[#697E70]">
                          Administered: {vac.administeredDate} · Batch: {vac.batchNumber || 'N/A'}
                        </span>
                      </div>
                      {vac.nextDueDate && (
                        <span className="text-[11px] font-semibold text-[#32523B] bg-[#EDF3EF] px-2 py-0.5 rounded-md">
                          Due: {vac.nextDueDate}
                        </span>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Additional Remarks */}
            {record.additionalNotes && (
              <div className="p-3 rounded-xl border border-[#E3ECE5] bg-white text-xs text-[#55695B]">
                <span className="font-bold text-[#324536] block mb-1">Attending Notes</span>
                <p>{record.additionalNotes}</p>
              </div>
            )}
          </div>
        </div>

        {/* Modal Footer */}
        <div className="p-4 border-t border-[#E8EFEA] bg-[#F8FAF8] flex items-center justify-between">
          <span className="text-xs text-[#738879]">
            Certified by {record.veterinarian}
          </span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 bg-[#E8EFEA] hover:bg-[#DCE6DE] text-[#2F4134] text-xs font-semibold rounded-xl transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
